if(!window.cp)window.cp = function(str){return document.getElementById(str)};cp.CPProjInit = function(){if(cp && cp.model && cp.model.data) return; cp.model = {}; cp.poolResources = {}; cp.D = cp.model.data = {
pref:{
acc:1,
rkt:1,
hsr:0,
atp:false
},
si507:{
name:'Paragraph_1',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si507c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":20,"bottom":20,"left":10,"right":10},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si515',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"padding":{"top":20,"bottom":20,"left":10,"right":10},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'PARAGRAPH_OPTION_SOLID_FILL',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si507c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:507,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si507',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si515:{
name:'Paragraph_Group_1',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si515c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":false,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-heading":"CENTER","slide-item-subtitle":"CENTER","slide-item-body":"CENTER","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si507',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si543',
t:1250
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":false,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-heading":"CENTER","slide-item-subtitle":"CENTER","slide-item-body":"CENTER","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si507',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si515c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:515,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si515',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si543:{
name:'Text_3',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si543c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"marginTop":"60px"},"tablet":{},"mobile":{}}}',
parentGroup:'si515',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"8e2h2","text":"EU Legislation affecting eProcument ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":36,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":36,"style":"textOutlineEnable:false"},{"offset":0,"length":36,"style":"opacity:1"},{"offset":0,"length":36,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":36,"style":"hlnke:true"},{"offset":0,"length":36,"style":"defaultTextShadow:none"},{"offset":0,"length":36,"style":"textShadow:none"},{"offset":0,"length":36,"style":"textShadowX:0px"},{"offset":0,"length":36,"style":"fontStretch:normal"},{"offset":0,"length":36,"style":"fontType:regular"},{"offset":0,"length":36,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":36,"style":"textShadowY:4px"},{"offset":0,"length":36,"style":"letterSpacing:3%"},{"offset":0,"length":36,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":36,"style":"textHighlightEnable:false"},{"offset":0,"length":36,"style":"textTransform:none"},{"offset":0,"length":36,"style":"desktop-fontSize:60"},{"offset":0,"length":36,"style":"color:#020C1C"},{"offset":0,"length":36,"style":"lineHeight:110%"},{"offset":0,"length":36,"style":"textShadowOpacity:none"},{"offset":0,"length":36,"style":"textDecoration:none"},{"offset":0,"length":36,"style":"fontFamily:Georgia"},{"offset":0,"length":36,"style":"borderBottomStyle:none"},{"offset":0,"length":36,"style":"textShadowEnable:false"},{"offset":0,"length":36,"style":"hlnk:"},{"offset":0,"length":36,"style":"fontWeight:normal"},{"offset":0,"length":36,"style":"textShadowBlur:8px"},{"offset":0,"length":36,"style":"overridden:false"},{"offset":0,"length":36,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":36,"style":"backgroundColor:unset"},{"offset":0,"length":36,"style":"mobile-fontSize:44"},{"offset":0,"length":36,"style":"tablet-fontSize:52"},{"offset":0,"length":36,"style":"fontStyle:normal"},{"offset":0,"length":36,"style":"hlnkt:wp"},{"offset":0,"length":36,"style":"defaultTextStrokeWidth:1px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-3","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[543]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si543c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:543,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si543',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1092:{
name:'Click_To_Reveal_Widget_1',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1092c',
tag:'click-to-reveal-widget-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"click-to-reveal-heading":true,"slide-item-widget-body":true,"slide-item-widget-instructions":true,"click-to-reveal-icon":true,"click-to-reveal-label":true,"slide-item-prev-button":true,"slide-item-next-button":true},"numberOfCards":{"value":4},"canBeCard":false,"isForcedNavigationEnabled":{"value":true},"activeOverlay":{"value":null},"widgetContentSpacing":{"value":1},"padding":{"value":{"top":40,"bottom":40,"left":4,"right":4}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{},"revealFirstCardByDefault":{"value":false},"areStatesSupported":false}',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1100',
t:1250
}
,{
n:'si1110',
t:1250
}
,{
n:'si1120',
t:1250
}
,{
n:'si1130',
t:1268
}
,{
n:'si1420',
t:1268
}
,{
n:'si1932',
t:1268
}
]
,
containerType:'click-to-reveal-widget',
widgetProps:'{"visibilityInfo":{"click-to-reveal-heading":true,"slide-item-widget-body":true,"slide-item-widget-instructions":true,"click-to-reveal-icon":true,"click-to-reveal-label":true,"slide-item-prev-button":true,"slide-item-next-button":true},"numberOfCards":{"value":4},"canBeCard":false,"isForcedNavigationEnabled":{"value":true},"activeOverlay":{"value":null},"widgetContentSpacing":{"value":1},"padding":{"value":{"top":40,"bottom":40,"left":4,"right":4}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{},"revealFirstCardByDefault":{"value":false},"areStatesSupported":false}',
option:'CLICK_TO_REVEAL_WIDGET_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1092c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1092,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1092',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1100:{
name:'Text_19',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1100c',
tag:'click-to-reveal-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"textAlign":"left"},"tablet":{},"mobile":{},"mobile_landscape":{}}}',
parentGroup:'si1092',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"8fq97","text":"EU Law forms the foundation upon which EU procurement practices are based","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":73,"style":"hlnk:"},{"offset":0,"length":73,"style":"hlnkt:wp"},{"offset":0,"length":73,"style":"textOutlineEnable:false"},{"offset":0,"length":73,"style":"opacity:1"},{"offset":0,"length":73,"style":"hlnke:true"},{"offset":0,"length":73,"style":"backgroundColor:unset"},{"offset":0,"length":73,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":73,"style":"textHighlightEnable:false"},{"offset":0,"length":73,"style":"textShadowEnable:false"},{"offset":0,"length":73,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-heading-5"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1100]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1100c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1100,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1100',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1110:{
name:'Text_20',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1110c',
tag:'slide-item-widget-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1092',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"am0nn","text":"Three new directives around procurement by public bodies were were adopted by the European Parliament on 26 February 2014: ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":123,"style":"backgroundColor:unset"},{"offset":0,"length":123,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":123,"style":"textHighlightEnable:false"},{"offset":0,"length":123,"style":"textShadowEnable:false"},{"offset":0,"length":123,"style":"overridden:false"},{"offset":0,"length":123,"style":"hlnk:"},{"offset":0,"length":123,"style":"hlnkt:wp"},{"offset":0,"length":123,"style":"textOutlineEnable:false"},{"offset":0,"length":123,"style":"opacity:1"},{"offset":0,"length":123,"style":"hlnke:true"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-body-2"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1110]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1110c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1110,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1110',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1120:{
name:'Text_21',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1120c',
tag:'slide-item-widget-instructions',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1092',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5lt2m","text":"Select each card to learn more.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":31,"style":"hlnk:"},{"offset":0,"length":31,"style":"hlnkt:wp"},{"offset":0,"length":31,"style":"textOutlineEnable:false"},{"offset":0,"length":31,"style":"opacity:1"},{"offset":0,"length":31,"style":"hlnke:true"},{"offset":0,"length":31,"style":"backgroundColor:unset"},{"offset":0,"length":31,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":31,"style":"textHighlightEnable:false"},{"offset":0,"length":31,"style":"textShadowEnable:false"},{"offset":0,"length":31,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1120]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1120c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1120,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1120',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1130:{
name:'Click_To_Reveal_Content_Container_1',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1130c',
tag:'click-to-reveal-content-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"20px","paddingTop":"20px"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"},"mobile_landscape":{"flexDirection":"column"}}}',
parentGroup:'si1092',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1138',
t:1268
}
,{
n:'si1185',
t:1268
}
,{
n:'si1232',
t:1268
}
,{
n:'si1279',
t:1268
}
,{
n:'si1326',
t:1268
}
,{
n:'si1373',
t:1268
}
]
,
containerType:'click-to-reveal-content-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"20px","paddingTop":"20px"},"tablet":{"flexDirection":"column"},"mobile":{"flexDirection":"column"},"mobile_landscape":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1092',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1130c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1130,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1130',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1138:{
name:'Click_To_Reveal_Card_Container_1',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1138c',
tag:'click-to-reveal-card-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
parentGroup:'si1130',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1146',
t:1268
}
,{
n:'si1154',
t:1268
}
,{
n:'si1175',
t:1250
}
]
,
containerType:'click-to-reveal-card-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1130',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1138c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1138,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1138',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1146:{
name:'Click_To_Reveal_Wrapper_For_Card_Design_Options_1',
type:1268,
from:181,
to:180,
rp:0,
rpa:0,
mdi:'si1146c',
tag:'click-to-reveal-wrapper-for-card-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
parentGroup:'si1138',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-card-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1138',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1146c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1146,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1146',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1154:{
name:'Click_To_Reveal_SVG_Container_1',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1154c',
tag:'click-to-reveal-svg-container-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#075CA3","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#ffffff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#ffffff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"}}}',
parentGroup:'si1138',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1165',
t:652
}
]
,
containerType:'click-to-reveal-svg-container-1',
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#075CA3","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#ffffff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#ffffff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1138',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1154c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1154,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1154',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1165:{
name:'Briefcase',
type:652,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1165c',
tag:'click-to-reveal-icon-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true},"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clicktoreveal_default","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si1154',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1165]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1165c:{
b:[627,328,739,440],
fh:false,
fw:false,
uid:1165,
iso:false,
css:{
360:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1165',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/02099.svg',
wofh:36,
wofw:36,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[626,327,740,441],
vb:[626,327,740,441]
},
si1175:{
name:'Text_22',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1175c',
tag:'click-to-reveal-content-label-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"paddingTop":"17px","paddingBottom":"13px"}}}',
parentGroup:'si1138',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"9nohk","text":"Directive 2014/24/EU on public procurement","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":42,"style":"hlnk:"},{"offset":0,"length":42,"style":"hlnkt:wp"},{"offset":0,"length":42,"style":"textOutlineEnable:false"},{"offset":0,"length":42,"style":"opacity:1"},{"offset":0,"length":42,"style":"hlnke:true"},{"offset":0,"length":42,"style":"backgroundColor:unset"},{"offset":0,"length":42,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":42,"style":"textHighlightEnable:false"},{"offset":0,"length":42,"style":"textShadowEnable:false"},{"offset":0,"length":42,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-3"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1175]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1175c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1175,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1175',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1185:{
name:'Click_To_Reveal_Card_Container_2',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1185c',
tag:'click-to-reveal-card-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
parentGroup:'si1130',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1193',
t:1268
}
,{
n:'si1201',
t:1268
}
,{
n:'si1222',
t:1250
}
]
,
containerType:'click-to-reveal-card-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1130',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1185c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1185,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1185',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1193:{
name:'Click_To_Reveal_Wrapper_For_Card_Design_Options_2',
type:1268,
from:181,
to:180,
rp:0,
rpa:0,
mdi:'si1193c',
tag:'click-to-reveal-wrapper-for-card-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
parentGroup:'si1185',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-card-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1185',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1193c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1193,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1193',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1201:{
name:'Click_To_Reveal_SVG_Container_2',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1201c',
tag:'click-to-reveal-svg-container-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2E7EB9","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"},"tablet":{},"mobile":{},"mobile_landscape":{}}}',
parentGroup:'si1185',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1212',
t:652
}
]
,
containerType:'click-to-reveal-svg-container-2',
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2E7EB9","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"},"tablet":{},"mobile":{},"mobile_landscape":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1185',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1201c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1201,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1201',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1212:{
name:'ClickToRevealPlaceholder2',
type:652,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1212c',
tag:'click-to-reveal-icon-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true},"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clicktoreveal_default","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si1201',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1212]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1212c:{
b:[627,328,739,440],
fh:false,
fw:false,
uid:1212,
iso:false,
css:{
360:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1212',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/01209.svg',
wofh:112,
wofw:112,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[626,327,740,441],
vb:[626,327,740,441]
},
si1222:{
name:'Text_23',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1222c',
tag:'click-to-reveal-content-label-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"paddingTop":"17px","paddingBottom":"13px"}}}',
parentGroup:'si1185',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"916ss","text":"Directive 2014/25/EU on procurement by entities operating in the water, energy, transport and postal services sectors","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":117,"style":"backgroundColor:unset"},{"offset":0,"length":117,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":117,"style":"textHighlightEnable:false"},{"offset":0,"length":117,"style":"textShadowEnable:false"},{"offset":0,"length":117,"style":"overridden:false"},{"offset":0,"length":117,"style":"hlnk:"},{"offset":0,"length":117,"style":"hlnkt:wp"},{"offset":0,"length":117,"style":"textOutlineEnable:false"},{"offset":0,"length":117,"style":"opacity:1"},{"offset":0,"length":117,"style":"hlnke:true"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-3"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1222]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1222c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1222,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1222',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1232:{
name:'Click_To_Reveal_Card_Container_3',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1232c',
tag:'click-to-reveal-card-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
parentGroup:'si1130',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1240',
t:1268
}
,{
n:'si1248',
t:1268
}
,{
n:'si1269',
t:1250
}
]
,
containerType:'click-to-reveal-card-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1130',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1232c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1232,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1232',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1240:{
name:'Click_To_Reveal_Wrapper_For_Card_Design_Options_3',
type:1268,
from:181,
to:180,
rp:0,
rpa:0,
mdi:'si1240c',
tag:'click-to-reveal-wrapper-for-card-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
parentGroup:'si1232',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-card-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1232',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1240c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1240,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1240',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1248:{
name:'Click_To_Reveal_SVG_Container_3',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1248c',
tag:'click-to-reveal-svg-container-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#66C4D9","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"},"tablet":{},"mobile":{},"mobile_landscape":{}}}',
parentGroup:'si1232',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1259',
t:652
}
]
,
containerType:'click-to-reveal-svg-container-3',
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#66C4D9","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"},"tablet":{},"mobile":{},"mobile_landscape":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1232',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1248c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1248,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1248',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1259:{
name:'ClickToRevealPlaceholder3',
type:652,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1259c',
tag:'click-to-reveal-icon-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true},"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clicktoreveal_default","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si1248',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1259]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1259c:{
b:[627,328,739,440],
fh:false,
fw:false,
uid:1259,
iso:false,
css:{
360:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1259',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/01256.svg',
wofh:112,
wofw:112,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[626,327,740,441],
vb:[626,327,740,441]
},
si1269:{
name:'Text_24',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1269c',
tag:'click-to-reveal-content-label-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"paddingTop":"17px","paddingBottom":"13px"}}}',
parentGroup:'si1232',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"38cm","text":"Directive 2014/23/EU on the award of concession contracts","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"hlnk:"},{"offset":0,"length":57,"style":"hlnkt:wp"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"hlnke:true"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textShadowEnable:false"},{"offset":0,"length":57,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-3"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1269]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1269c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1269,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1269',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1279:{
name:'Click_To_Reveal_Card_Container_4',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1279c',
tag:'click-to-reveal-card-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
parentGroup:'si1130',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1287',
t:1268
}
,{
n:'si1295',
t:1268
}
,{
n:'si1316',
t:1250
}
]
,
containerType:'click-to-reveal-card-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1130',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1279c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1279,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1279',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1287:{
name:'Click_To_Reveal_Wrapper_For_Card_Design_Options_4',
type:1268,
from:181,
to:180,
rp:0,
rpa:0,
mdi:'si1287c',
tag:'click-to-reveal-wrapper-for-card-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
parentGroup:'si1279',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-card-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1279',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1287c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1287,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1287',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1295:{
name:'Click_To_Reveal_SVG_Container_4',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1295c',
tag:'click-to-reveal-svg-container-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#CDD1DE","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"},"tablet":{},"mobile":{},"mobile_landscape":{}}}',
parentGroup:'si1279',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1306',
t:652
}
]
,
containerType:'click-to-reveal-svg-container-4',
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#CDD1DE","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"},"tablet":{},"mobile":{},"mobile_landscape":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1279',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1295c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1295,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1295',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1306:{
name:'ClickToRevealPlaceholder4',
type:652,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1306c',
tag:'click-to-reveal-icon-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true},"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clicktoreveal_default","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si1295',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1306]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1306c:{
b:[627,328,739,440],
fh:false,
fw:false,
uid:1306,
iso:false,
css:{
360:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1306',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/01303.svg',
wofh:112,
wofw:112,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[626,327,740,441],
vb:[626,327,740,441]
},
si1316:{
name:'Text_25',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1316c',
tag:'click-to-reveal-content-label-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"paddingTop":"17px","paddingBottom":"13px"}}}',
parentGroup:'si1279',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"7v52v","text":"Directive - 2009/81 on the award of works, supply and service contracts in defence and security","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":95,"style":"hlnk:"},{"offset":0,"length":95,"style":"hlnkt:wp"},{"offset":0,"length":95,"style":"textOutlineEnable:false"},{"offset":0,"length":95,"style":"opacity:1"},{"offset":0,"length":95,"style":"hlnke:true"},{"offset":0,"length":95,"style":"backgroundColor:unset"},{"offset":0,"length":95,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":95,"style":"textHighlightEnable:false"},{"offset":0,"length":95,"style":"textShadowEnable:false"},{"offset":0,"length":95,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-3"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1316]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1316c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1316,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1316',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1326:{
name:'Click_To_Reveal_Card_Container_5',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1326c',
tag:'click-to-reveal-card-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
parentGroup:'si1130',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1334',
t:1268
}
,{
n:'si1342',
t:1268
}
,{
n:'si1363',
t:1250
}
]
,
containerType:'click-to-reveal-card-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1130',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1326c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1326,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1326',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1334:{
name:'Click_To_Reveal_Wrapper_For_Card_Design_Options_5',
type:1268,
from:181,
to:180,
rp:0,
rpa:0,
mdi:'si1334c',
tag:'click-to-reveal-wrapper-for-card-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
parentGroup:'si1326',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-card-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1326',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1334c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1334,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1334',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1342:{
name:'Click_To_Reveal_SVG_Container_5',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1342c',
tag:'click-to-reveal-svg-container-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#522B47","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"},"tablet":{},"mobile":{},"mobile_landscape":{}}}',
parentGroup:'si1326',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1353',
t:652
}
]
,
containerType:'click-to-reveal-svg-container-5',
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#522B47","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"},"tablet":{},"mobile":{},"mobile_landscape":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1326',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1342c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1342,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1342',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1353:{
name:'ClickToRevealPlaceholder5',
type:652,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1353c',
tag:'click-to-reveal-icon-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true},"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clicktoreveal_default","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si1342',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1353]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1353c:{
b:[627,328,739,440],
fh:false,
fw:false,
uid:1353,
iso:false,
css:{
360:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1353',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/01350.svg',
wofh:112,
wofw:112,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[626,327,740,441],
vb:[626,327,740,441]
},
si1363:{
name:'Text_26',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1363c',
tag:'click-to-reveal-content-label-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"paddingTop":"17px","paddingBottom":"13px"}}}',
parentGroup:'si1326',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5qe78","text":"05","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1363]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1363c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1363,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1363',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1373:{
name:'Click_To_Reveal_Card_Container_6',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1373c',
tag:'click-to-reveal-card-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
parentGroup:'si1130',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1381',
t:1268
}
,{
n:'si1389',
t:1268
}
,{
n:'si1410',
t:1250
}
]
,
containerType:'click-to-reveal-card-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-icon":true,"click-to-reveal-label":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1130',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1373c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1373,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1373',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1381:{
name:'Click_To_Reveal_Wrapper_For_Card_Design_Options_6',
type:1268,
from:181,
to:180,
rp:0,
rpa:0,
mdi:'si1381c',
tag:'click-to-reveal-wrapper-for-card-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
parentGroup:'si1373',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-card-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"all":{"clipPath":"none","flex":1}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1373',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1381c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1381,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1381',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1389:{
name:'Click_To_Reveal_SVG_Container_6',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1389c',
tag:'click-to-reveal-svg-container-6',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#BC4749","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"},"tablet":{},"mobile":{},"mobile_landscape":{}}}',
parentGroup:'si1373',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1400',
t:652
}
]
,
containerType:'click-to-reveal-svg-container-6',
widgetProps:'{"canBeCard":true,"areStatesSupported":true,"visibilityInfo":{"card":true},"groupedItemsVisibility":{},"stateInfo":{"dropped":{"isEnabled":false,"appearanceProperties":{}},"dragMove":{"isEnabled":false,"appearanceProperties":{}},"normal":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#BC4749","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dragOver":{"isEnabled":false,"appearanceProperties":{}},"visited":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#2C15BF","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"dropSuccess":{"isEnabled":false,"appearanceProperties":{}},"dropActive":{"isEnabled":false,"appearanceProperties":{}},"currentState":"normal","hover":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#333333","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}},"disabled":{"isEnabled":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"},"fill":{"fillType":1,"fillEnable":true,"solidFillProps":{"color":"#B7B7B7","alpha":1},"linearGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":0},{"x":50,"y":100}]},"radialGradientProps":{"colorStops":[{"color":"#8eb7ff","alpha":1,"scaledPosition":0},{"color":"#002a3a","alpha":1,"scaledPosition":1}],"endPoints":[{"x":50,"y":50},{"x":100,"y":50}],"radialHandlePoints":[{"x":50,"y":100},{"x":100,"y":100}]},"imageProps":{}}}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"justifyContent":"center","alignItems":"center","flexBasis":"409px"},"tablet":{},"mobile":{},"mobile_landscape":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1373',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1389c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1389,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1389',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1400:{
name:'ClickToRevealPlaceholder6',
type:652,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1400c',
tag:'click-to-reveal-icon-6',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true},"currentState":"normal","normal":{"opacity":100,"shapePresetData":{"presetId":"cp_clicktoreveal_default","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si1389',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1400]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1400c:{
b:[627,328,739,440],
fh:false,
fw:false,
uid:1400,
iso:false,
css:{
360:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'64.506%',
t:'53.947%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'64.506%',
lhID:-1,
lvEID:0,
lvV:'53.947%',
lvID:-1,
w:'11.523%',
h:'18.421%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si1400',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/01397.svg',
wofh:112,
wofw:112,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[626,327,740,441],
vb:[626,327,740,441]
},
si1410:{
name:'Text_27',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1410c',
tag:'click-to-reveal-content-label-6',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"paddingTop":"17px","paddingBottom":"13px"}}}',
parentGroup:'si1373',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3s8ce","text":"06","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-3","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1410]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1410c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1410,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1410',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1420:{
name:'Click_To_Reveal_Overlay_Container_1',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1420c',
tag:'click-to-reveal-overlay-collection-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{}}',
parentGroup:'si1092',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1428',
t:1268
}
,{
n:'si1512',
t:1268
}
,{
n:'si1596',
t:1268
}
,{
n:'si1680',
t:1268
}
,{
n:'si1764',
t:1268
}
,{
n:'si1848',
t:1268
}
]
,
containerType:'click-to-reveal-overlay-collection-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1092',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1420c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1420,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1420',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1428:{
name:'Click_To_Reveal_Overlay_1',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1428c',
tag:'click-to-reveal-overlay-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
parentGroup:'si1420',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1436',
t:1268
}
,{
n:'si1444',
t:1268
}
]
,
containerType:'click-to-reveal-overlay-item-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
option:'CLICK_TO_REVEAL_OVERLAY_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1420',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1428c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1428,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1428',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color2)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1436:{
name:'Click_To_Reveal_Wrapper_For_Overlay_Design_Options_1',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si1436c',
tag:'click-to-reveal-wrapper-for-overlay-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
parentGroup:'si1428',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-overlay-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1428',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1436c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1436,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1436',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1444:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_1',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1444c',
tag:'click-to-reveal-image-and-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
parentGroup:'si1428',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1452',
t:1268
}
,{
n:'si1474',
t:1268
}
]
,
containerType:'click-to-reveal-image-and-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1428',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1444c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1444,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1444',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1452:{
name:'Click_To_Reveal_Overlay_Image_Container_1',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1452c',
tag:'click-to-reveal-overlay-image-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
parentGroup:'si1444',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1462',
t:15
}
]
,
containerType:'click-to-reveal-overlay-image-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1444',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1452c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1452,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1452',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1462:{
name:'ClickToRevealImagePlaceHolder1',
type:15,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1462c',
tag:'click-to-reveal-overlay-image-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1452',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:295,
irh:369,
w:295,
h:369,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1462]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1462c:{
b:[0,0,295,369],
fh:false,
fw:false,
uid:1462,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/01460.png',
dn:'si1462',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,296,370],
vb:[-1,-1,296,370]
},
si1474:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_2',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1474c',
tag:'click-to-reveal-overlay-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
parentGroup:'si1444',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1482',
t:1250
}
,{
n:'si1492',
t:1250
}
,{
n:'si1502',
t:1250
}
]
,
containerType:'click-to-reveal-overlay-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1444',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1474c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1474,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1474',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1482:{
name:'Text_28',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1482c',
tag:'click-to-reveal-overlay-label-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1474',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"ctctf","text":"01","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"overridden:false"},{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-detail-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1482]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1482c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1482,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1482',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1492:{
name:'Text_29',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1492c',
tag:'click-to-reveal-overlay-title-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1474',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"b58tq","text":"Directive 2014/24/EU on public procurement","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":42,"style":"hlnk:"},{"offset":0,"length":42,"style":"hlnkt:wp"},{"offset":0,"length":42,"style":"textOutlineEnable:false"},{"offset":0,"length":42,"style":"opacity:1"},{"offset":0,"length":42,"style":"hlnke:true"},{"offset":0,"length":42,"style":"backgroundColor:unset"},{"offset":0,"length":42,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":42,"style":"textHighlightEnable:false"},{"offset":0,"length":42,"style":"textShadowEnable:false"},{"offset":0,"length":42,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-5"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1492]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1492c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1492,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1492',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1502:{
name:'Text_30',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1502c',
tag:'click-to-reveal-overlay-body-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px","maxHeight":"100px","overflow":"scroll"}}}',
parentGroup:'si1474',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"ca6hp","text":"[update 01/01/2024]","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"opacity:1"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"79g56","text":"This directive applies to the ...","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":33,"style":"hlnk:"},{"offset":0,"length":33,"style":"hlnkt:wp"},{"offset":0,"length":33,"style":"textOutlineEnable:false"},{"offset":0,"length":33,"style":"opacity:1"},{"offset":0,"length":33,"style":"hlnke:true"},{"offset":0,"length":33,"style":"backgroundColor:unset"},{"offset":0,"length":33,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":33,"style":"textHighlightEnable:false"},{"offset":0,"length":33,"style":"textShadowEnable:false"},{"offset":0,"length":33,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-body-4"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1502]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1502c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1502,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1502',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1512:{
name:'Click_To_Reveal_Overlay_2',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1512c',
tag:'click-to-reveal-overlay-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
parentGroup:'si1420',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1520',
t:1268
}
,{
n:'si1528',
t:1268
}
]
,
containerType:'click-to-reveal-overlay-item-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
option:'CLICK_TO_REVEAL_OVERLAY_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1420',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1512c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1512,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1512',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color2)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1520:{
name:'Click_To_Reveal_Wrapper_For_Overlay_Design_Options_2',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si1520c',
tag:'click-to-reveal-wrapper-for-overlay-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
parentGroup:'si1512',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-overlay-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1512',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1520c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1520,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1520',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1528:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_3',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1528c',
tag:'click-to-reveal-image-and-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
parentGroup:'si1512',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1536',
t:1268
}
,{
n:'si1558',
t:1268
}
]
,
containerType:'click-to-reveal-image-and-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1512',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1528c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1528,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1528',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1536:{
name:'Click_To_Reveal_Overlay_Image_Container_2',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1536c',
tag:'click-to-reveal-overlay-image-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
parentGroup:'si1528',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1546',
t:15
}
]
,
containerType:'click-to-reveal-overlay-image-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1528',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1536c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1536,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1536',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1546:{
name:'ClickToRevealImagePlaceHolder2',
type:15,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1546c',
tag:'click-to-reveal-overlay-image-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1536',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:295,
irh:369,
w:295,
h:369,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1546]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1546c:{
b:[0,0,295,369],
fh:false,
fw:false,
uid:1546,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/01544.png',
dn:'si1546',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,296,370],
vb:[-1,-1,296,370]
},
si1558:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_4',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1558c',
tag:'click-to-reveal-overlay-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
parentGroup:'si1528',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1566',
t:1250
}
,{
n:'si1576',
t:1250
}
,{
n:'si1586',
t:1250
}
]
,
containerType:'click-to-reveal-overlay-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1528',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1558c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1558,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1558',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1566:{
name:'Text_31',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1566c',
tag:'click-to-reveal-overlay-label-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1558',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"1kmu8","text":"02","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"overridden:false"},{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-detail-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1566]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1566c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1566,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1566',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1576:{
name:'Text_32',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1576c',
tag:'click-to-reveal-overlay-title-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1558',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"81h06","text":"Directive 2014/25/EU on procurement by entities operating in the water, energy, transport and postal services sectors","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":117,"style":"hlnk:"},{"offset":0,"length":117,"style":"hlnkt:wp"},{"offset":0,"length":117,"style":"textOutlineEnable:false"},{"offset":0,"length":117,"style":"opacity:1"},{"offset":0,"length":117,"style":"hlnke:true"},{"offset":0,"length":117,"style":"backgroundColor:unset"},{"offset":0,"length":117,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":117,"style":"textHighlightEnable:false"},{"offset":0,"length":117,"style":"textShadowEnable:false"},{"offset":0,"length":117,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-5"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1576]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1576c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1576,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1576',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1586:{
name:'Text_33',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1586c',
tag:'click-to-reveal-overlay-body-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px","maxHeight":"100px","overflow":"scroll"}}}',
parentGroup:'si1558',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"2mjv9","text":"[updated 01/01/2024]","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":20,"style":"opacity:1"},{"offset":0,"length":20,"style":"hlnke:true"},{"offset":0,"length":20,"style":"backgroundColor:unset"},{"offset":0,"length":20,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":20,"style":"textHighlightEnable:false"},{"offset":0,"length":20,"style":"textShadowEnable:false"},{"offset":0,"length":20,"style":"overridden:false"},{"offset":0,"length":20,"style":"hlnk:"},{"offset":0,"length":20,"style":"hlnkt:wp"},{"offset":0,"length":20,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"3o2a","text":"This directive applies to essential sevices...","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":46,"style":"hlnk:"},{"offset":0,"length":46,"style":"hlnkt:wp"},{"offset":0,"length":46,"style":"textOutlineEnable:false"},{"offset":0,"length":46,"style":"opacity:1"},{"offset":0,"length":46,"style":"hlnke:true"},{"offset":0,"length":46,"style":"backgroundColor:unset"},{"offset":0,"length":46,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":46,"style":"textHighlightEnable:false"},{"offset":0,"length":46,"style":"textShadowEnable:false"},{"offset":0,"length":46,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-body-4"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1586]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1586c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1586,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1586',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1596:{
name:'Click_To_Reveal_Overlay_3',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1596c',
tag:'click-to-reveal-overlay-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
parentGroup:'si1420',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1604',
t:1268
}
,{
n:'si1612',
t:1268
}
]
,
containerType:'click-to-reveal-overlay-item-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
option:'CLICK_TO_REVEAL_OVERLAY_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1420',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1596c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1596,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1596',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color2)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1604:{
name:'Click_To_Reveal_Wrapper_For_Overlay_Design_Options_3',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si1604c',
tag:'click-to-reveal-wrapper-for-overlay-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
parentGroup:'si1596',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-overlay-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1596',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1604c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1604,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1604',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1612:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_5',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1612c',
tag:'click-to-reveal-image-and-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
parentGroup:'si1596',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1620',
t:1268
}
,{
n:'si1642',
t:1268
}
]
,
containerType:'click-to-reveal-image-and-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1596',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1612c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1612,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1612',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1620:{
name:'Click_To_Reveal_Overlay_Image_Container_3',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1620c',
tag:'click-to-reveal-overlay-image-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
parentGroup:'si1612',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1630',
t:15
}
]
,
containerType:'click-to-reveal-overlay-image-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1612',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1620c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1620,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1620',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1630:{
name:'ClickToRevealImagePlaceHolder3',
type:15,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1630c',
tag:'click-to-reveal-overlay-image-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1620',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:295,
irh:369,
w:295,
h:369,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1630]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1630c:{
b:[0,0,295,369],
fh:false,
fw:false,
uid:1630,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/01628.png',
dn:'si1630',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,296,370],
vb:[-1,-1,296,370]
},
si1642:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_6',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1642c',
tag:'click-to-reveal-overlay-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
parentGroup:'si1612',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1650',
t:1250
}
,{
n:'si1660',
t:1250
}
,{
n:'si1670',
t:1250
}
]
,
containerType:'click-to-reveal-overlay-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1612',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1642c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1642,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1642',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1650:{
name:'Text_34',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1650c',
tag:'click-to-reveal-overlay-label-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1642',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"2pjph","text":"03","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"overridden:false"},{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-detail-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1650]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1650c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1650,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1650',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1660:{
name:'Text_35',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1660c',
tag:'click-to-reveal-overlay-title-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1642',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"b0sfl","text":"Directive 2014/23/EU on the award of concession contracts","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":57,"style":"textDecoration:none"},{"offset":0,"length":57,"style":"lineHeight:130%"},{"offset":0,"length":57,"style":"borderBottomStyle:none"},{"offset":0,"length":57,"style":"fontWeight:bold"},{"offset":0,"length":57,"style":"desktop-fontSize:22"},{"offset":0,"length":57,"style":"textShadowEnable:false"},{"offset":0,"length":57,"style":"textShadowBlur:8px"},{"offset":0,"length":57,"style":"fontFamily:Arial"},{"offset":0,"length":57,"style":"textShadow:none"},{"offset":0,"length":57,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":57,"style":"tablet-fontSize:20"},{"offset":0,"length":57,"style":"fontStyle:normal"},{"offset":0,"length":57,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":57,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":57,"style":"textOutlineEnable:false"},{"offset":0,"length":57,"style":"opacity:1"},{"offset":0,"length":57,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":57,"style":"hlnke:true"},{"offset":0,"length":57,"style":"defaultTextShadow:none"},{"offset":0,"length":57,"style":"backgroundColor:unset"},{"offset":0,"length":57,"style":"mobile-fontSize:18"},{"offset":0,"length":57,"style":"hlnkt:n"},{"offset":0,"length":57,"style":"textShadowX:0px"},{"offset":0,"length":57,"style":"fontStretch:normal"},{"offset":0,"length":57,"style":"fontType:regular"},{"offset":0,"length":57,"style":"color:#666666"},{"offset":0,"length":57,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":57,"style":"textShadowY:4px"},{"offset":0,"length":57,"style":"letterSpacing:3%"},{"offset":0,"length":57,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":57,"style":"textHighlightEnable:false"},{"offset":0,"length":57,"style":"textTransform:none"},{"offset":0,"length":57,"style":"textShadowOpacity:none"},{"offset":0,"length":57,"style":"overridden:true"},{"offset":0,"length":57,"style":"hlnk:https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:02014L0023-20180101"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1660]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1660c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1660,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1660',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1670:{
name:'Text_36',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1670c',
tag:'click-to-reveal-overlay-body-3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px","maxHeight":"100px","overflow":"scroll"}}}',
parentGroup:'si1642',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6ugkl","text":"[updated 01/01/2024]","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":20,"style":"hlnk:"},{"offset":0,"length":20,"style":"hlnkt:wp"},{"offset":0,"length":20,"style":"textOutlineEnable:false"},{"offset":0,"length":20,"style":"opacity:1"},{"offset":0,"length":20,"style":"hlnke:true"},{"offset":0,"length":20,"style":"backgroundColor:unset"},{"offset":0,"length":20,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":20,"style":"textHighlightEnable:false"},{"offset":0,"length":20,"style":"textShadowEnable:false"},{"offset":0,"length":20,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"8q6te","text":"This directive applies to...","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":28,"style":"backgroundColor:unset"},{"offset":0,"length":28,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":28,"style":"textHighlightEnable:false"},{"offset":0,"length":28,"style":"textShadowEnable:false"},{"offset":0,"length":28,"style":"overridden:false"},{"offset":0,"length":28,"style":"hlnk:"},{"offset":0,"length":28,"style":"hlnkt:wp"},{"offset":0,"length":28,"style":"textOutlineEnable:false"},{"offset":0,"length":28,"style":"opacity:1"},{"offset":0,"length":28,"style":"hlnke:true"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-body-4"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1670]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1670c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1670,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1670',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1680:{
name:'Click_To_Reveal_Overlay_4',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1680c',
tag:'click-to-reveal-overlay-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
parentGroup:'si1420',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1688',
t:1268
}
,{
n:'si1696',
t:1268
}
]
,
containerType:'click-to-reveal-overlay-item-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
option:'CLICK_TO_REVEAL_OVERLAY_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1420',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1680c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1680,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1680',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color2)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1688:{
name:'Click_To_Reveal_Wrapper_For_Overlay_Design_Options_4',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si1688c',
tag:'click-to-reveal-wrapper-for-overlay-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
parentGroup:'si1680',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-overlay-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1680',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1688c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1688,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1688',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1696:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_7',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1696c',
tag:'click-to-reveal-image-and-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
parentGroup:'si1680',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1704',
t:1268
}
,{
n:'si1726',
t:1268
}
]
,
containerType:'click-to-reveal-image-and-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1680',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1696c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1696,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1696',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1704:{
name:'Click_To_Reveal_Overlay_Image_Container_4',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1704c',
tag:'click-to-reveal-overlay-image-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
parentGroup:'si1696',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1714',
t:15
}
]
,
containerType:'click-to-reveal-overlay-image-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1696',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1704c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1704,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1704',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1714:{
name:'ClickToRevealImagePlaceHolder4',
type:15,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1714c',
tag:'click-to-reveal-overlay-image-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1704',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:295,
irh:369,
w:295,
h:369,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1714]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1714c:{
b:[0,0,295,369],
fh:false,
fw:false,
uid:1714,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/01712.png',
dn:'si1714',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,296,370],
vb:[-1,-1,296,370]
},
si1726:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_8',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1726c',
tag:'click-to-reveal-overlay-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
parentGroup:'si1696',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1734',
t:1250
}
,{
n:'si1744',
t:1250
}
,{
n:'si1754',
t:1250
}
]
,
containerType:'click-to-reveal-overlay-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1696',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1726c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1726,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1726',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1734:{
name:'Text_37',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1734c',
tag:'click-to-reveal-overlay-label-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1726',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"d7rde","text":"04","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1734]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1734c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1734,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1734',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1744:{
name:'Text_38',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1744c',
tag:'click-to-reveal-overlay-title-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1726',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"42d69","text":"Directive - 2009/81 Defence and Security","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":40,"style":"textHighlightEnable:false"},{"offset":0,"length":40,"style":"textShadowEnable:false"},{"offset":0,"length":40,"style":"overridden:false"},{"offset":0,"length":40,"style":"hlnk:"},{"offset":0,"length":40,"style":"hlnkt:wp"},{"offset":0,"length":40,"style":"textOutlineEnable:false"},{"offset":0,"length":40,"style":"opacity:1"},{"offset":0,"length":40,"style":"hlnke:true"},{"offset":0,"length":40,"style":"backgroundColor:unset"},{"offset":0,"length":40,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-subheading-5"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1744]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1744c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1744,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1744',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1754:{
name:'Text_39',
type:1250,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1754c',
tag:'click-to-reveal-overlay-body-4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px","maxHeight":"100px","overflow":"scroll"}}}',
parentGroup:'si1726',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"35aqt","text":"[updated 01/01/2024]","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":20,"style":"hlnk:"},{"offset":0,"length":20,"style":"hlnkt:wp"},{"offset":0,"length":20,"style":"textOutlineEnable:false"},{"offset":0,"length":20,"style":"opacity:1"},{"offset":0,"length":20,"style":"hlnke:true"},{"offset":0,"length":20,"style":"backgroundColor:unset"},{"offset":0,"length":20,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":20,"style":"textHighlightEnable:false"},{"offset":0,"length":20,"style":"textShadowEnable:false"},{"offset":0,"length":20,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}},{"key":"c3q76","text":"This directive is concerned with...","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":35,"style":"hlnk:"},{"offset":0,"length":35,"style":"hlnkt:wp"},{"offset":0,"length":35,"style":"textOutlineEnable:false"},{"offset":0,"length":35,"style":"opacity:1"},{"offset":0,"length":35,"style":"hlnke:true"},{"offset":0,"length":35,"style":"backgroundColor:unset"},{"offset":0,"length":35,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":35,"style":"textHighlightEnable:false"},{"offset":0,"length":35,"style":"textShadowEnable:false"},{"offset":0,"length":35,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-body-4"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1754]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1754c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:1754,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1754',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si1764:{
name:'Click_To_Reveal_Overlay_5',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1764c',
tag:'click-to-reveal-overlay-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
parentGroup:'si1420',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1772',
t:1268
}
,{
n:'si1780',
t:1268
}
]
,
containerType:'click-to-reveal-overlay-item-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
option:'CLICK_TO_REVEAL_OVERLAY_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1420',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1764c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1764,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1764',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color2)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1772:{
name:'Click_To_Reveal_Wrapper_For_Overlay_Design_Options_5',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si1772c',
tag:'click-to-reveal-wrapper-for-overlay-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
parentGroup:'si1764',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-overlay-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1764',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1772c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1772,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1772',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1780:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_9',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1780c',
tag:'click-to-reveal-image-and-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
parentGroup:'si1764',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1788',
t:1268
}
,{
n:'si1810',
t:1268
}
]
,
containerType:'click-to-reveal-image-and-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1764',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1780c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1780,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1780',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1788:{
name:'Click_To_Reveal_Overlay_Image_Container_5',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1788c',
tag:'click-to-reveal-overlay-image-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
parentGroup:'si1780',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1798',
t:15
}
]
,
containerType:'click-to-reveal-overlay-image-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1780',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1788c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1788,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1788',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1798:{
name:'ClickToRevealImagePlaceHolder5',
type:15,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1798c',
tag:'click-to-reveal-overlay-image-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1788',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:295,
irh:369,
w:295,
h:369,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1798]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1798c:{
b:[0,0,295,369],
fh:false,
fw:false,
uid:1798,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/01796.png',
dn:'si1798',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,296,370],
vb:[-1,-1,296,370]
},
si1810:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_10',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1810c',
tag:'click-to-reveal-overlay-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
parentGroup:'si1780',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1818',
t:1250
}
,{
n:'si1828',
t:1250
}
,{
n:'si1838',
t:1250
}
]
,
containerType:'click-to-reveal-overlay-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1780',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1810c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1810,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1810',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1818:{
name:'Text_40',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1818c',
tag:'click-to-reveal-overlay-label-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1810',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"d4uo7","text":"05","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1818]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1818c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1818,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1818',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1828:{
name:'Text_41',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1828c',
tag:'click-to-reveal-overlay-title-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1810',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"bq784","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"},{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"overridden:false"},{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-subheading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1828]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1828c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1828,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1828',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1838:{
name:'Text_42',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1838c',
tag:'click-to-reveal-overlay-body-5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px","maxHeight":"100px","overflow":"scroll"}}}',
parentGroup:'si1810',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"fhek9","text":"Sed ut perpicilatis unde omnis iste natus error sit voluptatem accusan tium doloremque laudantium, totam rem aperiam eaque ipsa quae ab illo inventore veritatis et quas.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":169,"style":"hlnk:"},{"offset":0,"length":169,"style":"hlnkt:wp"},{"offset":0,"length":169,"style":"textOutlineEnable:false"},{"offset":0,"length":169,"style":"opacity:1"},{"offset":0,"length":169,"style":"hlnke:true"},{"offset":0,"length":169,"style":"backgroundColor:unset"},{"offset":0,"length":169,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":169,"style":"textHighlightEnable:false"},{"offset":0,"length":169,"style":"textShadowEnable:false"},{"offset":0,"length":169,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1838]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1838c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1838,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1838',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1848:{
name:'Click_To_Reveal_Overlay_6',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1848c',
tag:'click-to-reveal-overlay-6',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
parentGroup:'si1420',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1856',
t:1268
}
,{
n:'si1864',
t:1268
}
]
,
containerType:'click-to-reveal-overlay-item-container',
widgetProps:'{"canBeCard":true,"areStatesSupported":false,"visibilityInfo":{"click-to-reveal-overlay-label":true,"click-to-reveal-overlay-image":true,"click-to-reveal-overlay-title":true,"click-to-reveal-overlay-body":true,"card":true},"groupedItemsVisibility":{},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"flexDirection":"column","flexBasis":"370px","justifyContent":"center","padding":"40px"}}}',
option:'CLICK_TO_REVEAL_OVERLAY_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1420',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si1848c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1848,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1848',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color2)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1856:{
name:'Click_To_Reveal_Wrapper_For_Overlay_Design_Options_6',
type:1268,
from:1,
to:0,
rp:0,
rpa:0,
mdi:'si1856c',
tag:'click-to-reveal-wrapper-for-overlay-design-options',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:0,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
parentGroup:'si1848',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
containerType:'click-to-reveal-wrapper-for-overlay-design-options',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"designOptionStyles":{"desktop":{"width":"60%","height":"450px","display":"flex","flexDirection":"column"},"tablet":{"width":"90%","height":"450px","display":"flex","flexDirection":"column"},"mobile":{"width":"100%","display":"flex","flexDirection":"column"},"mobile_landscape":{"width":"85%","display":"flex","flexDirection":"column"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1848',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1856c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1856,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1856',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1864:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_11',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1864c',
tag:'click-to-reveal-image-and-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
parentGroup:'si1848',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1872',
t:1268
}
,{
n:'si1894',
t:1268
}
]
,
containerType:'click-to-reveal-image-and-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"40px","justifyContent":"flex-start"},"mobile":{"flexDirection":"column","gap":"40px"},"mobile_landscape":{"flexDirection":"column","gap":"40px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1848',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1864c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1864,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1864',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1872:{
name:'Click_To_Reveal_Overlay_Image_Container_6',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1872c',
tag:'click-to-reveal-overlay-image-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
parentGroup:'si1864',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1882',
t:15
}
]
,
containerType:'click-to-reveal-overlay-image-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"imageBehavior":"IG_TILE_CENTRE","imageHeight":340,"designOptionStyles":{"all":{"width":"200px"},"mobile":{"width":"100%"},"mobile_landscape":{"width":"100%"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1864',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1872c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1872,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1872',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si1882:{
name:'ClickToRevealImagePlaceHolder6',
type:15,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1882c',
tag:'click-to-reveal-overlay-image-6',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si1872',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:295,
irh:369,
w:295,
h:369,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1882]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1882c:{
b:[0,0,295,369],
fh:false,
fw:false,
uid:1882,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'30.350%',
h:'60.691%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/01880.png',
dn:'si1882',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,296,370],
vb:[-1,-1,296,370]
},
si1894:{
name:'Click_To_Reveal_Overlay_Image_And_Text_Container_12',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1894c',
tag:'click-to-reveal-overlay-text-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
parentGroup:'si1864',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1902',
t:1250
}
,{
n:'si1912',
t:1250
}
,{
n:'si1922',
t:1250
}
]
,
containerType:'click-to-reveal-overlay-text-container',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"alignItems":"flex-start","flex":1,"display":"flex","flexDirection":"column","justifyContent":"center","gap":"16px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1864',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1894c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1894,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1894',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1902:{
name:'Text_43',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1902c',
tag:'click-to-reveal-overlay-label-6',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1894',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"8ectj","text":"06","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":2,"style":"hlnk:"},{"offset":0,"length":2,"style":"hlnkt:wp"},{"offset":0,"length":2,"style":"textOutlineEnable:false"},{"offset":0,"length":2,"style":"opacity:1"},{"offset":0,"length":2,"style":"hlnke:true"},{"offset":0,"length":2,"style":"backgroundColor:unset"},{"offset":0,"length":2,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":2,"style":"textHighlightEnable:false"},{"offset":0,"length":2,"style":"textShadowEnable:false"},{"offset":0,"length":2,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-detail-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1902]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1902c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1902,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1902',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1912:{
name:'Text_44',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1912c',
tag:'click-to-reveal-overlay-title-6',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px"}}}',
parentGroup:'si1894',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"c0ts1","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":56,"style":"hlnke:true"},{"offset":0,"length":56,"style":"backgroundColor:unset"},{"offset":0,"length":56,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":56,"style":"textHighlightEnable:false"},{"offset":0,"length":56,"style":"textShadowEnable:false"},{"offset":0,"length":56,"style":"overridden:false"},{"offset":0,"length":56,"style":"hlnk:"},{"offset":0,"length":56,"style":"hlnkt:wp"},{"offset":0,"length":56,"style":"textOutlineEnable:false"},{"offset":0,"length":56,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-subheading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1912]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1912c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1912,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1912',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1922:{
name:'Text_45',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si1922c',
tag:'click-to-reveal-overlay-body-6',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"marginBottom":"10px","maxHeight":"100px","overflow":"scroll"}}}',
parentGroup:'si1894',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"9lfr3","text":"Sed ut perpicilatis unde omnis iste natus error sit voluptatem accusan tium doloremque laudantium, totam rem aperiam eaque ipsa quae ab illo inventore veritatis et quas.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":169,"style":"hlnk:"},{"offset":0,"length":169,"style":"hlnkt:wp"},{"offset":0,"length":169,"style":"textOutlineEnable:false"},{"offset":0,"length":169,"style":"opacity:1"},{"offset":0,"length":169,"style":"hlnke:true"},{"offset":0,"length":169,"style":"backgroundColor:unset"},{"offset":0,"length":169,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":169,"style":"textHighlightEnable:false"},{"offset":0,"length":169,"style":"textShadowEnable:false"},{"offset":0,"length":169,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1922]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1922c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:1922,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1922',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si1932:{
name:'Slide_Buttons_Widget_1',
type:1268,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1932c',
tag:'slide-buttons-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","justifyContent":"space-between","padding":"18px 0px 0px"}}}',
parentGroup:'si1092',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si1943',
t:29
}
,{
n:'si1965',
t:29
}
]
,
containerType:'slide-buttons',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","justifyContent":"space-between","padding":"18px 0px 0px"}}}',
option:'SLIDE_BUTTONS_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si1092',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si1932c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:1932,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1932',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ff0000',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si1943:{
name:'Button_19',
type:29,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1943c',
tag:'slide-buttons-previous-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"apq1h","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_default","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9cee9","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"30"}},"designOption":"SLIDE_PREVIOUS_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"01940.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"f52ei","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d5qdr","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"86kjl","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si1932',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToPreviousSlide(1961);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1943]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1943c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1943,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1943',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si1965:{
name:'Button_20',
type:29,
from:181,
to:270,
rp:0,
rpa:0,
mdi:'si1965c',
tag:'slide-buttons-next-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":true,"hover":true,"visited":false},"normal":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dqao3","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_default","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9493i","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"30"}},"designOption":"SLIDE_NEXT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"01962.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bc0hj","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cqvto","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"53asg","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si1932',
retainState:false,
immo:false,
apsn:'Slide388',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToNextSlide(1983);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[1965]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si1965c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:1965,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si1965',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide388:{
lb:'Blank 1',
id:388,
from:181,
to:270,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide388c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
accProps:{
}
,
si:[{
n:'si507',
t:1268
}
,{
n:'si1092',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
1961:{
ts:''
}
,
1983:{
ts:''
}

}

},
Slide388c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:388,
dn:'Slide388',
visible:'1'
},
si2102:{
name:'Hotspot_Widget_1',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2102c',
tag:'container-hotspot-widget',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-widget-body":true,"slide-item-next-button":true,"slide-item-prev-button":true,"slide-item-widget-instructions":true,"hotspot-widget-image":true,"hotspot-button":true,"callout-title":true,"callout-image":true,"callout-body":true},"canBeCard":false,"numberOfHotspots":{"value":4},"activeHotspot":{"value":3},"isForcedNavigationEnabled":true,"widgetLayout":{"value":"F"},"padding":{"top":40,"bottom":40,"left":4,"right":4},"designOptionStyles":{"all":{"flexDirection":"column"},"tablet":{},"mobile":{}},"appearanceProperties":{}}',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2110',
t:1250
}
,{
n:'si2120',
t:1250
}
,{
n:'si2130',
t:1250
}
,{
n:'si2140',
t:1268
}
,{
n:'si3034',
t:1268
}
]
,
containerType:'hotspot-widget',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-widget-body":true,"slide-item-next-button":true,"slide-item-prev-button":true,"slide-item-widget-instructions":true,"hotspot-widget-image":true,"hotspot-button":true,"callout-title":true,"callout-image":true,"callout-body":true},"canBeCard":false,"numberOfHotspots":{"value":4},"activeHotspot":{"value":3},"isForcedNavigationEnabled":true,"widgetLayout":{"value":"F"},"padding":{"top":40,"bottom":40,"left":4,"right":4},"designOptionStyles":{"all":{"flexDirection":"column"},"tablet":{},"mobile":{}},"appearanceProperties":{}}',
option:'DEFAULT_HOTSPOT_WIDGET_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2102c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2102,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2102',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#ffffff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2110:{
name:'Text_49',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2110c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2102',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"frnn0","text":"How do these directives affect public procurement?","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":50,"style":"hlnk:"},{"offset":0,"length":50,"style":"hlnkt:wp"},{"offset":0,"length":50,"style":"textOutlineEnable:false"},{"offset":0,"length":50,"style":"opacity:1"},{"offset":0,"length":50,"style":"hlnke:true"},{"offset":0,"length":50,"style":"backgroundColor:unset"},{"offset":0,"length":50,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":50,"style":"textHighlightEnable:false"},{"offset":0,"length":50,"style":"textShadowEnable:false"},{"offset":0,"length":50,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-heading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2110]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2110c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2110,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2110',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2120:{
name:'Text_50',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2120c',
tag:'slide-item-widget-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2102',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"1vttr","text":"Easier to participate, simpler to manage","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":40,"style":"hlnk:"},{"offset":0,"length":40,"style":"hlnkt:wp"},{"offset":0,"length":40,"style":"textOutlineEnable:false"},{"offset":0,"length":40,"style":"opacity:1"},{"offset":0,"length":40,"style":"hlnke:true"},{"offset":0,"length":40,"style":"backgroundColor:unset"},{"offset":0,"length":40,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":40,"style":"textHighlightEnable:false"},{"offset":0,"length":40,"style":"textShadowEnable:false"},{"offset":0,"length":40,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2120]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2120c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2120,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2120',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2130:{
name:'Text_51',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2130c',
tag:'slide-item-widget-instructions',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2102',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"f0oa2","text":"Select each hotspot to learn more.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":34,"style":"hlnk:"},{"offset":0,"length":34,"style":"hlnkt:wp"},{"offset":0,"length":34,"style":"textOutlineEnable:false"},{"offset":0,"length":34,"style":"opacity:1"},{"offset":0,"length":34,"style":"hlnke:true"},{"offset":0,"length":34,"style":"backgroundColor:unset"},{"offset":0,"length":34,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":34,"style":"textHighlightEnable:false"},{"offset":0,"length":34,"style":"textShadowEnable:false"},{"offset":0,"length":34,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2130]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2130c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2130,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2130',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2140:{
name:'Hotspot_Insertion_Area_1',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2140c',
tag:'container-hotspot-insertion-area',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"sizeNPos":{"height":768.375},"designOptionStyles":{"all":{"marginTop":"18px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2102',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2148',
t:1268
}
]
,
containerType:'container-hotspot-insertion-area',
widgetProps:'{"sizeNPos":{"height":768.375},"designOptionStyles":{"all":{"marginTop":"18px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2102',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2140c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2140,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2140',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2148:{
name:'Non_Responsive_1',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2148c',
tag:'container-non-responsive',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{}',
parentGroup:'si2140',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2156',
t:1268
}
,{
n:'si2179',
t:1268
}
,{
n:'si2303',
t:1268
}
,{
n:'si2427',
t:1268
}
,{
n:'si2551',
t:1268
}
,{
n:'si2675',
t:1268
}
,{
n:'si2799',
t:1268
}
,{
n:'si2923',
t:1268
}
,{
n:'si2944',
t:1268
}
,{
n:'si2962',
t:1268
}
,{
n:'si2980',
t:1268
}
,{
n:'si2998',
t:1268
}
,{
n:'si3016',
t:1268
}
]
,
containerType:'non-responsive',
widgetProps:'{}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2140',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2148c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2148,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2148',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2156:{
name:'Hotspot_widget_image_container_1',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2156c',
tag:'container-hotspot-widget-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2167',
t:15
}
]
,
containerType:'image-container',
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2156c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2156,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2156',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2167:{
name:'map-5624038_1280(3)',
type:15,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2167c',
tag:'hotspot-widget-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'theme_image_greyscale',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2156',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'saturation',
ift:'Greyscale',
ifi:100,
iff:{
bc:'#000000',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1110,
irh:680,
w:1110,
h:680,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2167]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2167c:{
b:[0,0,1110,680],
fh:false,
fw:false,
uid:2167,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'129.321%',
h:'116.283%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'129.321%',
h:'116.283%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'129.321%',
h:'116.283%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03192.png',
dn:'si2167',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1111,681],
vb:[-1,-1,1111,681]
},
si2179:{
name:'Callout_group_1',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2179c',
tag:'container-callout',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"BOTTOM","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2187',
t:1268
}
,{
n:'si2209',
t:1268
}
]
,
containerType:'container-callout',
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"BOTTOM","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2179c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2179,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2179',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2187:{
name:'Callout_Image_1',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2187c',
tag:'container-callout-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2179',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2197',
t:15
}
]
,
containerType:'image-container',
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2179',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2187c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2187,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2187',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2197:{
name:'AdobeStock_317770623',
type:15,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2197c',
tag:'callout-image0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2187',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:5400,
irh:3602,
w:5400,
h:3602,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2197]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2197c:{
b:[0,0,5400,3602],
fh:false,
fw:false,
uid:2197,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03080.jpeg',
dn:'si2197',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,5401,3603],
vb:[-1,-1,5401,3603]
},
si2209:{
name:'Paragraph_6',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2209c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2179',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2217',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
option:'HOTSPOT_WIDGET_PARAGRAPH_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2179',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2209c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2209,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2209',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2217:{
name:'Paragraph_Card_1',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2217c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si2209',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2225',
t:1250
}
,{
n:'si2235',
t:1250
}
,{
n:'si2245',
t:1250
}
,{
n:'si2255',
t:29
}
,{
n:'si2271',
t:29
}
,{
n:'si2287',
t:29
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2209',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2217c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2217,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2217',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2225:{
name:'Text_52',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2225c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2217',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"b6pv5","text":"Free movement of goods and services","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":35,"style":"hlnk:"},{"offset":0,"length":35,"style":"hlnkt:wp"},{"offset":0,"length":35,"style":"textOutlineEnable:false"},{"offset":0,"length":35,"style":"opacity:1"},{"offset":0,"length":35,"style":"hlnke:true"},{"offset":0,"length":35,"style":"backgroundColor:unset"},{"offset":0,"length":35,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":35,"style":"textHighlightEnable:false"},{"offset":0,"length":35,"style":"textShadowEnable:false"},{"offset":0,"length":35,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2225]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2225c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2225,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2225',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2235:{
name:'Text_53',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2235c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2217',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"4l62q","text":"Haworthia","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2235]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2235c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2235,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2235',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2245:{
name:'Text_54',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2245c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2217',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"co76m","text":"The new rules simplified public procurement procedures and made them simpler, promoting the free movements of goods and services","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":128,"style":"textShadowX:0px"},{"offset":0,"length":128,"style":"fontStretch:normal"},{"offset":0,"length":128,"style":"fontType:regular"},{"offset":0,"length":128,"style":"color:#666666"},{"offset":0,"length":128,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":128,"style":"textShadowY:4px"},{"offset":0,"length":128,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":128,"style":"lineHeight:135%"},{"offset":0,"length":128,"style":"letterSpacing:0%"},{"offset":0,"length":128,"style":"textHighlightEnable:false"},{"offset":0,"length":128,"style":"textTransform:none"},{"offset":0,"length":128,"style":"textShadowOpacity:none"},{"offset":0,"length":128,"style":"textDecoration:none"},{"offset":0,"length":128,"style":"borderBottomStyle:none"},{"offset":0,"length":128,"style":"textShadowEnable:false"},{"offset":0,"length":128,"style":"hlnk:"},{"offset":0,"length":128,"style":"fontWeight:normal"},{"offset":0,"length":128,"style":"textShadowBlur:8px"},{"offset":0,"length":128,"style":"fontFamily:Arial"},{"offset":0,"length":128,"style":"overridden:false"},{"offset":0,"length":128,"style":"defaultTextShadow:none"},{"offset":0,"length":128,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":128,"style":"desktop-fontSize:18"},{"offset":0,"length":128,"style":"fontStyle:normal"},{"offset":0,"length":128,"style":"hlnkt:wp"},{"offset":0,"length":128,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":128,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":128,"style":"textOutlineEnable:false"},{"offset":0,"length":128,"style":"opacity:1"},{"offset":0,"length":128,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":128,"style":"mobile-fontSize:16"},{"offset":0,"length":128,"style":"hlnke:true"},{"offset":0,"length":128,"style":"backgroundColor:unset"},{"offset":0,"length":128,"style":"textShadow:none"},{"offset":0,"length":128,"style":"tablet-fontSize:16"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-6","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2245]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2245c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2245,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2245',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2255:{
name:'Button_24',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2255c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6g94j","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"djvc4","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"fmil0","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9dph0","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1fjhv","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2217',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2255]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2255c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2255,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2255',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2271:{
name:'Button_25',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2271c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5rkeu","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"auqd6","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9ejk0","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9mag","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"enr3k","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2217',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2271]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2271c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2271,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2271',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2287:{
name:'Button_26',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2287c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d3ieo","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cehqm","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1bnvg","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"fhfa9","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"okbl","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2217',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2287]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2287c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2287,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2287',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2303:{
name:'Callout_group_2',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2303c',
tag:'container-callout',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"TOP","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2311',
t:1268
}
,{
n:'si2333',
t:1268
}
]
,
containerType:'container-callout',
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"TOP","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2303c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2303,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2303',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2311:{
name:'Callout_Image_2',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2311c',
tag:'container-callout-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2303',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2321',
t:15
}
]
,
containerType:'image-container',
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2303',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2311c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2311,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2311',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2321:{
name:'AdobeStock_166179922',
type:15,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2321c',
tag:'callout-image1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2311',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:5760,
irh:3240,
w:5760,
h:3240,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2321]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2321c:{
b:[0,0,5760,3240],
fh:false,
fw:false,
uid:2321,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03083.jpeg',
dn:'si2321',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,5761,3241],
vb:[-1,-1,5761,3241]
},
si2333:{
name:'Paragraph_7',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2333c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2303',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2341',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
option:'HOTSPOT_WIDGET_PARAGRAPH_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2303',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2333c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2333,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2333',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2341:{
name:'Paragraph_Card_2',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2341c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si2333',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2349',
t:1250
}
,{
n:'si2359',
t:1250
}
,{
n:'si2369',
t:1250
}
,{
n:'si2379',
t:29
}
,{
n:'si2395',
t:29
}
,{
n:'si2411',
t:29
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2333',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2341c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2341,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2341',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2349:{
name:'Text_55',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2349c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2341',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"4v3d0","text":"SME Participation","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"textOutlineEnable:false"},{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"hlnke:true"},{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2349]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2349c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2349,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2349',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2359:{
name:'Text_56',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2359c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2341',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"a8tca","text":"Haworthia","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2359]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2359c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2359,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2359',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2369:{
name:'Text_57',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2369c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2341',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"7puvd","text":"They limited turnover requirements and enabled tender lots enabling participation by SMEs.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":90,"style":"opacity:1"},{"offset":0,"length":90,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":90,"style":"mobile-fontSize:16"},{"offset":0,"length":90,"style":"hlnke:true"},{"offset":0,"length":90,"style":"backgroundColor:unset"},{"offset":0,"length":90,"style":"textShadow:none"},{"offset":0,"length":90,"style":"tablet-fontSize:16"},{"offset":0,"length":90,"style":"textShadowX:0px"},{"offset":0,"length":90,"style":"fontStretch:normal"},{"offset":0,"length":90,"style":"fontType:regular"},{"offset":0,"length":90,"style":"color:#666666"},{"offset":0,"length":90,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":90,"style":"textShadowY:4px"},{"offset":0,"length":90,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":90,"style":"lineHeight:135%"},{"offset":0,"length":90,"style":"letterSpacing:0%"},{"offset":0,"length":90,"style":"textHighlightEnable:false"},{"offset":0,"length":90,"style":"textTransform:none"},{"offset":0,"length":90,"style":"textShadowOpacity:none"},{"offset":0,"length":90,"style":"textDecoration:none"},{"offset":0,"length":90,"style":"borderBottomStyle:none"},{"offset":0,"length":90,"style":"textShadowEnable:false"},{"offset":0,"length":90,"style":"hlnk:"},{"offset":0,"length":90,"style":"fontWeight:normal"},{"offset":0,"length":90,"style":"textShadowBlur:8px"},{"offset":0,"length":90,"style":"fontFamily:Arial"},{"offset":0,"length":90,"style":"overridden:false"},{"offset":0,"length":90,"style":"defaultTextShadow:none"},{"offset":0,"length":90,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":90,"style":"desktop-fontSize:18"},{"offset":0,"length":90,"style":"fontStyle:normal"},{"offset":0,"length":90,"style":"hlnkt:wp"},{"offset":0,"length":90,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":90,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":90,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-6","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2369]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2369c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2369,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2369',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2379:{
name:'Button_27',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2379c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1r5n","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3655n","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8kg0p","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9vbhc","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"65kj3","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2341',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2379]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2379c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2379,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2379',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2395:{
name:'Button_28',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2395c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6bhkt","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3u9u0","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8u6o0","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7qe11","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3ggnh","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2341',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2395]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2395c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2395,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2395',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2411:{
name:'Button_29',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2411c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9l2op","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a21gt","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"936de","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4es2d","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5s356","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2341',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2411]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2411c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2411,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2411',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2427:{
name:'Callout_group_3',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2427c',
tag:'container-callout',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"TOP","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2435',
t:1268
}
,{
n:'si2457',
t:1268
}
]
,
containerType:'container-callout',
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"TOP","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2427c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2427,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2427',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2435:{
name:'Callout_Image_3',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2435c',
tag:'container-callout-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2427',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2445',
t:15
}
]
,
containerType:'image-container',
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2427',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2435c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2435,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2435',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2445:{
name:'AdobeStock_284867628',
type:15,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2445c',
tag:'callout-image2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2435',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:2000,
irh:1333,
w:2000,
h:1333,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2445]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2445c:{
b:[0,0,2000,1333],
fh:false,
fw:false,
uid:2445,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03086.jpeg',
dn:'si2445',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,2001,1334],
vb:[-1,-1,2001,1334]
},
si2457:{
name:'Paragraph_8',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2457c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2427',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2465',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
option:'HOTSPOT_WIDGET_PARAGRAPH_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2427',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2457c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2457,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2457',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2465:{
name:'Paragraph_Card_3',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2465c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si2457',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2473',
t:1250
}
,{
n:'si2483',
t:1250
}
,{
n:'si2493',
t:1250
}
,{
n:'si2503',
t:29
}
,{
n:'si2519',
t:29
}
,{
n:'si2535',
t:29
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2457',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2465c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2465,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2465',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2473:{
name:'Text_58',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2473c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"f1f94","text":"Self Declaration for Qualification","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":34,"style":"hlnk:"},{"offset":0,"length":34,"style":"hlnkt:wp"},{"offset":0,"length":34,"style":"textOutlineEnable:false"},{"offset":0,"length":34,"style":"opacity:1"},{"offset":0,"length":34,"style":"hlnke:true"},{"offset":0,"length":34,"style":"backgroundColor:unset"},{"offset":0,"length":34,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":34,"style":"textHighlightEnable:false"},{"offset":0,"length":34,"style":"textShadowEnable:false"},{"offset":0,"length":34,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2473]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2473c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2473,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2473',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2483:{
name:'Text_59',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2483c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"cg9p7","text":"Aloe Vera","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"overridden:false"},{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2483]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2483c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2483,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2483',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2493:{
name:'Text_60',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2493c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"2cv0i","text":"They included a self declaration of exclusion and qualification criteria for suppliers, promoting efficiency","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":108,"style":"fontFamily:Arial"},{"offset":0,"length":108,"style":"overridden:false"},{"offset":0,"length":108,"style":"defaultTextShadow:none"},{"offset":0,"length":108,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":108,"style":"desktop-fontSize:18"},{"offset":0,"length":108,"style":"fontStyle:normal"},{"offset":0,"length":108,"style":"hlnkt:wp"},{"offset":0,"length":108,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":108,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":108,"style":"textOutlineEnable:false"},{"offset":0,"length":108,"style":"opacity:1"},{"offset":0,"length":108,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":108,"style":"mobile-fontSize:16"},{"offset":0,"length":108,"style":"hlnke:true"},{"offset":0,"length":108,"style":"backgroundColor:unset"},{"offset":0,"length":108,"style":"textShadow:none"},{"offset":0,"length":108,"style":"tablet-fontSize:16"},{"offset":0,"length":108,"style":"textShadowX:0px"},{"offset":0,"length":108,"style":"fontStretch:normal"},{"offset":0,"length":108,"style":"fontType:regular"},{"offset":0,"length":108,"style":"color:#666666"},{"offset":0,"length":108,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":108,"style":"textShadowY:4px"},{"offset":0,"length":108,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":108,"style":"lineHeight:135%"},{"offset":0,"length":108,"style":"letterSpacing:0%"},{"offset":0,"length":108,"style":"textHighlightEnable:false"},{"offset":0,"length":108,"style":"textTransform:none"},{"offset":0,"length":108,"style":"textShadowOpacity:none"},{"offset":0,"length":108,"style":"textDecoration:none"},{"offset":0,"length":108,"style":"borderBottomStyle:none"},{"offset":0,"length":108,"style":"textShadowEnable:false"},{"offset":0,"length":108,"style":"hlnk:"},{"offset":0,"length":108,"style":"fontWeight:normal"},{"offset":0,"length":108,"style":"textShadowBlur:8px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-6","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2493]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2493c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2493,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2493',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2503:{
name:'Button_30',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2503c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6gojh","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1dpia","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"e2qrt","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"82ab9","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ciq2m","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2503]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2503c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2503,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2503',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2519:{
name:'Button_31',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2519c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"70c35","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"eccs6","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dgnud","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"elev0","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1n6nl","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2519]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2519c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2519,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2519',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2535:{
name:'Button_32',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2535c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4pok2","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4hrfk","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5oalt","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"43q8f","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dnuj9","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2465',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2535]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2535c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2535,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2535',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2551:{
name:'Callout_group_4',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2551c',
tag:'container-callout',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"BOTTOM","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2559',
t:1268
}
,{
n:'si2581',
t:1268
}
]
,
containerType:'container-callout',
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"BOTTOM","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2551c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2551,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2551',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2559:{
name:'Callout_Image_4',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2559c',
tag:'container-callout-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2551',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2569',
t:15
}
]
,
containerType:'image-container',
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2551',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2559c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2559,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2559',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2569:{
name:'AdobeStock_100928873',
type:15,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2569c',
tag:'callout-image3',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2559',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:5483,
irh:3655,
w:5483,
h:3655,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2569]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2569c:{
b:[0,0,5483,3655],
fh:false,
fw:false,
uid:2569,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/03089.jpeg',
dn:'si2569',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,5484,3656],
vb:[-1,-1,5484,3656]
},
si2581:{
name:'Paragraph_9',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2581c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2551',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2589',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
option:'HOTSPOT_WIDGET_PARAGRAPH_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2551',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2581c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2581,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2581',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2589:{
name:'Paragraph_Card_4',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2589c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si2581',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2597',
t:1250
}
,{
n:'si2607',
t:1250
}
,{
n:'si2617',
t:1250
}
,{
n:'si2627',
t:29
}
,{
n:'si2643',
t:29
}
,{
n:'si2659',
t:29
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2581',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2589c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2589,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2589',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2597:{
name:'Text_61',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2597c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2589',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"20c1s","text":"Policy Strategy","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2597]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2597c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2597,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2597',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2607:{
name:'Text_62',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2607c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2589',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"fgg9b","text":"Sunset Jade","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2607]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2607c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2607,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2607',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2617:{
name:'Text_63',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2617c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2589',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"2ssun","text":"Public procurement became a policy strategy instrument, allowing the implementation of e.g., environmental policies and those around social integration and innovation.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":167,"style":"textShadowOpacity:none"},{"offset":0,"length":167,"style":"textDecoration:none"},{"offset":0,"length":167,"style":"borderBottomStyle:none"},{"offset":0,"length":167,"style":"textShadowEnable:false"},{"offset":0,"length":167,"style":"hlnk:"},{"offset":0,"length":167,"style":"fontWeight:normal"},{"offset":0,"length":167,"style":"textShadowBlur:8px"},{"offset":0,"length":167,"style":"fontFamily:Arial"},{"offset":0,"length":167,"style":"overridden:false"},{"offset":0,"length":167,"style":"defaultTextShadow:none"},{"offset":0,"length":167,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":167,"style":"desktop-fontSize:18"},{"offset":0,"length":167,"style":"fontStyle:normal"},{"offset":0,"length":167,"style":"hlnkt:wp"},{"offset":0,"length":167,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":167,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":167,"style":"textOutlineEnable:false"},{"offset":0,"length":167,"style":"opacity:1"},{"offset":0,"length":167,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":167,"style":"mobile-fontSize:16"},{"offset":0,"length":167,"style":"hlnke:true"},{"offset":0,"length":167,"style":"backgroundColor:unset"},{"offset":0,"length":167,"style":"textShadow:none"},{"offset":0,"length":167,"style":"tablet-fontSize:16"},{"offset":0,"length":167,"style":"textShadowX:0px"},{"offset":0,"length":167,"style":"fontStretch:normal"},{"offset":0,"length":167,"style":"fontType:regular"},{"offset":0,"length":167,"style":"color:#666666"},{"offset":0,"length":167,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":167,"style":"textShadowY:4px"},{"offset":0,"length":167,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":167,"style":"lineHeight:135%"},{"offset":0,"length":167,"style":"letterSpacing:0%"},{"offset":0,"length":167,"style":"textHighlightEnable:false"},{"offset":0,"length":167,"style":"textTransform:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-6","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2617]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2617c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:2617,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2617',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si2627:{
name:'Button_33',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2627c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4bkr1","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7069f","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"94c1n","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"eq30i","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1dlbp","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2589',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2627]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2627c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2627,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2627',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2643:{
name:'Button_34',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2643c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3l0p5","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3toin","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3d3d2","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3i1k7","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bs1k1","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2589',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2643]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2643c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2643,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2643',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2659:{
name:'Button_35',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2659c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"10kgg","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6ar8r","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a5jo3","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"148ra","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"fcr9e","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2589',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2659]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2659c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2659,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2659',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2675:{
name:'Callout_group_5',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2675c',
tag:'container-callout',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"TOP","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2683',
t:1268
}
,{
n:'si2705',
t:1268
}
]
,
containerType:'container-callout',
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"TOP","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2675c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2675,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2675',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2683:{
name:'Callout_Image_5',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2683c',
tag:'container-callout-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2675',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2693',
t:15
}
]
,
containerType:'image-container',
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2675',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2683c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2683,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2683',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2693:{
name:'Callout_image_5',
type:15,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2693c',
tag:'callout-image4',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2683',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:240,
irh:135,
w:240,
h:135,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2693]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2693c:{
b:[0,0,240,135],
fh:false,
fw:false,
uid:2693,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/02691.png',
dn:'si2693',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,241,136],
vb:[-1,-1,241,136]
},
si2705:{
name:'Paragraph_10',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2705c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2675',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2713',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
option:'HOTSPOT_WIDGET_PARAGRAPH_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2675',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2705c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2705,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2705',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2713:{
name:'Paragraph_Card_5',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2713c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si2705',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2721',
t:1250
}
,{
n:'si2731',
t:1250
}
,{
n:'si2741',
t:1250
}
,{
n:'si2751',
t:29
}
,{
n:'si2767',
t:29
}
,{
n:'si2783',
t:29
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2705',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2713c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2713,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2713',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2721:{
name:'Text_64',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2721c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2713',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"d4tb5","text":"Melocactus","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"overridden:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2721]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2721c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2721,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2721',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2731:{
name:'Text_65',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2731c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2713',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"26adn","text":"Melocactus","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2731]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2731c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2731,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2731',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2741:{
name:'Text_66',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2741c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2713',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"a268g","text":"Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat pariatur.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":96,"style":"hlnk:"},{"offset":0,"length":96,"style":"hlnkt:wp"},{"offset":0,"length":96,"style":"textOutlineEnable:false"},{"offset":0,"length":96,"style":"opacity:1"},{"offset":0,"length":96,"style":"hlnke:true"},{"offset":0,"length":96,"style":"backgroundColor:unset"},{"offset":0,"length":96,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":96,"style":"textHighlightEnable:false"},{"offset":0,"length":96,"style":"textShadowEnable:false"},{"offset":0,"length":96,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2741]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2741c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2741,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2741',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2751:{
name:'Button_36',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2751c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ejlmd","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2s63","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"slha","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6h37j","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bavt8","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2713',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2751]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2751c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2751,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2751',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2767:{
name:'Button_37',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2767c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2f3fu","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"38kn4","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ac3u9","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"csker","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8mjse","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2713',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2767]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2767c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2767,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2767',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2783:{
name:'Button_38',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2783c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4uimd","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9mmlm","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3n08k","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"todj","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1bfe","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2713',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2783]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2783c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2783,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2783',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2799:{
name:'Callout_group_6',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2799c',
tag:'container-callout',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"TOP","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2807',
t:1268
}
,{
n:'si2829',
t:1268
}
]
,
containerType:'container-callout',
widgetProps:'{"visibilityInfo":{"hotspot-button":true,"callout-image":true,"callout-title":true,"callout-body":true,"card":true},"calloutRevealDirection":{"value":"TOP","isOverridden":false},"alignment":{"hotspot-button":"LEFT","callout-image":"LEFT","callout-title":"LEFT","callout-body":"LEFT"},"canBeCard":true,"calloutRevealCursorEvent":{"value":"CLICK"},"sizeNPos":{"width":"240"},"childNodesCustomStyles":{"cp-hotspot-widget-paragraph":{"all":{},"tablet":{},"mobile":{}}},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":1,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"type":1,"color":"var(--c3)"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2799c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2799,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2799',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2807:{
name:'Callout_Image_6',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2807c',
tag:'container-callout-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2799',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2817',
t:15
}
]
,
containerType:'image-container',
widgetProps:'{"canBeCard":false,"imageBehavior":"IG_SCALE","imageHeight":100,"imageAspectRatio":1.7,"designOptionStyles":{"all":{"height":"135px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2799',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2807c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2807,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2807',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2817:{
name:'Callout_image_6',
type:15,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2817c',
tag:'callout-image5',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2807',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:240,
irh:135,
w:240,
h:135,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2817]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2817c:{
b:[0,0,240,135],
fh:false,
fw:false,
uid:2817,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'24.691%',
h:'22.204%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/02815.png',
dn:'si2817',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,241,136],
vb:[-1,-1,241,136]
},
si2829:{
name:'Paragraph_11',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2829c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
parentGroup:'si2799',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2837',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"padding":{"top":50,"bottom":50,"left":10,"right":10},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","paddingTop":"16px","paddingBottom":"16px","paddingLeft":"20px","paddingRight":"20px"},"tablet":{},"mobile":{}}}',
option:'HOTSPOT_WIDGET_PARAGRAPH_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2799',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2829c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2829,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2829',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2837:{
name:'Paragraph_Card_6',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2837c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si2829',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2845',
t:1250
}
,{
n:'si2855',
t:1250
}
,{
n:'si2865',
t:1250
}
,{
n:'si2875',
t:29
}
,{
n:'si2891',
t:29
}
,{
n:'si2907',
t:29
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2829',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si2837c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2837,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2837',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2845:{
name:'Text_67',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2845c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2837',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"875n8","text":"Mammillaria","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2845]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2845c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2845,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2845',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2855:{
name:'Text_68',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2855c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2837',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6bj06","text":"Mammillaria","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2855]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2855c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2855,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2855',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2865:{
name:'Text_69',
type:1250,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2865c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si2837',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"a1cem","text":"Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat pariatur.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":96,"style":"textOutlineEnable:false"},{"offset":0,"length":96,"style":"opacity:1"},{"offset":0,"length":96,"style":"hlnke:true"},{"offset":0,"length":96,"style":"backgroundColor:unset"},{"offset":0,"length":96,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":96,"style":"textHighlightEnable:false"},{"offset":0,"length":96,"style":"textShadowEnable:false"},{"offset":0,"length":96,"style":"overridden:false"},{"offset":0,"length":96,"style":"hlnk:"},{"offset":0,"length":96,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-body-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2865]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2865c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:2865,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2865',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si2875:{
name:'Button_39',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2875c',
tag:'slide-item-buttons0',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5nmrf","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7ehet","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3ia9r","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6p2vv","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"csjcj","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2837',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2875]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2875c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2875,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2875',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2891:{
name:'Button_40',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2891c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dle81","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3f9oe","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cjcos","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"79chn","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6ahrg","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2837',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2891]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2891c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2891,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2891',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2907:{
name:'Button_41',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2907c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"f7apb","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1nngp","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6q8ul","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9lr6h","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"58qph","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si2837',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2907]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2907c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:2907,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2907',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si2923:{
name:'Hotspot_Button_Container_1',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2923c',
tag:'container-hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":360.2548659900478,"top":310.11649841175205,"containerWidth":1366},"buttonState":{"value":"moved"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2934',
t:652
}
]
,
containerType:'hotspot-svg-container',
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":360.2548659900478,"top":310.11649841175205,"containerWidth":1366},"buttonState":{"value":"moved"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
option:'DEFAULT_HOTSPOT_BUTTON_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2923c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2923,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2923',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2934:{
name:'Hotspot_default',
type:652,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si2934c',
tag:'hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","normal":{"opacity":100,"fillEnable":true,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"selected":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_selected","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"disabled":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_disabled","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"hover":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_hover","shadowEnable":true,"strokeEnable":false,"fillEnable":true,"fillType":1}},"visited":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_visited","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si2923',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2934]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2934c:{
b:[667,368,699,400],
fh:false,
fw:false,
uid:2934,
iso:false,
css:{
360:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2934',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/02931.svg',
wofh:32,
wofw:32,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[666,367,700,401],
vb:[666,367,700,401]
},
si2944:{
name:'Hotspot_Button_Container_2',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2944c',
tag:'container-hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":582.4527563547141,"top":392.6840272631524,"containerWidth":1366},"buttonState":{"value":"moved"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2952',
t:652
}
]
,
containerType:'hotspot-svg-container',
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":582.4527563547141,"top":392.6840272631524,"containerWidth":1366},"buttonState":{"value":"moved"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
option:'DEFAULT_HOTSPOT_BUTTON_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2944c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2944,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2944',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2952:{
name:'Hotspot_default_1',
type:652,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si2952c',
tag:'hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","normal":{"opacity":100,"fillEnable":true,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"selected":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_selected","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"disabled":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_disabled","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"hover":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_hover","shadowEnable":true,"strokeEnable":false,"fillEnable":true,"fillType":1}},"visited":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_visited","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si2944',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2952]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2952c:{
b:[667,368,699,400],
fh:false,
fw:false,
uid:2952,
iso:false,
css:{
360:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2952',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/02931.svg',
wofh:32,
wofw:32,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[666,367,700,401],
vb:[666,367,700,401]
},
si2962:{
name:'Hotspot_Button_Container_3',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2962c',
tag:'container-hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":775.5431922681266,"top":555.9809338374191,"containerWidth":1366},"buttonState":{"value":"moved"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2970',
t:652
}
]
,
containerType:'hotspot-svg-container',
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":775.5431922681266,"top":555.9809338374191,"containerWidth":1366},"buttonState":{"value":"moved"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
option:'DEFAULT_HOTSPOT_BUTTON_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2962c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2962,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2962',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2970:{
name:'Hotspot_default_2',
type:652,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si2970c',
tag:'hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","normal":{"opacity":100,"fillEnable":true,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"selected":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_selected","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"disabled":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_disabled","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"hover":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_hover","shadowEnable":true,"strokeEnable":false,"fillEnable":true,"fillType":1}},"visited":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_visited","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si2962',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2970]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2970c:{
b:[667,368,699,400],
fh:false,
fw:false,
uid:2970,
iso:false,
css:{
360:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2970',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/02931.svg',
wofh:32,
wofw:32,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[666,367,700,401],
vb:[666,367,700,401]
},
si2980:{
name:'Hotspot_Button_Container_4',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2980c',
tag:'container-hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":850.1864822693547,"top":271.8431603250415,"containerWidth":1366},"buttonState":{"value":"moved"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si2988',
t:652
}
]
,
containerType:'hotspot-svg-container',
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":850.1864822693547,"top":271.8431603250415,"containerWidth":1366},"buttonState":{"value":"moved"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
option:'DEFAULT_HOTSPOT_BUTTON_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2980c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2980,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2980',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si2988:{
name:'Hotspot_default_3',
type:652,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2988c',
tag:'hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","normal":{"opacity":100,"fillEnable":true,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1},"appearenceProperties":{"fill":{"color":"#163EE5FF"},"shadow":{},"stroke":{}}},"selected":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_selected","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"disabled":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_disabled","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"hover":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_hover","shadowEnable":true,"strokeEnable":false,"fillEnable":true,"fillType":1}},"visited":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_visited","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si2980',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[2988]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si2988c:{
b:[667,368,699,400],
fh:false,
fw:false,
uid:2988,
iso:false,
css:{
360:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si2988',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/02931.svg',
wofh:32,
wofw:32,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[666,367,700,401],
vb:[666,367,700,401]
},
si2998:{
name:'Hotspot_Button_Container_5',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si2998c',
tag:'container-hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":1366,"top":461.025},"buttonState":{"value":"initial"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3006',
t:652
}
]
,
containerType:'hotspot-svg-container',
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":1366,"top":461.025},"buttonState":{"value":"initial"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
option:'DEFAULT_HOTSPOT_BUTTON_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si2998c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:2998,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si2998',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3006:{
name:'Hotspot_default_4',
type:652,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si3006c',
tag:'hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","normal":{"opacity":100,"fillEnable":true,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"selected":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_selected","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"disabled":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_disabled","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"hover":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_hover","shadowEnable":true,"strokeEnable":false,"fillEnable":true,"fillType":1}},"visited":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_visited","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si2998',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3006]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3006c:{
b:[667,368,699,400],
fh:false,
fw:false,
uid:3006,
iso:false,
css:{
360:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3006',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/02931.svg',
wofh:32,
wofw:32,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[666,367,700,401],
vb:[666,367,700,401]
},
si3016:{
name:'Hotspot_Button_Container_6',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si3016c',
tag:'container-hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":1639.1999999999998,"top":461.025},"buttonState":{"value":"initial"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
parentGroup:'si2148',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3024',
t:652
}
]
,
containerType:'hotspot-svg-container',
widgetProps:'{"canBeCard":false,"sizeNPos":{"left":1639.1999999999998,"top":461.025},"buttonState":{"value":"initial"},"svgPath":"Hotspot_default.svg","designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","designOptionStyles":{}}',
option:'DEFAULT_HOTSPOT_BUTTON_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2148',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3016c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3016,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3016',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si3024:{
name:'Hotspot_default_5',
type:652,
from:271,
to:360,
rp:0,
rpa:0,
mdi:'si3024c',
tag:'hotspot-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:0,
isOverridden:false
}
]
,
widgetProps:'{"designOption":"DEFAULT_HOTSPOT_BUTTON_OPTION","stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","normal":{"opacity":100,"fillEnable":true,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"selected":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_selected","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"disabled":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_disabled","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}},"hover":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_hover","shadowEnable":true,"strokeEnable":false,"fillEnable":true,"fillType":1}},"visited":{"opacity":100,"shapePresetData":{"presetId":"cp_button_shape_1_solid_style_visited","shadowEnable":false,"strokeEnable":false,"fillEnable":true,"fillType":1}}}',
parentGroup:'si3016',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3024]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3024c:{
b:[667,368,699,400],
fh:false,
fw:false,
uid:3024,
iso:false,
css:{
360:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'68.621%',
t:'60.526%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'68.621%',
lhID:-1,
lvEID:0,
lvV:'60.526%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
dn:'si3024',
visible:1,
effectiveVi:1,
JSONEffectData:false,
woal:true,
woc:0,
wob:false,
wos:false,
wolanim:false,
wows:0,
woww:400,
wowh:400,
wort:0,
wou:'dr/02931.svg',
wofh:32,
wofw:32,
wosvgz:-1,
wosvg:true,
wosvgBoundBoxEnabled:true,
fa:100,
wosvgfill:[]
,
wosvgstroke:[]
,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[666,367,700,401],
vb:[666,367,700,401]
},
si3034:{
name:'Slide_Buttons_Widget_2',
type:1268,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si3034c',
tag:'slide-buttons-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","justifyContent":"space-between","padding":"18px 0px 0px"}}}',
parentGroup:'si2102',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si3042',
t:29
}
,{
n:'si3061',
t:29
}
]
,
containerType:'slide-buttons',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","justifyContent":"space-between","padding":"18px 0px 0px"}}}',
option:'SLIDE_BUTTONS_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si2102',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si3034c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:3034,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3034',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ff0000',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si3042:{
name:'Button_42',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si3042c',
tag:'slide-buttons-previous-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"58a2j","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_default","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"df5rb","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"30"}},"designOption":"SLIDE_PREVIOUS_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"01940.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"fbefk","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"b3m4t","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"as3mq","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si3034',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToPreviousSlide(3060);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3042]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3042c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3042,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3042',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si3061:{
name:'Button_43',
type:29,
from:631,
to:720,
rp:0,
rpa:0,
mdi:'si3061c',
tag:'slide-buttons-next-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":true,"hover":true,"visited":false},"normal":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"47b80","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_default","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"as5if","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"30"}},"designOption":"SLIDE_NEXT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"01962.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ep0ui","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9fao3","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cpuec","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si3034',
retainState:false,
immo:false,
apsn:'Slide1987',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToNextSlide(3079);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[3061]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si3061c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:3061,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si3061',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide1987:{
lb:'Blank 2',
id:1987,
from:631,
to:720,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide1987c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
accProps:{
}
,
si:[{
n:'si2102',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:'',
iph:{
3079:{
ts:''
}
,
3060:{
ts:''
}

}

},
Slide1987c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:1987,
dn:'Slide1987',
visible:'1'
},
si904:{
name:'Paragraph_4',
type:1268,
from:451,
to:540,
rp:0,
rpa:0,
mdi:'si904c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":40,"bottom":40,"left":15,"right":15},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide886',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si912',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"padding":{"top":40,"bottom":40,"left":15,"right":15},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'PARAGRAPH_AS_HEADING',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si904c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:904,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si904',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c7)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si912:{
name:'Paragraph_Group_4',
type:1268,
from:451,
to:540,
rp:0,
rpa:0,
mdi:'si912c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":true,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":50,"bottom":50,"left":50,"right":50},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":true,"color":"var(--c8)","size":2,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si904',
retainState:false,
immo:false,
apsn:'Slide886',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si920',
t:1250
}
,{
n:'si930',
t:1250
}
,{
n:'si940',
t:1250
}
,{
n:'si966',
t:29
}
,{
n:'si982',
t:29
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":true,"slide-item-body":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":50,"bottom":50,"left":50,"right":50},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"fill":{"enabled":true,"color":"#FFFFFFFF"},"border":{"enabled":true,"color":"var(--c8)","size":2,"type":0},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si904',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si912c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:912,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si912',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c3)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si920:{
name:'Text_13',
type:1250,
from:451,
to:540,
rp:0,
rpa:0,
mdi:'si920c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"marginBottom":"12px"},"tablet":{},"mobile":{}}}',
parentGroup:'si912',
retainState:false,
immo:false,
apsn:'Slide886',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"dd3nd","text":"Thresholds","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"fontFamily:Georgia"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"mobile-fontSize:60"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"textShadowBlur:8px"},{"offset":0,"length":10,"style":"overridden:false"},{"offset":0,"length":10,"style":"tablet-fontSize:72"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"letterSpacing:-4%"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"defaultTextShadow:none"},{"offset":0,"length":10,"style":"textShadow:none"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"fontType:regular"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"textShadowY:4px"},{"offset":0,"length":10,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":10,"style":"desktop-fontSize:80"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"textTransform:none"},{"offset":0,"length":10,"style":"color:#020C1C"},{"offset":0,"length":10,"style":"lineHeight:110%"},{"offset":0,"length":10,"style":"textShadowOpacity:none"},{"offset":0,"length":10,"style":"textDecoration:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"false","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[920]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si920c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:920,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si920',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si930:{
name:'Text_14',
type:1250,
from:361,
to:450,
rp:0,
rpa:0,
mdi:'si930c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"marginBottom":"12px"},"tablet":{},"mobile":{}}}',
parentGroup:'si912',
retainState:false,
immo:false,
apsn:'Slide886',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"cd8uh","text":"Minimised harmonised rules for tenders over a certain value","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":59,"style":"hlnkt:wp"},{"offset":0,"length":59,"style":"textOutlineEnable:false"},{"offset":0,"length":59,"style":"opacity:1"},{"offset":0,"length":59,"style":"hlnke:true"},{"offset":0,"length":59,"style":"backgroundColor:unset"},{"offset":0,"length":59,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":59,"style":"textHighlightEnable:false"},{"offset":0,"length":59,"style":"textShadowEnable:false"},{"offset":0,"length":59,"style":"overridden:false"},{"offset":0,"length":59,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-subheading-5","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[930]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si930c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:930,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si930',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si940:{
name:'Text_15',
type:1250,
from:361,
to:450,
rp:0,
rpa:0,
mdi:'si940c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"marginBottom":"20px"},"tablet":{},"mobile":{}}}',
parentGroup:'si912',
retainState:false,
immo:false,
apsn:'Slide886',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"s6l6","text":"EU law sets minimum harmonised rules for tenders whose monetary value exceeds a certain amount and which are presumed to be of cross-border interest. The European rules ensure that the award of contracts of higher value for the provision of public goods and services must be fair, equitable, transparent and non-discriminatory. For tenders of lower value however, national rules apply, which nevertheless must respect general principles of EU law.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":447,"style":"hlnk:"},{"offset":0,"length":447,"style":"hlnkt:wp"},{"offset":0,"length":447,"style":"textOutlineEnable:false"},{"offset":0,"length":447,"style":"opacity:1"},{"offset":0,"length":447,"style":"hlnke:true"},{"offset":0,"length":447,"style":"backgroundColor:unset"},{"offset":0,"length":447,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":447,"style":"textHighlightEnable:false"},{"offset":0,"length":447,"style":"textShadowEnable:false"},{"offset":0,"length":447,"style":"overridden:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-body-2"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[940]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si940c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:940,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si940',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si966:{
name:'Button_14',
type:29,
from:91,
to:180,
rp:0,
rpa:0,
mdi:'si966c',
tag:'slide-item-buttons1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8kl4a","text":"LET’S BEGIN","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"b3dgl","text":"LET’S BEGIN","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"esdcb","text":"LET’S BEGIN","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bgtfd","text":"LET’S BEGIN","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"abe3v","text":"LET’S BEGIN","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si912',
retainState:false,
immo:false,
apsn:'Slide886',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[966]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si966c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:966,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si966',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si982:{
name:'Button_15',
type:29,
from:91,
to:180,
rp:0,
rpa:0,
mdi:'si982c',
tag:'slide-item-buttons2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"currentState":"normal","iconProps":{"srcPath":"0553.svg","size":"medium","position":0,"offset":0},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"784i4","text":"LET’S BEGIN","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"b4cke","text":"LET’S BEGIN","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"365pn","text":"LET’S BEGIN","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"bcttg","text":"LET’S BEGIN","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"act12","text":"LET’S BEGIN","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"textShadowY:0px"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":11,"style":"textShadowBlur:0px"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"overridden:false"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"textShadowColor:ffffff00"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldDesignOptionHiddenInPI":true,"designOption":"DEFAULT_BUTTON_ITEM_OPTION","shapeData":{"type":"rect","attributes":{"rx":"20"}}}',
parentGroup:'si912',
retainState:false,
immo:false,
apsn:'Slide886',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[982]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si982c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:982,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si982',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide886:{
lb:'Title and text 1',
id:886,
from:451,
to:540,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide886c',
st:'Normal Slide',
sk:'Title and Text',
slideTag:'title-text-slide',
type:30,
accProps:{
}
,
si:[{
n:'si904',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide886c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:886,
dn:'Slide886',
visible:'1'
},
quizzingData:{
allowBackwardMovement:true,
allowReviewMode:true,
reviewShowAnswers:true,
it:false,
firstSlideInQuiz:-1,
lastSlideInQuiz:-1,
quizScopeEndSlide:-1,
maxScore:0,
minScore:0,
maxPretestScore:0,
numQuestionsInQuiz:0,
numQuizAttemptsAllowed:1,
passingScore:0,
quizInfoCurrentAttempt:0,
quizInfoPercentScored:0,
quizMandateLevel:0,
quizID:199,
questionPoolsInitialized:true,
quizInfoAttempts:1,
quizInfoLastSlidePointScored:0,
quizInfoMaxAttemptsOnCurrentQuestion:1,
quizInfoPassFail:0,
quizInfoPointsPerQuestionSlide:0,
quizInfoPointsScored:0,
quizInfoQuizPassPercent:80,
quizInfoQuizPassPoints:0,
quizInfoTotalCorrectAnswers:0,
quizInfoTotalProjectPoints:0,
quizInfoTotalQuestionsPerProject:0,
quizInfoTotalQuizPoints:0,
quizInfoTotalUnansweredQuestions:0,
reportingEnabled:false,
submitAll:false,
hidePlaybarInQuiz:false,
quizBranchAware:false,
passFailPassingScoreTypeInPrecent:true,
passFailPassingScoreValue:80,
showRetake:false,
showReviewButtons:true,
oid:'$$OBJECTIVE_ID',
quizVariableVsIdMap:{
learnerId:'var346',
learnerName:'var347',
isInQuizScope:'var368',
isInReviewMode:'var369',
quizInfoPercentScored:'var370',
quizInfoAttempts:'var371',
quizInfoPassFail:'var372',
score:'var373',
quizInfoQuizPassPercent:'var374',
passingScore:'var375',
quizInfoTotalCorrectAnswers:'var376',
maxScore:'var377',
quizInfoTotalQuestionsPerProject:'var378',
quizInfoTotalUnansweredQuestions:'var379',
quizInfoAnswerChoice:'var380',
quizInfoPreviousQuestionScore:'var381',
questionInfoMaxAttempts:'var382',
questionInfoNegativePoints:'var383',
questionInfoPointsAssigned:'var384'
}

},
var346var346:{
vid:346,
name:'LMS.LearnerID',
vv:'',
vvt:2,
vt:0
},
var347var347:{
vid:347,
name:'LMS.LearnerName',
vv:'',
vvt:2,
vt:0
},
var348var348:{
vid:348,
name:'LMS.CourseName',
vv:'',
vvt:2,
vt:0
},
var349var349:{
vid:349,
name:'Project.ClosedCaptions',
vv:1,
vvt:0,
vt:9
},
var350var350:{
vid:350,
name:'Project.MuteAudio',
vv:0,
vvt:0,
vt:9
},
var351var351:{
vid:351,
name:'Project.ShowPlaybar',
vv:1,
vvt:0,
vt:9
},
var352var352:{
vid:352,
name:'Project.ShowTOC',
vv:0,
vvt:0,
vt:9
},
var353var353:{
vid:353,
name:'Project.AudioLevel',
vv:100,
vvt:1,
vt:9
},
var354var354:{
vid:354,
name:'Project.LockTOC',
vv:0,
vvt:0,
vt:9
},
var355var355:{
vid:355,
name:'Project.CurrentSlideNumber',
vv:1,
vvt:1,
vt:9
},
var356var356:{
vid:356,
name:'Project.CurrentSlideName',
vv:'slide',
vvt:2,
vt:9
},
var357var357:{
vid:357,
name:'Project.SlideCount',
vv:1,
vvt:1,
vt:9
},
var358var358:{
vid:358,
name:'Date.Today',
vv:'dd',
vvt:3,
vt:5
},
var359var359:{
vid:359,
name:'Date.DateMMDDYY',
vv:'mm/dd/yyyy',
vvt:3,
vt:5
},
var360var360:{
vid:360,
name:'Date.DateDDMMYY',
vv:'dd/mm/yyyy',
vvt:3,
vt:5
},
var361var361:{
vid:361,
name:'Date.Day',
vv:'1',
vvt:3,
vt:5
},
var362var362:{
vid:362,
name:'Date.Hours',
vv:'hh',
vvt:3,
vt:5
},
var363var363:{
vid:363,
name:'Date.LocaleString',
vv:'',
vvt:3,
vt:5
},
var364var364:{
vid:364,
name:'Date.Minutes',
vv:'mm',
vvt:3,
vt:5
},
var365var365:{
vid:365,
name:'Date.Month',
vv:'mm',
vvt:3,
vt:5
},
var366var366:{
vid:366,
name:'Date.Time',
vv:'hh:mm:ss',
vvt:3,
vt:5
},
var367var367:{
vid:367,
name:'Date.Year',
vv:'yyyy',
vvt:3,
vt:5
},
var368var368:{
vid:368,
name:'Quiz.InScope',
vv:0,
vvt:0,
vt:7
},
var369var369:{
vid:369,
name:'Quiz.InReview',
vv:0,
vvt:0,
vt:7
},
var370var370:{
vid:370,
name:'Quiz.PercentageScore',
vv:'0',
vvt:2,
vt:7
},
var371var371:{
vid:371,
name:'Quiz.AttemptCount',
vv:0,
vvt:1,
vt:7
},
var372var372:{
vid:372,
name:'Quiz.Pass',
vv:0,
vvt:0,
vt:7
},
var373var373:{
vid:373,
name:'Quiz.Score',
vv:0,
vvt:1,
vt:7
},
var374var374:{
vid:374,
name:'Quiz.PassPercentage',
vv:80,
vvt:1,
vt:7
},
var375var375:{
vid:375,
name:'Quiz.PassPoints',
vv:0,
vvt:1,
vt:7
},
var376var376:{
vid:376,
name:'Quiz.CorrectAnswerCount',
vv:0,
vvt:1,
vt:7
},
var377var377:{
vid:377,
name:'Quiz.MaxScore',
vv:0,
vvt:1,
vt:7
},
var378var378:{
vid:378,
name:'Quiz.QuestionCount',
vv:0,
vvt:1,
vt:7
},
var379var379:{
vid:379,
name:'Quiz.UnansweredQuestionCount',
vv:0,
vvt:1,
vt:7
},
var380var380:{
vid:380,
name:'Question.AnswerChoice',
vv:'',
vvt:2,
vt:7
},
var381var381:{
vid:381,
name:'Question.PreviousQuestionScore',
vv:0,
vvt:1,
vt:7
},
var382var382:{
vid:382,
name:'Question.MaxAttempts',
vv:0,
vvt:1,
vt:7
},
var383var383:{
vid:383,
name:'Question.NegativePoints',
vv:0,
vvt:1,
vt:7
},
var384var384:{
vid:384,
name:'Question.PointsAssigned',
vv:0,
vvt:1,
vt:7
},
variableIdVsNameMap:{
var346:'LMS.LearnerID',
var347:'LMS.LearnerName',
var348:'LMS.CourseName',
var349:'Project.ClosedCaptions',
var350:'Project.MuteAudio',
var351:'Project.ShowPlaybar',
var352:'Project.ShowTOC',
var353:'Project.AudioLevel',
var354:'Project.LockTOC',
var355:'Project.CurrentSlideNumber',
var356:'Project.CurrentSlideName',
var357:'Project.SlideCount',
var358:'Date.Today',
var359:'Date.DateMMDDYY',
var360:'Date.DateDDMMYY',
var361:'Date.Day',
var362:'Date.Hours',
var363:'Date.LocaleString',
var364:'Date.Minutes',
var365:'Date.Month',
var366:'Date.Time',
var367:'Date.Year',
var368:'Quiz.InScope',
var369:'Quiz.InReview',
var370:'Quiz.PercentageScore',
var371:'Quiz.AttemptCount',
var372:'Quiz.Pass',
var373:'Quiz.Score',
var374:'Quiz.PassPercentage',
var375:'Quiz.PassPoints',
var376:'Quiz.CorrectAnswerCount',
var377:'Quiz.MaxScore',
var378:'Quiz.QuestionCount',
var379:'Quiz.UnansweredQuestionCount',
var380:'Question.AnswerChoice',
var381:'Question.PreviousQuestionScore',
var382:'Question.MaxAttempts',
var383:'Question.NegativePoints',
var384:'Question.PointsAssigned'
},
project:{
fps:30,
hasTOC:1,
hasCC:false,
showClosedCaptions:true,
w:1366,
h:768,
iw:1366,
ih:768,
prm:[1,1,0,0],
stateNameToLocalizedStateNameMap:{
kCPNormalState:'Normal',
kCPDownState:'Click',
kCPRolloverState:'Hover',
kCPVisitedState:'Visited',
kCPDragoverState:'',
kCPDragstartState:'',
kCPDropCorrect:'',
kCPDropIncorrect:'',
kCPDropAccept:'',
kCPDropReject:''
}
,
prjBgColor:'#ffffff',
pkt:0,
htmlBgColor:'#f5f4f1',
shc:false,
pN:'Section 1.cpt'
},
projectThemeData:{
image_presets:'{\\
  "theme_image_default": {\\
    "meta": {\\
      "name": "kCPImageStyleNormal",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_default--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_default--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Normal",\\
        "mixBlendMode": "normal"\\
      }\\
    }\\
  },\\
\\
  "theme_image_greyscale": {\\
    "meta": {\\
      "name": "kCPImageStyleGreyscale",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_greyscale--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_greyscale--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Greyscale",\\
        "mixBlendMode": "saturation",\\
        "intensity": "var(--theme_image_greyscale--intensity)",\\
        "filterColor": {\\
          "fill": "#000000",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_lighten": {\\
    "meta": {\\
      "name": "kCPImageStyleLighten",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_lighten--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_lighten--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Lighten",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_lighten--intensity)",\\
        "filterColor": {\\
          "fill": "#FFFFFF",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_darken": {\\
    "meta": {\\
      "name": "kCPImageStyleDarken",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_darken--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_darken--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Darken",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_darken--intensity)",\\
        "filterColor": {\\
          "fill": "var(--black)",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_overlay": {\\
    "meta": {\\
      "name": "kCPImageStyleOverlay",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_overlay--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_overlay--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Overlay",\\
        "mixBlendMode": "overlay",\\
        "intensity": "var(--theme_image_overlay--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_overlay--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_colorize": {\\
    "meta": {\\
      "name": "kCPImageStyleColorize",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_colorize--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_colorize--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Colorize",\\
        "mixBlendMode": "color",\\
        "intensity": "var(--theme_image_colorize--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_colorize--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  }\\
}\\
',
meta:'{\\
  "name": "kCPThemeLight",\\
  "description": "kCPThemeLightDescription",\\
  "version": 0.1,\\
  "guid": "Default-Light-Theme",\\
  "default_presets": {\\
    "0": "cp_default_shape_solid_style",\\
    "1": "text-body-1",\\
    "2": "theme_image_default",\\
    "3": "cp_default_slide_style",\\
    "4": "cp_textinshape_body_1",\\
    "5": "cp_default_line_shape_style",\\
    "6": "cp_default_complex_shape_solid_style",\\
    "7": "cp_button_style_1_textonly",\\
    "8": "cp_checkbox_style_1_textonly",\\
    "9": "cp_svg_style",\\
    "10": "cp_dropDown_style_1",\\
    "11": "cp_radiobutton_style_1_textonly",\\
    "12": "cp_inputField_style_1",\\
    "13": "cp_clickbox_style",\\
    "14": "cp_responsive_container_style",\\
    "15": "cp_default_shape_solid_style"\\
  },\\
  "color_palettes": [\\
    {\\
      "name": "Light Palette - 1",\\
      "colors": [\\
        "var(--color1)",\\
        "var(--color2)",\\
        "var(--color3)",\\
        "var(--color4)",\\
        "var(--color5)",\\
        "var(--color6)",\\
        "var(--color7)",\\
        "var(--color5_light)",\\
        "var(--color4_dark)"\\
      ]\\
    }\\
  ],\\
  "active_color_palette": 0\\
}',
other_presets:'{\\
  "cp_default_slide_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "type": 3,\\
      "category": 0\\
    },\\
    "backgroundColor": "var(--palette-color1)",\\
    "outlineColor": "var(--palette-color5)",\\
    "outlineWidth": 1,\\
    "outlineStyle": "solid",\\
    "outlineCap": "butt",\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 0,\\
            "y": 0\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_responsive_container_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 14,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": 1,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_correct": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--success)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incorrect": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--error)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incomplete": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--incomplete)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_hint": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--hint)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_retry": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--retry)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_timeout": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--timeout)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color1)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_radial_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}',
theme:'{\\
  "--primary": "#F1EEE6",\\
\\
  "--color1": "#FFFFFF",\\
  "--color2": "#F8F7F4",\\
  "--color3": "#F1EEE6",\\
  "--color4": "#D6D5D1",\\
  "--color5": "#666666",\\
  "--color6": "#333333",\\
  "--color7": "#020C1C",\\
  "--colorC7": "#F7F7F7",\\
  "--disabledC12": "#989898",\\
  "--color1_light": "#FFCD74",\\
  "--color1_dark": "#C76D12",\\
  "--color2_light": "#86FFFF",\\
  "--color2_dark": "#00ACCC",\\
  "--color3_light": "#9B5DFF",\\
  "--color3_dark": "#0000CA",\\
  "--color4_light": "#99FF99",\\
  "--color4_dark": "#112FA7",\\
  "--color5_light": "#163EE5",\\
  "--color5_dark": "#00CB92",\\
  "--color6_light": "#7697FF",\\
  "--color6_dark": "#0040CB",\\
  "--color7_light": "#FF8E64",\\
  "--color7_dark": "#C5230B",\\
\\
  "--success": "#558564",\\
  "--error": "#C83E4D",\\
  "--hint": "#CB6F10",\\
  "--incomplete":"#E8BD2B",\\
  "--timeout": "#C74545",\\
  "--retry": "#CB6F10",\\
  "--white": "#ffffff",\\
  "--black": "#000000",\\
\\
  "--greyscale1": "#FFFFFF",\\
  "--greyscale2": "#F1EEE61F",\\
  "--greyscale3": "#B3B3B3",\\
  "--greyscale4": "#4B4B4B",\\
  "--greyscale5": "#333333",\\
  "--disabled": "#818181",\\
\\
  "--palette-color0": "var(--color1)",\\
  "--palette-color1": "var(--color2)",\\
  "--palette-color2": "var(--color3)",\\
  "--palette-color3": "var(--color4)",\\
  "--palette-color4": "var(--color5)",\\
  "--palette-color5": "var(--color6)",\\
  "--palette-color6": "var(--color7)",\\
  "--palette-color7": "var(--color5_light)",\\
  "--palette-color8": "var(--color4_dark)",\\
\\
  "--design-option-color1": "255, 255, 255",\\
  "--design-option-color2": "248, 247, 244",\\
  "--design-option-color3": "241, 238, 230",\\
  "--design-option-color4": "214, 213, 209",\\
  "--design-option-color5": "102, 102, 102",\\
  "--design-option-color6": "51, 51, 51",\\
  "--design-option-color7": "2, 12, 28",\\
  "--design-option-color5_light": "22, 62, 229",\\
  "--design-option-color4_dark": "17, 47, 167",\\
\\
  "--c1": "var(--design-option-color1)",\\
  "--c2": "var(--design-option-color2)",\\
  "--c3": "var(--design-option-color3)",\\
  "--c4": "var(--design-option-color4)",\\
  "--c5": "var(--design-option-color5)",\\
  "--c6": "var(--design-option-color6)",\\
  "--c7": "var(--design-option-color7)",\\
  "--c8": "var(--design-option-color5_light)",\\
  "--c9": "var(--design-option-color4_dark)",\\
  \\
  "--widget-container--fillcolor": "var(--palette-color1)",\\
\\
  "--font1": "Georgia",\\
  "--font2": "Arial",\\
  "--text-style-unset": "none",\\
\\
  "--text-heading-1--fontSize--desktop": "120px",\\
  "--text-heading-1--fontSize--tablet": "100px",\\
  "--text-heading-1--fontSize--mobile": "80px",\\
  "--text-heading-1--fontFamily": "var(--font1)",\\
  "--text-heading-1--fontWeight": "normal",\\
  "--text-heading-1--fontType": "regular",\\
  "--text-heading-1--fontStyle": "normal",\\
  "--text-heading-1--fontStretch": "normal",\\
  "--text-heading-1--lineHeight": "1.07",\\
  "--text-heading-1--marginLeft": "0px",\\
  "--text-heading-1--color": "var(--palette-color6)",\\
  "--text-heading-1--borderBottomStyle": "none",\\
  "--text-heading-1--textDecoration": "none",\\
  "--text-heading-1--letterSpacing": "-0.01",\\
  "--text-heading-1--textTransform": "none",\\
  "--text-heading-1--stroke": "var(--palette-color2)",\\
  "--text-heading-1--textAlign": "left",\\
  "--text-heading-1--justifyContent": "flex-start",\\
  "--text-heading-1--marginTop": "auto",\\
  "--text-heading-1--marginBottom": "0",\\
  "--text-heading-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-2--fontSize--desktop": "80px",\\
  "--text-heading-2--fontSize--tablet": "72px",\\
  "--text-heading-2--fontSize--mobile": "60px",\\
  "--text-heading-2--fontFamily": "var(--font1)",\\
  "--text-heading-2--fontWeight": "normal",\\
  "--text-heading-2--fontType": "regular",\\
  "--text-heading-2--fontStyle": "normal",\\
  "--text-heading-2--fontStretch": "normal",\\
  "--text-heading-2--lineHeight": "1.1",\\
  "--text-heading-2--marginLeft": "0px",\\
  "--text-heading-2--color": "var(--palette-color6)",\\
  "--text-heading-2--borderBottomStyle": "none",\\
  "--text-heading-2--textDecoration": "none",\\
  "--text-heading-2--letterSpacing": "-0.04",\\
  "--text-heading-2--textTransform": "none",\\
  "--text-heading-2--stroke": "var(--palette-color2)",\\
  "--text-heading-2--textAlign": "left",\\
  "--text-heading-2--justifyContent": "flex-start",\\
  "--text-heading-2--marginTop": "auto",\\
  "--text-heading-2--marginBottom": "0",\\
  "--text-heading-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-3--fontSize--desktop": "60px",\\
  "--text-heading-3--fontSize--tablet": "52px",\\
  "--text-heading-3--fontSize--mobile": "44px",\\
  "--text-heading-3--fontFamily": "var(--font1)",\\
  "--text-heading-3--fontWeight": "normal",\\
  "--text-heading-3--fontType": "regular",\\
  "--text-heading-3--fontStyle": "normal",\\
  "--text-heading-3--fontStretch": "normal",\\
  "--text-heading-3--lineHeight": "1.1",\\
  "--text-heading-3--marginLeft": "0px",\\
  "--text-heading-3--color": "var(--palette-color6)",\\
  "--text-heading-3--borderBottomStyle": "none",\\
  "--text-heading-3--textDecoration": "none",\\
  "--text-heading-3--letterSpacing": "0.03",\\
  "--text-heading-3--textTransform": "none",\\
  "--text-heading-3--stroke": "var(--palette-color2)",\\
  "--text-heading-3--textAlign": "left",\\
  "--text-heading-3--justifyContent": "flex-start",\\
  "--text-heading-3--marginTop": "auto",\\
  "--text-heading-3--marginBottom": "0",\\
  "--text-heading-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-4--fontSize--desktop": "52px",\\
  "--text-heading-4--fontSize--tablet": "40px",\\
  "--text-heading-4--fontSize--mobile": "32px",\\
  "--text-heading-4--fontFamily": "var(--font1)",\\
  "--text-heading-4--fontWeight": "normal",\\
  "--text-heading-4--fontType": "regular",\\
  "--text-heading-4--fontStyle": "normal",\\
  "--text-heading-4--fontStretch": "normal",\\
  "--text-heading-4--lineHeight": "1.15",\\
  "--text-heading-4--marginLeft": "0px",\\
  "--text-heading-4--color": "var(--palette-color6)",\\
  "--text-heading-4--borderBottomStyle": "none",\\
  "--text-heading-4--textDecoration": "none",\\
  "--text-heading-4--letterSpacing": "0.10",\\
  "--text-heading-4--textTransform": "uppercase",\\
  "--text-heading-4--stroke": "var(--palette-color2)",\\
  "--text-heading-4--textAlign": "left",\\
  "--text-heading-4--justifyContent": "flex-start",\\
  "--text-heading-4--marginTop": "auto",\\
  "--text-heading-4--marginBottom": "0",\\
  "--text-heading-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-5--fontSize--desktop": "40px",\\
  "--text-heading-5--fontSize--tablet": "32px",\\
  "--text-heading-5--fontSize--mobile": "28px",\\
  "--text-heading-5--fontFamily": "var(--font1)",\\
  "--text-heading-5--fontWeight": "normal",\\
  "--text-heading-5--fontType": "regular",\\
  "--text-heading-5--fontStyle": "normal",\\
  "--text-heading-5--fontStretch": "normal",\\
  "--text-heading-5--lineHeight": "1.2",\\
  "--text-heading-5--marginLeft": "0px",\\
  "--text-heading-5--color": "var(--palette-color6)",\\
  "--text-heading-5--borderBottomStyle": "none",\\
  "--text-heading-5--textDecoration": "none",\\
  "--text-heading-5--letterSpacing": "0",\\
  "--text-heading-5--textTransform": "none",\\
  "--text-heading-5--stroke": "var(--palette-color2)",\\
  "--text-heading-5--textAlign": "left",\\
  "--text-heading-5--justifyContent": "flex-start",\\
  "--text-heading-5--marginTop": "auto",\\
  "--text-heading-5--marginBottom": "0",\\
  "--text-heading-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-6--fontSize--desktop": "36px",\\
  "--text-heading-6--fontSize--tablet": "28px",\\
  "--text-heading-6--fontSize--mobile": "24px",\\
  "--text-heading-6--fontFamily": "var(--font2)",\\
  "--text-heading-6--fontWeight": "normal",\\
  "--text-heading-6--fontType": "regular",\\
  "--text-heading-6--fontStyle": "normal",\\
  "--text-heading-6--fontStretch": "normal",\\
  "--text-heading-6--lineHeight": "1.2",\\
  "--text-heading-6--marginLeft": "0px",\\
  "--text-heading-6--color": "var(--palette-color6)",\\
  "--text-heading-6--borderBottomStyle": "none",\\
  "--text-heading-6--textDecoration": "none",\\
  "--text-heading-6--letterSpacing": "0",\\
  "--text-heading-6--textTransform": "none",\\
  "--text-heading-6--stroke": "var(--palette-color2)",\\
  "--text-heading-6--textAlign": "left",\\
  "--text-heading-6--justifyContent": "flex-start",\\
  "--text-heading-6--marginTop": "auto",\\
  "--text-heading-6--marginBottom": "0",\\
  "--text-heading-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-7--fontSize--desktop": "20px",\\
  "--text-heading-7--fontSize--tablet": "20px",\\
  "--text-heading-7--fontSize--mobile": "20px",\\
  "--text-heading-7--fontFamily": "var(--font1)",\\
  "--text-heading-7--fontWeight": "normal",\\
  "--text-heading-7--fontType": "regular",\\
  "--text-heading-7--fontStyle": "normal",\\
  "--text-heading-7--fontStretch": "normal",\\
  "--text-heading-7--lineHeight": "1.35",\\
  "--text-heading-7--marginLeft": "0px",\\
  "--text-heading-7--color": "var(--palette-color5)",\\
  "--text-heading-7--borderBottomStyle": "none",\\
  "--text-heading-7--textDecoration": "none",\\
  "--text-heading-7--letterSpacing": "0",\\
  "--text-heading-7--textTransform": "none",\\
  "--text-heading-7--stroke": "var(--palette-color2)",\\
  "--text-heading-7--textAlign": "left",\\
  "--text-heading-7--justifyContent": "flex-start",\\
  "--text-heading-7--marginTop": "auto",\\
  "--text-heading-7--marginBottom": "0",\\
  "--text-heading-7--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-7--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-7--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-7--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-8--fontSize--desktop": "72px",\\
  "--text-heading-8--fontSize--tablet": "48px",\\
  "--text-heading-8--fontSize--mobile": "32px",\\
  "--text-heading-8--fontFamily": "var(--font1)",\\
  "--text-heading-8--fontWeight": "normal",\\
  "--text-heading-8--fontType": "regular",\\
  "--text-heading-8--fontStyle": "normal",\\
  "--text-heading-8--fontStretch": "normal",\\
  "--text-heading-8--lineHeight": "1.35",\\
  "--text-heading-8--marginLeft": "0px",\\
  "--text-heading-8--color": "var(--palette-color5)",\\
  "--text-heading-8--borderBottomStyle": "none",\\
  "--text-heading-8--textDecoration": "none",\\
  "--text-heading-8--letterSpacing": "0",\\
  "--text-heading-8--textTransform": "none",\\
  "--text-heading-8--stroke": "var(--palette-color2)",\\
  "--text-heading-8--textAlign": "center",\\
  "--text-heading-8--justifyContent": "flex-start",\\
  "--text-heading-8--marginTop": "auto",\\
  "--text-heading-8--marginBottom": "0",\\
  "--text-heading-8--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-8--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-8--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-8--textShadow": "var(--text-style-unset)",\\
\\
  "--text-heading-9--fontSize--desktop": "32px",\\
  "--text-heading-9--fontSize--tablet": "32px",\\
  "--text-heading-9--fontSize--mobile": "32px",\\
  "--text-heading-9--fontFamily": "var(--font1)",\\
  "--text-heading-9--fontWeight": "normal",\\
  "--text-heading-9--fontType": "regular",\\
  "--text-heading-9--fontStyle": "normal",\\
  "--text-heading-9--fontStretch": "normal",\\
  "--text-heading-9--lineHeight": "1.35",\\
  "--text-heading-9--marginLeft": "0px",\\
  "--text-heading-9--color": "var(--palette-color5)",\\
  "--text-heading-9--borderBottomStyle": "none",\\
  "--text-heading-9--textDecoration": "none",\\
  "--text-heading-9--letterSpacing": "0",\\
  "--text-heading-9--textTransform": "none",\\
  "--text-heading-9--stroke": "var(--palette-color2)",\\
  "--text-heading-9--textAlign": "center",\\
  "--text-heading-9--justifyContent": "flex-start",\\
  "--text-heading-9--marginTop": "auto",\\
  "--text-heading-9--marginBottom": "0",\\
  "--text-heading-9--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-heading-9--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-heading-9--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-heading-9--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-1--fontSize--desktop": "22px",\\
  "--text-body-1--fontSize--tablet": "20px",\\
  "--text-body-1--fontSize--mobile": "18px",\\
  "--text-body-1--fontFamily": "var(--font1)",\\
  "--text-body-1--fontWeight": "normal",\\
  "--text-body-1--fontType": "regular",\\
  "--text-body-1--fontStyle": "normal",\\
  "--text-body-1--fontStretch": "normal",\\
  "--text-body-1--lineHeight": "1.3",\\
  "--text-body-1--marginLeft": "0px",\\
  "--text-body-1--color": "var(--palette-color5)",\\
  "--text-body-1--borderBottomStyle": "none",\\
  "--text-body-1--textDecoration": "none",\\
  "--text-body-1--letterSpacing": "0",\\
  "--text-body-1--textTransform": "none",\\
  "--text-body-1--stroke": "var(--palette-color2)",\\
  "--text-body-1--textAlign": "left",\\
  "--text-body-1--justifyContent": "flex-start",\\
  "--text-body-1--marginTop": "auto",\\
  "--text-body-1--marginBottom": "0",\\
  "--text-body-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-2--fontSize--desktop": "22px",\\
  "--text-body-2--fontSize--tablet": "20px",\\
  "--text-body-2--fontSize--mobile": "18px",\\
  "--text-body-2--fontFamily": "var(--font2)",\\
  "--text-body-2--fontWeight": "normal",\\
  "--text-body-2--fontType": "regular",\\
  "--text-body-2--fontStyle": "normal",\\
  "--text-body-2--fontStretch": "normal",\\
  "--text-body-2--lineHeight": "1.3",\\
  "--text-body-2--marginLeft": "0px",\\
  "--text-body-2--color": "var(--palette-color4)",\\
  "--text-body-2--borderBottomStyle": "none",\\
  "--text-body-2--textDecoration": "none",\\
  "--text-body-2--letterSpacing": "0.03",\\
  "--text-body-2--textTransform": "none",\\
  "--text-body-2--Stroke": "var(--palette-color2)",\\
  "--text-body-2--textAlign": "left",\\
  "--text-body-2--justifyContent": "flex-start",\\
  "--text-body-2--marginTop": "auto",\\
  "--text-body-2--marginBottom": "0",\\
  "--text-body-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-3--fontSize--desktop": "18px",\\
  "--text-body-3--fontSize--tablet": "16px",\\
  "--text-body-3--fontSize--mobile": "16px",\\
  "--text-body-3--fontFamily": "var(--font1)",\\
  "--text-body-3--fontWeight": "normal",\\
  "--text-body-3--fontType": "regular",\\
  "--text-body-3--fontStyle": "normal",\\
  "--text-body-3--fontStretch": "normal",\\
  "--text-body-3--lineHeight": "1.35",\\
  "--text-body-3--marginLeft": "0px",\\
  "--text-body-3--color": "var(--palette-color4)",\\
  "--text-body-3--borderBottomStyle": "none",\\
  "--text-body-3--textDecoration": "none",\\
  "--text-body-3--letterSpacing": "0",\\
  "--text-body-3--textTransform": "none",\\
  "--text-body-3--Stroke": "var(--palette-color2)",\\
  "--text-body-3--textAlign": "left",\\
  "--text-body-3--justifyContent": "flex-start",\\
  "--text-body-3--marginTop": "auto",\\
  "--text-body-3--marginBottom": "0",\\
  "--text-body-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-4--fontSize--desktop": "18px",\\
  "--text-body-4--fontSize--tablet": "16px",\\
  "--text-body-4--fontSize--mobile": "16px",\\
  "--text-body-4--fontFamily": "var(--font2)",\\
  "--text-body-4--fontWeight": "normal",\\
  "--text-body-4--fontType": "regular",\\
  "--text-body-4--fontStyle": "normal",\\
  "--text-body-4--fontStretch": "normal",\\
  "--text-body-4--lineHeight": "1.35",\\
  "--text-body-4--marginLeft": "0px",\\
  "--text-body-4--color": "var(--palette-color4)",\\
  "--text-body-4--borderBottomStyle": "none",\\
  "--text-body-4--textDecoration": "none",\\
  "--text-body-4--letterSpacing": "0",\\
  "--text-body-4--textTransform": "none",\\
  "--text-body-4--Stroke": "var(--palette-color2)",\\
  "--text-body-4--textAlign": "left",\\
  "--text-body-4--justifyContent": "flex-start",\\
  "--text-body-4--marginTop": "auto",\\
  "--text-body-4--marginBottom": "0",\\
  "--text-body-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-5--fontSize--desktop": "18px",\\
  "--text-body-5--fontSize--tablet": "16px",\\
  "--text-body-5--fontSize--mobile": "16px",\\
  "--text-body-5--fontFamily": "var(--font1)",\\
  "--text-body-5--fontWeight": "normal",\\
  "--text-body-5--fontType": "italic",\\
  "--text-body-5--fontStyle": "normal",\\
  "--text-body-5--fontStretch": "normal",\\
  "--text-body-5--lineHeight": "1.35",\\
  "--text-body-5--marginLeft": "0px",\\
  "--text-body-5--color": "var(--palette-color4)",\\
  "--text-body-5--borderBottomStyle": "none",\\
  "--text-body-5--textDecoration": "none",\\
  "--text-body-5--letterSpacing": "0",\\
  "--text-body-5--textTransform": "none",\\
  "--text-body-5--Stroke": "var(--palette-color2)",\\
  "--text-body-5--textAlign": "center",\\
  "--text-body-5--justifyContent": "flex-start",\\
  "--text-body-5--marginTop": "auto",\\
  "--text-body-5--marginBottom": "0",\\
  "--text-body-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-body-6--fontSize--desktop": "16px",\\
  "--text-body-6--fontSize--tablet": "14px",\\
  "--text-body-6--fontSize--mobile": "14px",\\
  "--text-body-6--fontFamily": "var(--font2)",\\
  "--text-body-6--fontWeight": "normal",\\
  "--text-body-6--fontType": "regular",\\
  "--text-body-6--fontStyle": "normal",\\
  "--text-body-6--fontStretch": "normal",\\
  "--text-body-6--lineHeight": "1.35",\\
  "--text-body-6--marginLeft": "0px",\\
  "--text-body-6--color": "var(--palette-color4)",\\
  "--text-body-6--borderBottomStyle": "none",\\
  "--text-body-6--textDecoration": "none",\\
  "--text-body-6--letterSpacing": "0",\\
  "--text-body-6--textTransform": "none",\\
  "--text-body-6--Stroke": "var(--palette-color2)",\\
  "--text-body-6--textAlign": "left",\\
  "--text-body-6--justifyContent": "flex-start",\\
  "--text-body-6--marginTop": "auto",\\
  "--text-body-6--marginBottom": "0",\\
  "--text-body-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-body-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-body-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-body-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-1--fontSize--desktop": "22px",\\
  "--text-component-1--fontSize--tablet": "20px",\\
  "--text-component-1--fontSize--mobile": "20px",\\
  "--text-component-1--fontFamily": "var(--font1)",\\
  "--text-component-1--fontWeight": "normal",\\
  "--text-component-1--fontType": "regular",\\
  "--text-component-1--fontStyle": "normal",\\
  "--text-component-1--fontStretch": "normal",\\
  "--text-component-1--lineHeight": "1.35",\\
  "--text-component-1--marginLeft": "0px",\\
  "--text-component-1--color": "var(--color6)",\\
  "--text-component-1--borderBottomStyle": "none",\\
  "--text-component-1--textDecoration": "none",\\
  "--text-component-1--letterSpacing": "0",\\
  "--text-component-1--textTransform": "none",\\
  "--text-component-1--stroke": "var(--palette-color2)",\\
  "--text-component-1--textAlign": "left",\\
  "--text-component-1--justifyContent": "flex-start",\\
  "--text-component-1--marginTop": "auto",\\
  "--text-component-1--marginBottom": "0",\\
  "--text-component-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-2--fontSize--desktop": "24px",\\
  "--text-component-2--fontSize--tablet": "20px",\\
  "--text-component-2--fontSize--mobile": "20px",\\
  "--text-component-2--fontFamily": "var(--font1)",\\
  "--text-component-2--fontWeight": "normal",\\
  "--text-component-2--fontType": "regular",\\
  "--text-component-2--fontStyle": "normal",\\
  "--text-component-2--fontStretch": "normal",\\
  "--text-component-2--lineHeight": "1.35",\\
  "--text-component-2--marginLeft": "0px",\\
  "--text-component-2--color": "var(--palette-color1)",\\
  "--text-component-2--borderBottomStyle": "none",\\
  "--text-component-2--textDecoration": "none",\\
  "--text-component-2--letterSpacing": "0.16",\\
  "--text-component-2--textTransform": "none",\\
  "--text-component-2--stroke": "var(--palette-color2)",\\
  "--text-component-2--textAlign": "left",\\
  "--text-component-2--justifyContent": "flex-start",\\
  "--text-component-2--marginTop": "auto",\\
  "--text-component-2--marginBottom": "0",\\
  "--text-component-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-3--fontSize--desktop": "14px",\\
  "--text-component-3--fontSize--tablet": "14px",\\
  "--text-component-3--fontSize--mobile": "14px",\\
  "--text-component-3--fontFamily": "var(--font1)",\\
  "--text-component-3--fontWeight": "normal",\\
  "--text-component-3--fontType": "regular",\\
  "--text-component-3--fontStyle": "normal",\\
  "--text-component-3--fontStretch": "normal",\\
  "--text-component-3--lineHeight": "1.35",\\
  "--text-component-3--marginLeft": "0px",\\
  "--text-component-3--color": "var(--palette-color6)",\\
  "--text-component-3--borderBottomStyle": "none",\\
  "--text-component-3--textDecoration": "none",\\
  "--text-component-3--letterSpacing": "0.2",\\
  "--text-component-3--textTransform": "uppercase",\\
  "--text-component-3--stroke": "var(--palette-color2)",\\
  "--text-component-3--textAlign": "center",\\
  "--text-component-3--justifyContent": "flex-start",\\
  "--text-component-3--marginTop": "auto",\\
  "--text-component-3--marginBottom": "0",\\
  "--text-component-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-component-4--fontSize--desktop": "22px",\\
  "--text-component-4--fontSize--tablet": "20px",\\
  "--text-component-4--fontSize--mobile": "20px",\\
  "--text-component-4--fontFamily": "var(--font1)",\\
  "--text-component-4--fontWeight": "normal",\\
  "--text-component-4--fontType": "regular",\\
  "--text-component-4--fontStyle": "normal",\\
  "--text-component-4--fontStretch": "normal",\\
  "--text-component-4--lineHeight": "1.35",\\
  "--text-component-4--marginLeft": "0px",\\
  "--text-component-4--color": "var(--color6)",\\
  "--text-component-4--borderBottomStyle": "none",\\
  "--text-component-4--textDecoration": "none",\\
  "--text-component-4--letterSpacing": "0.02",\\
  "--text-component-4--textTransform": "none",\\
  "--text-component-4--stroke": "var(--palette-color2)",\\
  "--text-component-4--textAlign": "left",\\
  "--text-component-4--justifyContent": "flex-start",\\
  "--text-component-4--marginTop": "auto",\\
  "--text-component-4--marginBottom": "0",\\
  "--text-component-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-component-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-component-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-component-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-1--fontSize--desktop": "36px",\\
  "--text-subheading-1--fontSize--tablet": "32px",\\
  "--text-subheading-1--fontSize--mobile": "28px",\\
  "--text-subheading-1--fontFamily": "var(--font2)",\\
  "--text-subheading-1--fontWeight": "normal",\\
  "--text-subheading-1--fontType": "regular",\\
  "--text-subheading-1--fontStyle": "normal",\\
  "--text-subheading-1--fontStretch": "normal",\\
  "--text-subheading-1--lineHeight": "1.1",\\
  "--text-subheading-1--marginLeft": "0px",\\
  "--text-subheading-1--color": "var(--palette-color6)",\\
  "--text-subheading-1--borderBottomStyle": "none",\\
  "--text-subheading-1--textDecoration": "none",\\
  "--text-subheading-1--letterSpacing": "0.05",\\
  "--text-subheading-1--textTransform": "uppercase",\\
  "--text-subheading-1--stroke": "var(--palette-color2)",\\
  "--text-subheading-1--textAlign": "left",\\
  "--text-subheading-1--justifyContent": "flex-start",\\
  "--text-subheading-1--marginTop": "auto",\\
  "--text-subheading-1--marginBottom": "0",\\
  "--text-subheading-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-2--fontSize--desktop": "28px",\\
  "--text-subheading-2--fontSize--tablet": "24px",\\
  "--text-subheading-2--fontSize--mobile": "20px",\\
  "--text-subheading-2--fontFamily": "var(--font2)",\\
  "--text-subheading-2--fontWeight": "normal",\\
  "--text-subheading-2--fontType": "bold",\\
  "--text-subheading-2--fontStyle": "normal",\\
  "--text-subheading-2--fontStretch": "normal",\\
  "--text-subheading-2--lineHeight": "1.15",\\
  "--text-subheading-2--marginLeft": "0px",\\
  "--text-subheading-2--color": "var(--palette-color6)",\\
  "--text-subheading-2--borderBottomStyle": "none",\\
  "--text-subheading-2--textDecoration": "none",\\
  "--text-subheading-2--letterSpacing": "0.05",\\
  "--text-subheading-2--textTransform": "none",\\
  "--text-subheading-2--stroke": "var(--palette-color2)",\\
  "--text-subheading-2--textAlign": "left",\\
  "--text-subheading-2--justifyContent": "flex-start",\\
  "--text-subheading-2--marginTop": "auto",\\
  "--text-subheading-2--marginBottom": "0",\\
  "--text-subheading-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-3--fontSize--desktop": "26px",\\
  "--text-subheading-3--fontSize--tablet": "22px",\\
  "--text-subheading-3--fontSize--mobile": "18px",\\
  "--text-subheading-3--fontFamily": "var(--font2)",\\
  "--text-subheading-3--fontWeight": "normal",\\
  "--text-subheading-3--fontType": "regular",\\
  "--text-subheading-3--fontStyle": "normal",\\
  "--text-subheading-3--fontStretch": "normal",\\
  "--text-subheading-3--lineHeight": "1.15",\\
  "--text-subheading-3--marginLeft": "0px",\\
  "--text-subheading-3--color": "var(--palette-color6)",\\
  "--text-subheading-3--borderBottomStyle": "none",\\
  "--text-subheading-3--textDecoration": "none",\\
  "--text-subheading-3--letterSpacing": "0",\\
  "--text-subheading-3--textTransform": "none",\\
  "--text-subheading-3--stroke": "var(--palette-color2)",\\
  "--text-subheading-3--textAlign": "center",\\
  "--text-subheading-3--justifyContent": "flex-start",\\
  "--text-subheading-3--marginTop": "auto",\\
  "--text-subheading-3--marginBottom": "0",\\
  "--text-subheading-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-4--fontSize--desktop": "24px",\\
  "--text-subheading-4--fontSize--tablet": "20px",\\
  "--text-subheading-4--fontSize--mobile": "16px",\\
  "--text-subheading-4--fontFamily": "var(--font2)",\\
  "--text-subheading-4--fontWeight": "normal",\\
  "--text-subheading-4--fontType": "bold",\\
  "--text-subheading-4--fontStyle": "normal",\\
  "--text-subheading-4--fontStretch": "normal",\\
  "--text-subheading-4--lineHeight": "1.15",\\
  "--text-subheading-4--marginLeft": "0px",\\
  "--text-subheading-4--color": "var(--palette-color0)",\\
  "--text-subheading-4--borderBottomStyle": "none",\\
  "--text-subheading-4--textDecoration": "none",\\
  "--text-subheading-4--letterSpacing": "0.05",\\
  "--text-subheading-4--textTransform": "none",\\
  "--text-subheading-4--stroke": "var(--palette-color2)",\\
  "--text-subheading-4--textAlign": "left",\\
  "--text-subheading-4--justifyContent": "flex-start",\\
  "--text-subheading-4--marginTop": "auto",\\
  "--text-subheading-4--marginBottom": "0",\\
  "--text-subheading-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-5--fontSize--desktop": "24px",\\
  "--text-subheading-5--fontSize--tablet": "20px",\\
  "--text-subheading-5--fontSize--mobile": "16px",\\
  "--text-subheading-5--fontFamily": "var(--font1)",\\
  "--text-subheading-5--fontWeight": "normal",\\
  "--text-subheading-5--fontType": "bold",\\
  "--text-subheading-5--fontStyle": "normal",\\
  "--text-subheading-5--fontStretch": "normal",\\
  "--text-subheading-5--lineHeight": "1.15",\\
  "--text-subheading-5--marginLeft": "0px",\\
  "--text-subheading-5--color": "var(--palette-color5)",\\
  "--text-subheading-5--borderBottomStyle": "none",\\
  "--text-subheading-5--textDecoration": "none",\\
  "--text-subheading-5--letterSpacing": "-0.05",\\
  "--text-subheading-5--textTransform": "none",\\
  "--text-subheading-5--stroke": "var(--palette-color2)",\\
  "--text-subheading-5--textAlign": "left",\\
  "--text-subheading-5--justifyContent": "flex-start",\\
  "--text-subheading-5--marginTop": "auto",\\
  "--text-subheading-5--marginBottom": "0",\\
  "--text-subheading-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-subheading-6--fontSize--desktop": "18px",\\
  "--text-subheading-6--fontSize--tablet": "16px",\\
  "--text-subheading-6--fontSize--mobile": "14px",\\
  "--text-subheading-6--fontFamily": "var(--font2)",\\
  "--text-subheading-6--fontWeight": "normal",\\
  "--text-subheading-6--fontType": "bold",\\
  "--text-subheading-6--fontStyle": "normal",\\
  "--text-subheading-6--fontStretch": "normal",\\
  "--text-subheading-6--lineHeight": "1.25",\\
  "--text-subheading-6--marginLeft": "0px",\\
  "--text-subheading-6--color": "var(--palette-color5)",\\
  "--text-subheading-6--borderBottomStyle": "none",\\
  "--text-subheading-6--textDecoration": "none",\\
  "--text-subheading-6--letterSpacing": "0",\\
  "--text-subheading-6--textTransform": "none",\\
  "--text-subheading-6--stroke": "var(--palette-color2)",\\
  "--text-subheading-6--textAlign": "left",\\
  "--text-subheading-6--justifyContent": "flex-start",\\
  "--text-subheading-6--marginTop": "auto",\\
  "--text-subheading-6--marginBottom": "0",\\
  "--text-subheading-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-subheading-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-subheading-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-subheading-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-1--fontSize--desktop": "20px",\\
  "--text-detail-1--fontSize--tablet": "18px",\\
  "--text-detail-1--fontSize--mobile": "16px",\\
  "--text-detail-1--fontFamily": "var(--font2)",\\
  "--text-detail-1--fontWeight": "normal",\\
  "--text-detail-1--fontType": "regular",\\
  "--text-detail-1--fontStyle": "normal",\\
  "--text-detail-1--fontStretch": "normal",\\
  "--text-detail-1--lineHeight": "1.2",\\
  "--text-detail-1--marginLeft": "0px",\\
  "--text-detail-1--color": "var(--palette-color6)",\\
  "--text-detail-1--borderBottomStyle": "none",\\
  "--text-detail-1--textDecoration": "none",\\
  "--text-detail-1--letterSpacing": "0",\\
  "--text-detail-1--textTransform": "uppercase",\\
  "--text-detail-1--stroke": "var(--palette-color5)",\\
  "--text-detail-1--textAlign": "left",\\
  "--text-detail-1--justifyContent": "flex-start",\\
  "--text-detail-1--marginTop": "auto",\\
  "--text-detail-1--marginBottom": "0",\\
  "--text-detail-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-2--fontSize--desktop": "16px",\\
  "--text-detail-2--fontSize--tablet": "14px",\\
  "--text-detail-2--fontSize--mobile": "12px",\\
  "--text-detail-2--fontFamily": "var(--font2)",\\
  "--text-detail-2--fontWeight": "normal",\\
  "--text-detail-2--fontType": "bold",\\
  "--text-detail-2--fontStyle": "normal",\\
  "--text-detail-2--fontStretch": "normal",\\
  "--text-detail-2--lineHeight": "1.3",\\
  "--text-detail-2--marginLeft": "0px",\\
  "--text-detail-2--color": "var(--palette-color6)",\\
  "--text-detail-2--borderBottomStyle": "none",\\
  "--text-detail-2--textDecoration": "none",\\
  "--text-detail-2--letterSpacing": "0",\\
  "--text-detail-2--textTransform": "uppercase",\\
  "--text-detail-2--stroke": "var(--palette-color2)",\\
  "--text-detail-2--textAlign": "left",\\
  "--text-detail-2--justifyContent": "flex-start",\\
  "--text-detail-2--marginTop": "auto",\\
  "--text-detail-2--marginBottom": "0",\\
  "--text-detail-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-3--fontSize--desktop": "16px",\\
  "--text-detail-3--fontSize--tablet": "14px",\\
  "--text-detail-3--fontSize--mobile": "12px",\\
  "--text-detail-3--fontFamily": "var(--font2)",\\
  "--text-detail-3--fontWeight": "normal",\\
  "--text-detail-3--fontType": "regular",\\
  "--text-detail-3--fontStyle": "normal",\\
  "--text-detail-3--fontStretch": "normal",\\
  "--text-detail-3--lineHeight": "1.35",\\
  "--text-detail-3--marginLeft": "0px",\\
  "--text-detail-3--color": "var(--palette-color4)",\\
  "--text-detail-3--borderBottomStyle": "none",\\
  "--text-detail-3--textDecoration": "none",\\
  "--text-detail-3--letterSpacing": "0.2",\\
  "--text-detail-3--textTransform": "uppercase",\\
  "--text-detail-3--stroke": "var(--palette-color2)",\\
  "--text-detail-3--textAlign": "left",\\
  "--text-detail-3--justifyContent": "flex-start",\\
  "--text-detail-3--marginTop": "auto",\\
  "--text-detail-3--marginBottom": "0",\\
  "--text-detail-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-detail-4--fontSize--desktop": "22px",\\
  "--text-detail-4--fontSize--tablet": "20px",\\
  "--text-detail-4--fontSize--mobile": "20px",\\
  "--text-detail-4--fontFamily": "var(--font1)",\\
  "--text-detail-4--fontWeight": "normal",\\
  "--text-detail-4--fontType": "regular",\\
  "--text-detail-4--fontStyle": "normal",\\
  "--text-detail-4--fontStretch": "normal",\\
  "--text-detail-4--lineHeight": "1.35",\\
  "--text-detail-4--marginLeft": "0px",\\
  "--text-detail-4--color": "var(--palette-color5)",\\
  "--text-detail-4--borderBottomStyle": "none",\\
  "--text-detail-4--textDecoration": "none",\\
  "--text-detail-4--letterSpacing": "0",\\
  "--text-detail-4--textTransform": "none",\\
  "--text-detail-4--stroke": "var(--palette-color2)",\\
  "--text-detail-4--textAlign": "center",\\
  "--text-detail-4--justifyContent": "flex-start",\\
  "--text-detail-4--marginTop": "auto",\\
  "--text-detail-4--marginBottom": "0",\\
  "--text-detail-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-detail-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-detail-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-detail-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-1--fontSize--desktop": "36px",\\
  "--text-variable-1--fontSize--tablet": "32px",\\
  "--text-variable-1--fontSize--mobile": "30px",\\
  "--text-variable-1--fontFamily": "var(--font2)",\\
  "--text-variable-1--fontWeight": "normal",\\
  "--text-variable-1--fontType": "bold",\\
  "--text-variable-1--fontStyle": "normal",\\
  "--text-variable-1--fontStretch": "normal",\\
  "--text-variable-1--lineHeight": "1.2",\\
  "--text-variable-1--marginLeft": "0px",\\
  "--text-variable-1--color": "var(--palette-color7)",\\
  "--text-variable-1--borderBottomStyle": "none",\\
  "--text-variable-1--textDecoration": "none",\\
  "--text-variable-1--letterSpacing": "0.02",\\
  "--text-variable-1--textTransform": "none",\\
  "--text-variable-1--stroke": "var(--palette-color2)",\\
  "--text-variable-1--textAlign": "left",\\
  "--text-variable-1--justifyContent": "flex-start",\\
  "--text-variable-1--marginTop": "auto",\\
  "--text-variable-1--marginBottom": "0",\\
  "--text-variable-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-2--fontSize--desktop": "24px",\\
  "--text-variable-2--fontSize--tablet": "22px",\\
  "--text-variable-2--fontSize--mobile": "20px",\\
  "--text-variable-2--fontFamily": "var(--font2)",\\
  "--text-variable-2--fontWeight": "normal",\\
  "--text-variable-2--fontType": "bold",\\
  "--text-variable-2--fontStyle": "normal",\\
  "--text-variable-2--fontStretch": "normal",\\
  "--text-variable-2--lineHeight": "1.15",\\
  "--text-variable-2--marginLeft": "0px",\\
  "--text-variable-2--color": "var(--palette-color6)",\\
  "--text-variable-2--borderBottomStyle": "none",\\
  "--text-variable-2--textDecoration": "none",\\
  "--text-variable-2--letterSpacing": "0",\\
  "--text-variable-2--textTransform": "none",\\
  "--text-variable-2--stroke": "var(--palette-color2)",\\
  "--text-variable-2--textAlign": "left",\\
  "--text-variable-2--justifyContent": "flex-start",\\
  "--text-variable-2--marginTop": "auto",\\
  "--text-variable-2--marginBottom": "0",\\
  "--text-variable-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-3--fontSize--desktop": "20px",\\
  "--text-variable-3--fontSize--tablet": "18px",\\
  "--text-variable-3--fontSize--mobile": "16px",\\
  "--text-variable-3--fontFamily": "var(--font1)",\\
  "--text-variable-3--fontWeight": "normal",\\
  "--text-variable-3--fontType": "bold",\\
  "--text-variable-3--fontStyle": "normal",\\
  "--text-variable-3--fontStretch": "normal",\\
  "--text-variable-3--lineHeight": "1.2",\\
  "--text-variable-3--marginLeft": "0px",\\
  "--text-variable-3--color": "var(--palette-color6)",\\
  "--text-variable-3--borderBottomStyle": "none",\\
  "--text-variable-3--textDecoration": "none",\\
  "--text-variable-3--letterSpacing": "0",\\
  "--text-variable-3--textTransform": "none",\\
  "--text-variable-3--stroke": "var(--palette-color2)",\\
  "--text-variable-3--textAlign": "left",\\
  "--text-variable-3--justifyContent": "flex-start",\\
  "--text-variable-3--marginTop": "auto",\\
  "--text-variable-3--marginBottom": "0",\\
  "--text-variable-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-variable-4--fontSize--desktop": "16px",\\
  "--text-variable-4--fontSize--tablet": "14px",\\
  "--text-variable-4--fontSize--mobile": "12px",\\
  "--text-variable-4--fontFamily": "var(--font2)",\\
  "--text-variable-4--fontWeight": "normal",\\
  "--text-variable-4--fontType": "bold",\\
  "--text-variable-4--fontStyle": "normal",\\
  "--text-variable-4--fontStretch": "normal",\\
  "--text-variable-4--lineHeight": "1.3",\\
  "--text-variable-4--marginLeft": "0px",\\
  "--text-variable-4--color": "var(--palette-color6)",\\
  "--text-variable-4--borderBottomStyle": "none",\\
  "--text-variable-4--textDecoration": "none",\\
  "--text-variable-4--letterSpacing": "0.02",\\
  "--text-variable-4--textTransform": "none",\\
  "--text-variable-4--stroke": "var(--palette-color2)",\\
  "--text-variable-4--textAlign": "left",\\
  "--text-variable-4--justifyContent": "flex-start",\\
  "--text-variable-4--marginTop": "auto",\\
  "--text-variable-4--marginBottom": "0",\\
  "--text-variable-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-variable-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-variable-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-variable-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-question-1--fontSize--desktop": "48px",\\
  "--text-question-1--fontSize--tablet": "20px",\\
  "--text-question-1--fontSize--mobile": "20px",\\
  "--text-question-1--fontFamily": "var(--font1)",\\
  "--text-question-1--fontWeight": "normal",\\
  "--text-question-1--fontType": "regular",\\
  "--text-question-1--fontStyle": "normal",\\
  "--text-question-1--fontStretch": "normal",\\
  "--text-question-1--lineHeight": "1.35",\\
  "--text-question-1--marginLeft": "0px",\\
  "--text-question-1--color": "var(--palette-color5)",\\
  "--text-question-1--borderBottomStyle": "none",\\
  "--text-question-1--textDecoration": "none",\\
  "--text-question-1--letterSpacing": "0",\\
  "--text-question-1--textTransform": "none",\\
  "--text-question-1--stroke": "var(--palette-color2)",\\
  "--text-question-1--textAlign": "left",\\
  "--text-question-1--justifyContent": "flex-start",\\
  "--text-question-1--marginTop": "auto",\\
  "--text-question-1--marginBottom": "0",\\
  "--text-question-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-question-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-question-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-question-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-question-2--fontSize--desktop": "24px",\\
  "--text-question-2--fontSize--tablet": "20px",\\
  "--text-question-2--fontSize--mobile": "20px",\\
  "--text-question-2--fontFamily": "var(--font1)",\\
  "--text-question-2--fontWeight": "normal",\\
  "--text-question-2--fontType": "bold",\\
  "--text-question-2--fontStyle": "normal",\\
  "--text-question-2--fontStretch": "normal",\\
  "--text-question-2--lineHeight": "1.35",\\
  "--text-question-2--marginLeft": "0px",\\
  "--text-question-2--color": "var(--palette-color5)",\\
  "--text-question-2--borderBottomStyle": "none",\\
  "--text-question-2--textDecoration": "none",\\
  "--text-question-2--letterSpacing": "0",\\
  "--text-question-2--textTransform": "none",\\
  "--text-question-2--stroke": "var(--palette-color2)",\\
  "--text-question-2--textAlign": "left",\\
  "--text-question-2--justifyContent": "flex-start",\\
  "--text-question-2--marginTop": "auto",\\
  "--text-question-2--marginBottom": "0",\\
  "--text-question-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-question-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-question-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-question-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-1--fontSize--desktop": "16px",\\
  "--text-button-1--fontSize--tablet": "16px",\\
  "--text-button-1--fontSize--mobile": "16px",\\
  "--text-button-1--fontFamily": "var(--font2)",\\
  "--text-button-1--fontWeight": "normal",\\
  "--text-button-1--fontType": "regular",\\
  "--text-button-1--fontStyle": "normal",\\
  "--text-button-1--fontStretch": "normal",\\
  "--text-button-1--lineHeight": "1.25",\\
  "--text-button-1--marginLeft": "0px",\\
  "--text-button-1--color": "var(--palette-color7)",\\
  "--text-button-1--borderBottomStyle": "none",\\
  "--text-button-1--textDecoration": "none",\\
  "--text-button-1--letterSpacing": "0.12",\\
  "--text-button-1--textTransform": "uppercase",\\
  "--text-button-1--stroke": "var(--palette-color2)",\\
  "--text-button-1--textAlign": "center",\\
  "--text-button-1--justifyContent": "flex-start",\\
  "--text-button-1--marginTop": "auto",\\
  "--text-button-1--marginBottom": "0",\\
  "--text-button-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-2--fontSize--desktop": "16px",\\
  "--text-button-2--fontSize--tablet": "16px",\\
  "--text-button-2--fontSize--mobile": "16px",\\
  "--text-button-2--fontFamily": "var(--font2)",\\
  "--text-button-2--fontWeight": "normal",\\
  "--text-button-2--fontType": "regular",\\
  "--text-button-2--fontStyle": "normal",\\
  "--text-button-2--fontStretch": "normal",\\
  "--text-button-2--lineHeight": "1.25",\\
  "--text-button-2--marginLeft": "0px",\\
  "--text-button-2--color": "var(--palette-color0)",\\
  "--text-button-2--borderBottomStyle": "none",\\
  "--text-button-2--textDecoration": "none",\\
  "--text-button-2--letterSpacing": "0.12",\\
  "--text-button-2--textTransform": "uppercase",\\
  "--text-button-2--stroke": "var(--palette-color2)",\\
  "--text-button-2--textAlign": "center",\\
  "--text-button-2--justifyContent": "flex-start",\\
  "--text-button-2--marginTop": "auto",\\
  "--text-button-2--marginBottom": "0",\\
  "--text-button-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-3--fontSize--desktop": "16px",\\
  "--text-button-3--fontSize--tablet": "16px",\\
  "--text-button-3--fontSize--mobile": "16px",\\
  "--text-button-3--fontFamily": "var(--font2)",\\
  "--text-button-3--fontWeight": "normal",\\
  "--text-button-3--fontType": "regular",\\
  "--text-button-3--fontStyle": "normal",\\
  "--text-button-3--fontStretch": "normal",\\
  "--text-button-3--lineHeight": "1.25",\\
  "--text-button-3--marginLeft": "0px",\\
  "--text-button-3--color": "var(--palette-color5)",\\
  "--text-button-3--borderBottomStyle": "none",\\
  "--text-button-3--textDecoration": "none",\\
  "--text-button-3--letterSpacing": "0.12",\\
  "--text-button-3--textTransform": "uppercase",\\
  "--text-button-3--stroke": "var(--palette-color2)",\\
  "--text-button-3--textAlign": "center",\\
  "--text-button-3--justifyContent": "flex-start",\\
  "--text-button-3--marginTop": "auto",\\
  "--text-button-3--marginBottom": "0",\\
  "--text-button-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-button-4--fontSize--desktop": "16px",\\
  "--text-button-4--fontSize--tablet": "16px",\\
  "--text-button-4--fontSize--mobile": "16px",\\
  "--text-button-4--fontFamily": "var(--font2)",\\
  "--text-button-4--fontWeight": "normal",\\
  "--text-button-4--fontType": "regular",\\
  "--text-button-4--fontStyle": "normal",\\
  "--text-button-4--fontStretch": "normal",\\
  "--text-button-4--lineHeight": "1.25",\\
  "--text-button-4--marginLeft": "0px",\\
  "--text-button-4--color": "var(--palette-color4)",\\
  "--text-button-4--borderBottomStyle": "none",\\
  "--text-button-4--textDecoration": "none",\\
  "--text-button-4--letterSpacing": "0.12",\\
  "--text-button-4--textTransform": "uppercase",\\
  "--text-button-4--stroke": "var(--palette-color2)",\\
  "--text-button-4--textAlign": "center",\\
  "--text-button-4--justifyContent": "flex-start",\\
  "--text-button-4--marginTop": "auto",\\
  "--text-button-4--marginBottom": "0",\\
  "--text-button-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-button-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-button-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-button-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-1--fontSize--desktop": "18px",\\
  "--text-uic-1--fontSize--tablet": "18px",\\
  "--text-uic-1--fontSize--mobile": "18px",\\
  "--text-uic-1--fontFamily": "var(--font1)",\\
  "--text-uic-1--fontWeight": "normal",\\
  "--text-uic-1--fontType": "italic",\\
  "--text-uic-1--fontStyle": "normal",\\
  "--text-uic-1--fontStretch": "normal",\\
  "--text-uic-1--lineHeight": "1.35",\\
  "--text-uic-1--marginLeft": "0px",\\
  "--text-uic-1--color": "var(--palette-color4)",\\
  "--text-uic-1--borderBottomStyle": "none",\\
  "--text-uic-1--textDecoration": "none",\\
  "--text-uic-1--letterSpacing": "0",\\
  "--text-uic-1--textTransform": "none",\\
  "--text-uic-1--stroke": "var(--palette-color2)",\\
  "--text-uic-1--textAlign": "left",\\
  "--text-uic-1--justifyContent": "flex-start",\\
  "--text-uic-1--marginTop": "auto",\\
  "--text-uic-1--marginBottom": "0",\\
  "--text-uic-1--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-2--fontSize--desktop": "18px",\\
  "--text-uic-2--fontSize--tablet": "18px",\\
  "--text-uic-2--fontSize--mobile": "18px",\\
  "--text-uic-2--fontFamily": "var(--font1)",\\
  "--text-uic-2--fontWeight": "normal",\\
  "--text-uic-2--fontType": "italic",\\
  "--text-uic-2--fontStyle": "normal",\\
  "--text-uic-2--fontStretch": "normal",\\
  "--text-uic-2--lineHeight": "1.35",\\
  "--text-uic-2--marginLeft": "0px",\\
  "--text-uic-2--color": "var(--palette-color1)",\\
  "--text-uic-2--borderBottomStyle": "none",\\
  "--text-uic-2--textDecoration": "none",\\
  "--text-uic-2--letterSpacing": "0",\\
  "--text-uic-2--textTransform": "none",\\
  "--text-uic-2--stroke": "var(--palette-color2)",\\
  "--text-uic-2--textAlign": "left",\\
  "--text-uic-2--justifyContent": "flex-start",\\
  "--text-uic-2--marginTop": "auto",\\
  "--text-uic-2--marginBottom": "0",\\
  "--text-uic-2--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-3--fontSize--desktop": "22px",\\
  "--text-uic-3--fontSize--tablet": "22px",\\
  "--text-uic-3--fontSize--mobile": "22px",\\
  "--text-uic-3--fontFamily": "var(--font1)",\\
  "--text-uic-3--fontWeight": "normal",\\
  "--text-uic-3--fontType": "regular",\\
  "--text-uic-3--fontStyle": "normal",\\
  "--text-uic-3--fontStretch": "normal",\\
  "--text-uic-3--lineHeight": "1.25",\\
  "--text-uic-3--marginLeft": "0px",\\
  "--text-uic-3--color": "var(--palette-color5)",\\
  "--text-uic-3--borderBottomStyle": "none",\\
  "--text-uic-3--textDecoration": "none",\\
  "--text-uic-3--letterSpacing": "0",\\
  "--text-uic-3--textTransform": "none",\\
  "--text-uic-3--stroke": "var(--palette-color2)",\\
  "--text-uic-3--textAlign": "left",\\
  "--text-uic-3--justifyContent": "flex-start",\\
  "--text-uic-3--marginTop": "auto",\\
  "--text-uic-3--marginBottom": "0",\\
  "--text-uic-3--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-4--fontSize--desktop": "22px",\\
  "--text-uic-4--fontSize--tablet": "22px",\\
  "--text-uic-4--fontSize--mobile": "22px",\\
  "--text-uic-4--fontFamily": "var(--font1)",\\
  "--text-uic-4--fontWeight": "normal",\\
  "--text-uic-4--fontType": "regular",\\
  "--text-uic-4--fontStyle": "normal",\\
  "--text-uic-4--fontStretch": "normal",\\
  "--text-uic-4--lineHeight": "1.25",\\
  "--text-uic-4--marginLeft": "0px",\\
  "--text-uic-4--color": "var(--palette-color4)",\\
  "--text-uic-4--borderBottomStyle": "none",\\
  "--text-uic-4--textDecoration": "none",\\
  "--text-uic-4--letterSpacing": "0",\\
  "--text-uic-4--textTransform": "none",\\
  "--text-uic-4--stroke": "var(--palette-color2)",\\
  "--text-uic-4--textAlign": "left",\\
  "--text-uic-4--justifyContent": "flex-start",\\
  "--text-uic-4--marginTop": "auto",\\
  "--text-uic-4--marginBottom": "0",\\
  "--text-uic-4--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-5--fontSize--desktop": "22px",\\
  "--text-uic-5--fontSize--tablet": "22px",\\
  "--text-uic-5--fontSize--mobile": "22px",\\
  "--text-uic-5--fontFamily": "var(--font1)",\\
  "--text-uic-5--fontWeight": "normal",\\
  "--text-uic-5--fontType": "regular",\\
  "--text-uic-5--fontStyle": "normal",\\
  "--text-uic-5--fontStretch": "normal",\\
  "--text-uic-5--lineHeight": "1.25",\\
  "--text-uic-5--marginLeft": "0px",\\
  "--text-uic-5--color": "var(--palette-color3)",\\
  "--text-uic-5--borderBottomStyle": "none",\\
  "--text-uic-5--textDecoration": "none",\\
  "--text-uic-5--letterSpacing": "0",\\
  "--text-uic-5--textTransform": "none",\\
  "--text-uic-5--stroke": "var(--palette-color2)",\\
  "--text-uic-5--textAlign": "left",\\
  "--text-uic-5--justifyContent": "flex-start",\\
  "--text-uic-5--marginTop": "auto",\\
  "--text-uic-5--marginBottom": "0",\\
  "--text-uic-5--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-5--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-5--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-5--textShadow": "var(--text-style-unset)",\\
\\
  "--text-uic-6--fontSize--desktop": "16px",\\
  "--text-uic-6--fontSize--tablet": "16px",\\
  "--text-uic-6--fontSize--mobile": "16px",\\
  "--text-uic-6--fontFamily": "var(--font2)",\\
  "--text-uic-6--fontWeight": "normal",\\
  "--text-uic-6--fontType": "bold",\\
  "--text-uic-6--fontStyle": "normal",\\
  "--text-uic-6--fontStretch": "normal",\\
  "--text-uic-6--lineHeight": "1.5",\\
  "--text-uic-6--marginLeft": "0px",\\
  "--text-uic-6--color": "var(--palette-color7)",\\
  "--text-uic-6--borderBottomStyle": "none",\\
  "--text-uic-6--textDecoration": "none",\\
  "--text-uic-6--letterSpacing": "0.12",\\
  "--text-uic-6--textTransform": "none",\\
  "--text-uic-6--stroke": "var(--palette-color2)",\\
  "--text-uic-6--textAlign": "left",\\
  "--text-uic-6--justifyContent": "flex-start",\\
  "--text-uic-6--marginTop": "auto",\\
  "--text-uic-6--marginBottom": "0",\\
  "--text-uic-6--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-uic-6--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-uic-6--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-uic-6--textShadow": "var(--text-style-unset)",\\
\\
  "--text-closedcaptions--fontSize--desktop": "24px",\\
  "--text-closedcaptions--fontSize--tablet": "24px",\\
  "--text-closedcaptions--fontSize--mobile": "24px",\\
  "--text-closedcaptions--fontFamily": "var(--font1)",\\
  "--text-closedcaptions--fontWeight": "normal",\\
  "--text-closedcaptions--fontType": "regular",\\
  "--text-closedcaptions--fontStyle": "normal",\\
  "--text-closedcaptions--fontStretch": "normal",\\
  "--text-closedcaptions--lineHeight": "1.35",\\
  "--text-closedcaptions--marginLeft": "0px",\\
  "--text-closedcaptions--color": "var(--white)",\\
  "--text-closedcaptions--borderBottomStyle": "none",\\
  "--text-closedcaptions--textDecoration": "none",\\
  "--text-closedcaptions--letterSpacing": "0",\\
  "--text-closedcaptions--textTransform": "none",\\
  "--text-closedcaptions--stroke": "var(--palette-color2)",\\
  "--text-closedcaptions--textAlign": "center",\\
  "--text-closedcaptions--justifyContent": "flex-start",\\
  "--text-closedcaptions--marginTop": "auto",\\
  "--text-closedcaptions--marginBottom": "0",\\
  "--text-closedcaptions--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-closedcaptions--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-closedcaptions--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-closedcaptions--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption--fontSize--desktop": "24px",\\
  "--text-caption--fontSize--tablet": "24px",\\
  "--text-caption--fontSize--mobile": "24px",\\
  "--text-caption--fontFamily": "var(--font1)",\\
  "--text-caption--fontWeight": "normal",\\
  "--text-caption--fontType": "regular",\\
  "--text-caption--fontStyle": "normal",\\
  "--text-caption--fontStretch": "normal",\\
  "--text-caption--lineHeight": "1.35",\\
  "--text-caption--marginLeft": "0px",\\
  "--text-caption--color": "var(--palette-color6)",\\
  "--text-caption--borderBottomStyle": "none",\\
  "--text-caption--textDecoration": "none",\\
  "--text-caption--letterSpacing": "0",\\
  "--text-caption--textTransform": "none",\\
  "--text-caption--stroke": "var(--palette-color2)",\\
  "--text-caption--textAlign": "center",\\
  "--text-caption--justifyContent": "flex-start",\\
  "--text-caption--marginTop": "auto",\\
  "--text-caption--marginBottom": "0",\\
  "--text-caption--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_correct--fontSize--desktop": "24px",\\
  "--text-caption_correct--fontSize--tablet": "24px",\\
  "--text-caption_correct--fontSize--mobile": "24px",\\
  "--text-caption_correct--fontFamily": "var(--font1)",\\
  "--text-caption_correct--fontWeight": "normal",\\
  "--text-caption_correct--fontType": "regular",\\
  "--text-caption_correct--fontStyle": "normal",\\
  "--text-caption_correct--fontStretch": "normal",\\
  "--text-caption_correct--lineHeight": "1.35",\\
  "--text-caption_correct--marginLeft": "0px",\\
  "--text-caption_correct--color": "var(--palette-color6)",\\
  "--text-caption_correct--borderBottomStyle": "none",\\
  "--text-caption_correct--textDecoration": "none",\\
  "--text-caption_correct--letterSpacing": "0",\\
  "--text-caption_correct--textTransform": "none",\\
  "--text-caption_correct--stroke": "var(--palette-color2)",\\
  "--text-caption_correct--textAlign": "center",\\
  "--text-caption_correct--justifyContent": "flex-start",\\
  "--text-caption_correct--marginTop": "auto",\\
  "--text-caption_correct--marginBottom": "0",\\
  "--text-caption_correct--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_correct--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_correct--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_correct--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_incorrect--fontSize--desktop": "24px",\\
  "--text-caption_incorrect--fontSize--tablet": "24px",\\
  "--text-caption_incorrect--fontSize--mobile": "24px",\\
  "--text-caption_incorrect--fontFamily": "var(--font1)",\\
  "--text-caption_incorrect--fontWeight": "normal",\\
  "--text-caption_incorrect--fontType": "regular",\\
  "--text-caption_incorrect--fontStyle": "normal",\\
  "--text-caption_incorrect--fontStretch": "normal",\\
  "--text-caption_incorrect--lineHeight": "1.35",\\
  "--text-caption_incorrect--marginLeft": "0px",\\
  "--text-caption_incorrect--color": "var(--palette-color6)",\\
  "--text-caption_incorrect--borderBottomStyle": "none",\\
  "--text-caption_incorrect--textDecoration": "none",\\
  "--text-caption_incorrect--letterSpacing": "0",\\
  "--text-caption_incorrect--textTransform": "none",\\
  "--text-caption_incorrect--stroke": "var(--palette-color2)",\\
  "--text-caption_incorrect--textAlign": "center",\\
  "--text-caption_incorrect--justifyContent": "flex-start",\\
  "--text-caption_incorrect--marginTop": "auto",\\
  "--text-caption_incorrect--marginBottom": "0",\\
  "--text-caption_incorrect--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_incorrect--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_incorrect--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_incorrect--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_incomplete--fontSize--desktop": "24px",\\
  "--text-caption_incomplete--fontSize--tablet": "24px",\\
  "--text-caption_incomplete--fontSize--mobile": "24px",\\
  "--text-caption_incomplete--fontFamily": "var(--font1)",\\
  "--text-caption_incomplete--fontWeight": "normal",\\
  "--text-caption_incomplete--fontType": "regular",\\
  "--text-caption_incomplete--fontStyle": "normal",\\
  "--text-caption_incomplete--fontStretch": "normal",\\
  "--text-caption_incomplete--lineHeight": "1.35",\\
  "--text-caption_incomplete--marginLeft": "0px",\\
  "--text-caption_incomplete--color": "var(--palette-color6)",\\
  "--text-caption_incomplete--borderBottomStyle": "none",\\
  "--text-caption_incomplete--textDecoration": "none",\\
  "--text-caption_incomplete--letterSpacing": "0",\\
  "--text-caption_incomplete--textTransform": "none",\\
  "--text-caption_incomplete--stroke": "var(--palette-color2)",\\
  "--text-caption_incomplete--textAlign": "center",\\
  "--text-caption_incomplete--justifyContent": "flex-start",\\
  "--text-caption_incomplete--marginTop": "auto",\\
  "--text-caption_incomplete--marginBottom": "0",\\
  "--text-caption_incomplete--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_incomplete--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_incomplete--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_incomplete--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_hint--fontSize--desktop": "24px",\\
  "--text-caption_hint--fontSize--tablet": "24px",\\
  "--text-caption_hint--fontSize--mobile": "24px",\\
  "--text-caption_hint--fontFamily": "var(--font1)",\\
  "--text-caption_hint--fontWeight": "normal",\\
  "--text-caption_hint--fontType": "regular",\\
  "--text-caption_hint--fontStyle": "normal",\\
  "--text-caption_hint--fontStretch": "normal",\\
  "--text-caption_hint--lineHeight": "1.35",\\
  "--text-caption_hint--marginLeft": "0px",\\
  "--text-caption_hint--color": "var(--palette-color6)",\\
  "--text-caption_hint--borderBottomStyle": "none",\\
  "--text-caption_hint--textDecoration": "none",\\
  "--text-caption_hint--letterSpacing": "0",\\
  "--text-caption_hint--textTransform": "none",\\
  "--text-caption_hint--stroke": "var(--palette-color2)",\\
  "--text-caption_hint--textAlign": "center",\\
  "--text-caption_hint--justifyContent": "flex-start",\\
  "--text-caption_hint--marginTop": "auto",\\
  "--text-caption_hint--marginBottom": "0",\\
  "--text-caption_hint--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_hint--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_hint--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_hint--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_retry--fontSize--desktop": "24px",\\
  "--text-caption_retry--fontSize--tablet": "24px",\\
  "--text-caption_retry--fontSize--mobile": "24px",\\
  "--text-caption_retry--fontFamily": "var(--font1)",\\
  "--text-caption_retry--fontWeight": "normal",\\
  "--text-caption_retry--fontType": "regular",\\
  "--text-caption_retry--fontStyle": "normal",\\
  "--text-caption_retry--fontStretch": "normal",\\
  "--text-caption_retry--lineHeight": "1.35",\\
  "--text-caption_retry--marginLeft": "0px",\\
  "--text-caption_retry--color": "var(--palette-color6)",\\
  "--text-caption_retry--borderBottomStyle": "none",\\
  "--text-caption_retry--textDecoration": "none",\\
  "--text-caption_retry--letterSpacing": "0",\\
  "--text-caption_retry--textTransform": "none",\\
  "--text-caption_retry--stroke": "var(--palette-color2)",\\
  "--text-caption_retry--textAlign": "center",\\
  "--text-caption_retry--justifyContent": "flex-start",\\
  "--text-caption_retry--marginTop": "auto",\\
  "--text-caption_retry--marginBottom": "0",\\
  "--text-caption_retry--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_retry--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_retry--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_retry--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_timeout--fontSize--desktop": "24px",\\
  "--text-caption_timeout--fontSize--tablet": "24px",\\
  "--text-caption_timeout--fontSize--mobile": "24px",\\
  "--text-caption_timeout--fontFamily": "var(--font1)",\\
  "--text-caption_timeout--fontWeight": "normal",\\
  "--text-caption_timeout--fontType": "regular",\\
  "--text-caption_timeout--fontStyle": "normal",\\
  "--text-caption_timeout--fontStretch": "normal",\\
  "--text-caption_timeout--lineHeight": "1.35",\\
  "--text-caption_timeout--marginLeft": "0px",\\
  "--text-caption_timeout--color": "var(--palette-color6)",\\
  "--text-caption_timeout--borderBottomStyle": "none",\\
  "--text-caption_timeout--textDecoration": "none",\\
  "--text-caption_timeout--letterSpacing": "0",\\
  "--text-caption_timeout--textTransform": "none",\\
  "--text-caption_timeout--stroke": "var(--palette-color2)",\\
  "--text-caption_timeout--textAlign": "center",\\
  "--text-caption_timeout--justifyContent": "flex-start",\\
  "--text-caption_timeout--marginTop": "auto",\\
  "--text-caption_timeout--marginBottom": "0",\\
  "--text-caption_timeout--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-caption_timeout--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_timeout--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_timeout--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_1--fontSize--desktop": "18px",\\
  "--text-caption_1--fontSize--tablet": "18px",\\
  "--text-caption_1--fontSize--mobile": "16px",\\
  "--text-caption_1--fontFamily": "var(--font2)",\\
  "--text-caption_1--fontWeight": "normal",\\
  "--text-caption_1--fontType": "regular",\\
  "--text-caption_1--fontStyle": "normal",\\
  "--text-caption_1--fontStretch": "normal",\\
  "--text-caption_1--lineHeight": "1.2",\\
  "--text-caption_1--marginLeft": "0px",\\
  "--text-caption_1--color": "#FFFFFF",\\
  "--text-caption_1--borderBottomStyle": "none",\\
  "--text-caption_1--textDecoration": "none",\\
  "--text-caption_1--letterSpacing": "0",\\
  "--text-caption_1--textTransform": "none",\\
  "--text-caption_1--stroke": "#00000000",\\
  "--text-caption_1--textAlign": "left",\\
  "--text-caption_1--justifyContent": "flex-start",\\
  "--text-caption_1--marginTop": "auto",\\
  "--text-caption_1--marginBottom": "0",\\
  "--text-caption_1--defaultTextStroke": "1px #00000000",\\
  "--text-caption_1--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_1--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_1--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_2--fontSize--desktop": "20px",\\
  "--text-caption_2--fontSize--tablet": "20px",\\
  "--text-caption_2--fontSize--mobile": "18px",\\
  "--text-caption_2--fontFamily": "var(--font2)",\\
  "--text-caption_2--fontWeight": "normal",\\
  "--text-caption_2--fontType": "bold",\\
  "--text-caption_2--fontStyle": "normal",\\
  "--text-caption_2--fontStretch": "normal",\\
  "--text-caption_2--lineHeight": "1.2",\\
  "--text-caption_2--marginLeft": "0px",\\
  "--text-caption_2--color": "#FFFFFF",\\
  "--text-caption_2--borderBottomStyle": "none",\\
  "--text-caption_2--textDecoration": "none",\\
  "--text-caption_2--letterSpacing": "0",\\
  "--text-caption_2--textTransform": "none",\\
  "--text-caption_2--stroke": "#00000000",\\
  "--text-caption_2--textAlign": "left",\\
  "--text-caption_2--justifyContent": "flex-start",\\
  "--text-caption_2--marginTop": "auto",\\
  "--text-caption_2--marginBottom": "0",\\
  "--text-caption_2--defaultTextStroke": "1px #00000000",\\
  "--text-caption_2--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_2--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_2--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_3--fontSize--desktop": "24px",\\
  "--text-caption_3--fontSize--tablet": "24px",\\
  "--text-caption_3--fontSize--mobile": "22px",\\
  "--text-caption_3--fontFamily": "var(--font1)",\\
  "--text-caption_3--fontWeight": "normal",\\
  "--text-caption_3--fontType": "italic",\\
  "--text-caption_3--fontStyle": "normal",\\
  "--text-caption_3--fontStretch": "normal",\\
  "--text-caption_3--lineHeight": "1.2",\\
  "--text-caption_3--marginLeft": "0px",\\
  "--text-caption_3--color": "#FFFFFF",\\
  "--text-caption_3--borderBottomStyle": "none",\\
  "--text-caption_3--textDecoration": "none",\\
  "--text-caption_3--letterSpacing": "0",\\
  "--text-caption_3--textTransform": "none",\\
  "--text-caption_3--stroke": "#00000000",\\
  "--text-caption_3--textAlign": "left",\\
  "--text-caption_3--justifyContent": "flex-start",\\
  "--text-caption_3--marginTop": "auto",\\
  "--text-caption_3--marginBottom": "0",\\
  "--text-caption_3--defaultTextStroke": "1px #00000000",\\
  "--text-caption_3--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_3--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_3--textShadow": "var(--text-style-unset)",\\
\\
  "--text-caption_4--fontSize--desktop": "22px",\\
  "--text-caption_4--fontSize--tablet": "22px",\\
  "--text-caption_4--fontSize--mobile": "20px",\\
  "--text-caption_4--fontFamily": "var(--font2)",\\
  "--text-caption_4--fontWeight": "normal",\\
  "--text-caption_4--fontType": "italic",\\
  "--text-caption_4--fontStyle": "normal",\\
  "--text-caption_4--fontStretch": "normal",\\
  "--text-caption_4--lineHeight": "1.3",\\
  "--text-caption_4--marginLeft": "0px",\\
  "--text-caption_4--color": "#666666",\\
  "--text-caption_4--borderBottomStyle": "none",\\
  "--text-caption_4--textDecoration": "none",\\
  "--text-caption_4--letterSpacing": "0",\\
  "--text-caption_4--textTransform": "none",\\
  "--text-caption_4--stroke": "#00000000",\\
  "--text-caption_4--textAlign": "left",\\
  "--text-caption_4--justifyContent": "flex-start",\\
  "--text-caption_4--marginTop": "auto",\\
  "--text-caption_4--marginBottom": "0",\\
  "--text-caption_4--defaultTextStroke": "1px #00000000",\\
  "--text-caption_4--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-caption_4--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-caption_4--textShadow": "var(--text-style-unset)",\\
\\
  "--text-comment-box--fontSize--desktop": "20px",\\
  "--text-comment-box--fontSize--tablet": "20px",\\
  "--text-comment-box--fontSize--mobile": "20px",\\
  "--text-comment-box--fontFamily": "var(--font1)",\\
  "--text-comment-box--fontWeight": "normal",\\
  "--text-comment-box--fontType": "regular",\\
  "--text-comment-box--fontStyle": "normal",\\
  "--text-comment-box--fontStretch": "normal",\\
  "--text-comment-box--lineHeight": "1.35",\\
  "--text-comment-box--marginLeft": "0px",\\
  "--text-comment-box--color": "var(--palette-color6)",\\
  "--text-comment-box--borderBottomStyle": "none",\\
  "--text-comment-box--textDecoration": "none",\\
  "--text-comment-box--letterSpacing": "0",\\
  "--text-comment-box--textTransform": "none",\\
  "--text-comment-box--stroke": "var(--palette-color2)",\\
  "--text-comment-box--textAlign": "center",\\
  "--text-comment-box--justifyContent": "flex-start",\\
  "--text-comment-box--marginTop": "auto",\\
  "--text-comment-box--marginBottom": "0",\\
  "--text-comment-box--defaultTextStroke": "1px var(--palette-color2)",\\
  "--text-comment-box--WebkitTextStroke": "var(--text-style-unset)",\\
  "--text-comment-box--defaultTextShadow": "0px 4px 8px var(--greyscale2)",\\
  "--text-comment-box--textShadow": "var(--text-style-unset)",\\
\\
  "--theme_image_default--strokeColor": "var(--palette-color1)",\\
  "--theme_image_default--boxShadowColor": "var(--greyscale3)",\\
\\
  "--theme_image_greyscale--strokeColor": "var(--palette-color1)",\\
  "--theme_image_greyscale--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_greyscale--intensity": 100,\\
\\
  "--theme_image_lighten--strokeColor": "var(--palette-color1)",\\
  "--theme_image_lighten--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_lighten--intensity": 80,\\
\\
  "--theme_image_darken--strokeColor": "var(--palette-color1)",\\
  "--theme_image_darken--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_darken--intensity": 80,\\
\\
  "--theme_image_overlay--strokeColor": "var(--palette-color1)",\\
  "--theme_image_overlay--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_overlay--intensity": 80,\\
  "--theme_image_overlay--primaryFillColor": "var(--palette-color2)",\\
  "--theme_image_overlay--secondaryFillColor": "var(--palette-color1)",\\
\\
  "--theme_image_colorize--strokeColor": "var(--palette-color1)",\\
  "--theme_image_colorize--boxShadowColor": "var(--greyscale3)",\\
  "--theme_image_colorize--intensity": 80,\\
  "--theme_image_colorize--primaryFillColor": "var(--palette-color4)",\\
  "--theme_image_colorize--secondaryFillColor": "var(--palette-color1)",\\
\\
\\
  "--button-normal--primaryColor": "var(--palette-color7)",\\
  "--button-normal--borderColor": "var(--palette-color7)",\\
  "--button-normal--shadowColor": "var(--greyscale3)",\\
  "--text-button-normal--color": "var(--palette-color0)",\\
  "--text-button-normal--fontFamily": "var(--font2)",\\
  "--text-button-normal--fontType": "regular",\\
  "--text-button-normal--fontSize--desktop": "16px",\\
  "--text-button-normal--fontSize--tablet": "16px",\\
  "--text-button-normal--fontSize--mobile": "16px",\\
\\
  "--button-selected--primaryColor": "var(--palette-color5)",\\
  "--button-selected--borderColor": "var(--palette-color5)",\\
  "--button-selected--shadowColor": "var(--greyscale3)",\\
  "--text-button-selected--color": "var(--palette-color0)",\\
  "--text-button-selected--fontFamily": "var(--font2)",\\
  "--text-button-selected--fontType": "regular",\\
  "--text-button-selected--fontSize--desktop": "16px",\\
  "--text-button-selected--fontSize--tablet": "16px",\\
  "--text-button-selected--fontSize--mobile": "16px",\\
\\
  "--button-disabled--primaryColor": "var(--palette-color3)",\\
  "--button-disabled--borderColor": "var(--palette-color3)",\\
  "--button-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-button-disabled--color": "var(--palette-color4)",\\
  "--text-button-disabled--fontFamily": "var(--font2)",\\
  "--text-button-disabled--fontType": "regular",\\
  "--text-button-disabled--fontSize--desktop": "16px",\\
  "--text-button-disabled--fontSize--tablet": "16px",\\
  "--text-button-disabled--fontSize--mobile": "16px",\\
\\
  "--button-hover--primaryColor": "#112FA7",\\
  "--button-hover--borderColor": "#112FA7",\\
  "--button-hover--shadowColor": "var(--greyscale3)",\\
  "--text-button-hover--color": "var(--palette-color0)",\\
  "--text-button-hover--fontFamily": "var(--font2)",\\
  "--text-button-hover--fontType": "regular",\\
  "--text-button-hover--fontSize--desktop": "16px",\\
  "--text-button-hover--fontSize--tablet": "16px",\\
  "--text-button-hover--fontSize--mobile": "16px",\\
\\
  "--button-visited--primaryColor": "#112FA780",\\
  "--button-visited--borderColor": "#112FA780",\\
  "--button-visited--shadowColor": "var(--greyscale3)",\\
  "--text-button-visited--color": "var(--palette-color0)",\\
  "--text-button-visited--fontFamily": "var(--font2)",\\
  "--text-button-visited--fontType": "regular",\\
  "--text-button-visited--fontSize--desktop": "16px",\\
  "--text-button-visited--fontSize--tablet": "16px",\\
  "--text-button-visited--fontSize--mobile": "16px",\\
\\
  "--checkbox-normal--primaryColor": "var(--palette-color0)",\\
  "--checkbox-normal--borderColor": "var(--palette-color3)",\\
  "--checkbox-normal--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-normal--color": "var(--palette-color4)",\\
  "--text-checkbox-normal--fontFamily": "var(--font1)",\\
  "--text-checkbox-normal--fontType": "regular",\\
  "--text-checkbox-normal--fontSize--desktop": "22px",\\
  "--text-checkbox-normal--fontSize--tablet": "20px",\\
  "--text-checkbox-normal--fontSize--mobile": "20px",\\
\\
  "--checkbox-selected--primaryColor": "var(--palette-color7)",\\
  "--checkbox-selected--borderColor": "var(--palette-color4)",\\
  "--checkbox-selected--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-selected--color": "var(--palette-color4)",\\
  "--text-checkbox-selected--fontFamily": "var(--font1)",\\
  "--text-checkbox-selected--fontType": "regular",\\
  "--text-checkbox-selected--fontSize--desktop": "22px",\\
  "--text-checkbox-selected--fontSize--tablet": "20px",\\
  "--text-checkbox-selected--fontSize--mobile": "20px",\\
\\
  "--checkbox-disabled-checked--primaryColor": "var(--palette-color3)",\\
  "--checkbox-disabled-checked--borderColor": "var(--palette-color3)",\\
  "--checkbox-disabled-checked--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-disabled-checked--color": "var(--palette-color3)",\\
  "--text-checkbox-disabled-checked--fontFamily": "var(--font1)",\\
  "--text-checkbox-disabled-checked--fontType": "regular",\\
  "--text-checkbox-disabled-checked--fontSize--desktop": "22px",\\
  "--text-checkbox-disabled-checked--fontSize--tablet": "20px",\\
  "--text-checkbox-disabled-checked--fontSize--mobile": "20px",\\
\\
  "--checkbox-hover--primaryColor": "var(--palette-color0)",\\
  "--checkbox-hover--borderColor": "var(--palette-color3)",\\
  "--checkbox-hover--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-hover--color": "var(--palette-color5)",\\
  "--text-checkbox-hover--fontFamily": "var(--font1)",\\
  "--text-checkbox-hover--fontType": "regular",\\
  "--text-checkbox-hover--fontSize--desktop": "22px",\\
  "--text-checkbox-hover--fontSize--tablet": "20px",\\
  "--text-checkbox-hover--fontSize--mobile": "20px",\\
\\
  "--checkbox-disabled-unchecked--primaryColor": "var(--palette-color3)",\\
  "--checkbox-disabled-unchecked--borderColor": "var(--palette-color3)",\\
  "--checkbox-disabled-unchecked--shadowColor": "var(--greyscale3)",\\
  "--text-checkbox-disabled-unchecked--color": "var(--palette-color3)",\\
  "--text-checkbox-disabled-unchecked--fontFamily": "var(--font1)",\\
  "--text-checkbox-disabled-unchecked--fontType": "regular",\\
  "--text-checkbox-disabled-unchecked--fontSize--desktop": "22px",\\
  "--text-checkbox-disabled-unchecked--fontSize--tablet": "20px",\\
  "--text-checkbox-disabled-unchecked--fontSize--mobile": "20px",\\
\\
  "--inputfield-normal--primaryColor": "var(--palette-color0)", \\
  "--inputfield-normal--borderColor": "var(--palette-color3)",\\
  "--inputfield-normal--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-normal--color": "var(--palette-color4)",\\
  "--text-inputfield-normal--fontFamily": "var(--font1)",\\
  "--text-inputfield-normal--fontType": "regular",\\
  "--text-inputfield-normal--fontSize--desktop": "18px",\\
  "--text-inputfield-normal--fontSize--tablet": "20px",\\
  "--text-inputfield-normal--fontSize--mobile": "20px",\\
\\
  "--inputfield-active--primaryColor": "var(--palette-color0)",\\
  "--inputfield-active--borderColor": "var(--palette-color7)",\\
  "--inputfield-active--shadowColor": "#var(--greyscale3)",\\
  "--text-inputfield-active--color": "var(--palette-color4)",\\
  "--text-inputfield-active--fontFamily": "var(--font1)",\\
  "--text-inputfield-active--fontType": "regular",\\
  "--text-inputfield-active--fontSize--desktop": "18px",\\
  "--text-inputfield-active--fontSize--tablet": "20px",\\
  "--text-inputfield-active--fontSize--mobile": "20px",\\
\\
  "--inputfield-disabled--primaryColor": "var(--palette-color3)",\\
  "--inputfield-disabled--borderColor": "var(--palette-color3)",\\
  "--inputfield-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-disabled--color": "var(--palette-color1)",\\
  "--text-inputfield-disabled--fontFamily": "var(--font1)",\\
  "--text-inputfield-disabled--fontType": "regular",\\
  "--text-inputfield-disabled--fontSize--desktop": "18px",\\
  "--text-inputfield-disabled--fontSize--tablet": "20px",\\
  "--text-inputfield-disabled--fontSize--mobile": "20px",\\
\\
  "--inputfield-focusLost--primaryColor": "var(--palette-color0)",\\
  "--inputfield-focusLost--borderColor": "var(--palette-color3)",\\
  "--inputfield-focusLost--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-focusLost--color": "var(--palette-color4)",\\
  "--text-inputfield-focusLost--fontFamily": "var(--font1)",\\
  "--text-inputfield-focusLost--fontType": "regular",\\
  "--text-inputfield-focusLost--fontSize--desktop": "18px",\\
  "--text-inputfield-focusLost--fontSize--tablet": "20px",\\
  "--text-inputfield-focusLost--fontSize--mobile": "20px",\\
\\
  "--inputfield-error--primaryColor": "var(--palette-color0)",\\
  "--inputfield-error--borderColor": "var(--error)",\\
  "--inputfield-error--shadowColor": "var(--greyscale3)",\\
  "--text-inputfield-error--color": "var(--palette-color4)",\\
  "--text-inputfield-error--fontFamily": "var(--font1)",\\
  "--text-inputfield-error--fontType": "regular",\\
  "--text-inputfield-error--fontSize--desktop": "18px",\\
  "--text-inputfield-error--fontSize--tablet": "20px",\\
  "--text-inputfield-error--fontSize--mobile": "20px",\\
\\
  "--dropdown-normal--primaryColor": "var(--palette-color0)",\\
  "--dropdown-normal--borderColor": "var(--palette-color3)",\\
  "--dropdown-normal--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-normal--color": "var(--palette-color4)",\\
  "--text-dropdown-normal--fontFamily": "var(--font1)",\\
  "--text-dropdown-normal--fontType": "italic",\\
  "--text-dropdown-normal--fontSize--desktop": "18px",\\
  "--text-dropdown-normal--fontSize--tablet": "18px",\\
  "--text-dropdown-normal--fontSize--mobile": "18px",\\
\\
  "--dropdown-selected--primaryColor": "var(--palette-color0)",\\
  "--dropdown-selected--borderColor": "var(--palette-color7)",\\
  "--dropdown-selected--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-selected--color": "var(--palette-color4)",\\
  "--text-dropdown-selected--fontFamily": "var(--font1)",\\
  "--text-dropdown-selected--fontType": "italic",\\
  "--text-dropdown-selected--fontSize--desktop": "18px",\\
  "--text-dropdown-selected--fontSize--tablet": "18px",\\
  "--text-dropdown-selected--fontSize--mobile": "18px",\\
\\
  "--dropdown-disabled--primaryColor": "var(--palette-color3)",\\
  "--dropdown-disabled--borderColor": "var(--palette-color3)",\\
  "--dropdown-disabled--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-disabled--color": "var(--palette-color1)",\\
  "--text-dropdown-disabled--fontFamily": "var(--font1)",\\
  "--text-dropdown-disabled--fontType": "italic",\\
  "--text-dropdown-disabled--fontSize--desktop": "18px",\\
  "--text-dropdown-disabled--fontSize--tablet": "18px",\\
  "--text-dropdown-disabled--fontSize--mobile": "18px",\\
\\
  "--dropdown-hover--primaryColor": "var(--palette-color0)",\\
  "--dropdown-hover--borderColor": "var(--palette-color3)",\\
  "--dropdown-hover--shadowColor": "var(--greyscale3)",\\
  "--text-dropdown-hover--color": "var(--palette-color4)",\\
  "--text-dropdown-hover--fontFamily": "var(--font1)",\\
  "--text-dropdown-hover--fontType": "italic",\\
  "--text-dropdown-hover--fontSize--desktop": "18px",\\
  "--text-dropdown-hover--fontSize--tablet": "18px",\\
  "--text-dropdown-hover--fontSize--mobile": "18px",\\
\\
  "--radio-normal--primaryColor": "var(--palette-color0)",\\
  "--radio-normal--borderColor": "var(--palette-color3)",\\
  "--radio-normal--shadowColor": "var(--greyscale3)",\\
  "--text-radio-normal--color": "var(--palette-color4)",\\
  "--text-radio-normal--fontFamily": "var(--font1)",\\
  "--text-radio-normal--fontType": "regular",\\
  "--text-radio-normal--fontSize--desktop": "22px",\\
  "--text-radio-normal--fontSize--tablet": "20px",\\
  "--text-radio-normal--fontSize--mobile": "20px",\\
\\
  "--radio-selected--primaryColor": "var(--palette-color0)",\\
  "--radio-selected--borderColor": "var(--palette-color4)",\\
  "--radio-selected--shadowColor": "var(--greyscale3)",\\
  "--text-radio-selected--color": "var(--palette-color4)",\\
  "--text-radio-selected--fontFamily": "var(--font1)",\\
  "--text-radio-selected--fontType": "regular",\\
  "--text-radio-selected--fontSize--desktop": "22px",\\
  "--text-radio-selected--fontSize--tablet": "20px",\\
  "--text-radio-selected--fontSize--mobile": "20px",\\
\\
  "--radio-disabled-checked--primaryColor": "var(--palette-color3)",\\
  "--radio-disabled-checked--borderColor": "var(--palette-color3)",\\
  "--radio-disabled-checked--shadowColor": "var(--greyscale3)",\\
  "--text-radio-disabled-checked--color": "var(--palette-color3)",\\
  "--text-radio-disabled-checked--fontFamily": "var(--font1)",\\
  "--text-radio-disabled-checked--fontType": "regular",\\
  "--text-radio-disabled-checked--fontSize--desktop": "22px",\\
  "--text-radio-disabled-checked--fontSize--tablet": "20px",\\
  "--text-radio-disabled-checked--fontSize--mobile": "20px",\\
\\
  "--radio-hover--primaryColor": "var(--palette-color0)",\\
  "--radio-hover--borderColor": "var(--palette-color3)",\\
  "--radio-hover--shadowColor": "var(--greyscale3)",\\
  "--text-radio-hover--color": "var(--palette-color5)",\\
  "--text-radio-hover--fontFamily": "var(--font1)",\\
  "--text-radio-hover--fontType": "regular",\\
  "--text-radio-hover--fontSize--desktop": "22px",\\
  "--text-radio-hover--fontSize--tablet": "20px",\\
  "--text-radio-hover--fontSize--mobile": "20px",\\
\\
  "--radio-disabled-unchecked--primaryColor": "var(--palette-color3)",\\
  "--radio-disabled-unchecked--borderColor": "var(--palette-color3)",\\
  "--radio-disabled-unchecked--shadowColor": "var(--greyscale3)",\\
  "--text-radio-disabled-unchecked--color": "var(--palette-color3)",\\
  "--text-radio-disabled-unchecked--fontFamily": "var(--font1)",\\
  "--text-radio-disabled-unchecked--fontType": "regular",\\
  "--text-radio-disabled-unchecked--fontSize--desktop": "22px",\\
  "--text-radio-disabled-unchecked--fontSize--tablet": "20px",\\
  "--text-radio-disabled-unchecked--fontSize--mobile": "20px",\\
\\
  "--video_preset-color": "#666666",\\
  "--video_preset-borderColor": "#666666",\\
  \\
  "--clickbox-preset-fill-color": "#3F80E4",\\
\\
  "--drag-object-default-state-fill-color": "255, 255, 255",\\
  "--drag-object-hover-state-fill-color": "250, 250, 250",\\
  "--drag-object-transition-state-fill-color": "250, 250, 250",\\
  "--drag-object-dragOver-state-fill-color": "250, 250, 250",\\
  "--drag-object-dropped-state-fill-color": "255, 255, 255",\\
\\
  "--drag-object-default-state-border-color": "214, 213, 209",\\
  "--drag-object-hover-state-border-color": "214, 213, 209",\\
  "--drag-object-transition-state-border-color": "214, 213, 209",\\
  "--drag-object-dragOver-state-border-color": "230, 132, 80",\\
  "--drag-object-dropped-state-border-color": "214, 213, 209",\\
\\
  "--drop-object-default-state-fill-color": "255, 255, 255",\\
  "--drop-object-hover-state-fill-color": "255, 255, 255",\\
  "--drop-object-dragOver-state-fill-color": "230, 132, 80",\\
  "--drop-object-dropped-state-fill-color": "255, 255, 255",\\
\\
  "--drop-object-default-state-border-color": "42, 49, 62",\\
  "--drop-object-hover-state-border-color": "230, 132, 80",\\
  "--drop-object-dragOver-state-border-color": "230, 132, 80",\\
  "--drop-object-dropped-state-border-color": "42, 49, 62"\\
}',
uic_presets:'{\\
  "cp_button_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 1,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "--button-selected--shadowColor",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-visited--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style": {\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "#707070",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_hover": {\\
    "fill": "#9ec4f3",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--black)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_selected": {\\
    "fill": "var(--palette-color5)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_visited": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_disabled": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_active": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-active--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-active--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-active--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_focusLost": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-focusLost--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-focusLost--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-focusLost--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_error": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-error--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-error--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-error--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 14,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.78\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "video_preset_style": {\\
    "fillEnable": 0,\\
    "strokeEnable": 0,\\
    "shadowEnable": 0,\\
    "fill": "var(--video_preset-color)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--video_preset-border)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_comment_box_shape_1_solid_style": {\\
    "fill": "#F2B807",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clickbox_shape_solid_style": {\\
    "fill": "var(--clickbox-preset-fill-color)",\\
    "fillOpacity": 0.6,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "2, 3",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#333333",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#000000",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#D6D5D1",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clicktoreveal_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#ffffff",\\
    "fillOpacity": 1,\\
    "stroke": "#ffffff",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 3,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color7)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color8)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_blue": {\\
    "fill": "#ADD8E6",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}'
},
project_main:{
from:1,
to:0,
currentFrame:1,
featureFlags:{
isNewWidgetArchitecture:'{"isEnabled":true,"featureData":{}}'
}
,
useResponsive:true,
responsiveType:512,
isResponsiveSim:0,
currentFrame:1,
useWidgetVersion7:false,
isPublishedFromLacuna:false,
vestr:0,
vim:0,
slides:'Slide388,Slide1987,Slide886',
questions:'',
autoplay:false,
preloader:true,
preloaderFileName:'dr/loading.gif',
preloaderPercentage:100,
pprtd:false,
peon:false,
fadeInAtStart:0,
fadeOutAtEnd:0
},
borderProperties:{
hasBorder:false
},
playBarProperties:{
hasPlayBar:true,
jsfile:'playbarScript.js',
cssfile:'playbarStyle.css',
position:3,
layout:3,
showOnHover:false,
overlay:true,
tworow:false,
hasRewind:true,
hasBackward:true,
hasPlay:true,
hasEnterVR:false,
hasSlider:true,
hasForward:true,
hasCC:false,
hasAudioOn:true,
hasExit:true,
hasFastForward:true,
applyColors:false,
alpha:100,
noToolTips:false,
locale:0
},
tocProperties:{
tocProperties:'{"tocConfig":{"labels":{"TITLE":"Table of Content","SLIDE_DETAILS":"SLIDE TITLE","DURATION":"DURATION","CLOSE_BUTTON_LABEL":"Close"},"slideDetails":[{"label":"Blank 1","type":"slide","parentId":null,"id":"Slide388","isVisible":true,"slideVisited":false,"originalId":388,"labelShouldBeInSync":true},{"label":"Blank 2","type":"slide","parentId":null,"id":"Slide1987","isVisible":true,"slideVisited":false,"originalId":1987,"labelShouldBeInSync":true},{"label":"Title and text 1","type":"slide","parentId":null,"id":"Slide886","isVisible":true,"slideVisited":false,"originalId":886,"labelShouldBeInSync":true}],"tocGeneratedOnPreviewClick":true,"preserveSlidesOrder":true},"playbarConfig":{"isPlaybarControlsPlayEnabled":true,"isPlaybarControlsNextEnabled":true,"isPlaybarControlsTOCEnabled":true,"isShowPlaybarEnabled":true,"isShowTooltipsEnabled":true,"isPlaybarControlsBackEnabled":true,"isHidePlaybarInQuizEnabled":false,"isPlaybarControlsMuteEnabled":true,"isPlaybarControlsClosedCaptionsEnabled":false}}'
},
trecs:[{
link:388,
text:[]
}
,{
link:1987,
text:[]
}
,{
link:886,
text:[]
}
]

,
typekit:{
kit_id:''
},
};
cp.model.projectImages=[
'assets/htmlimages/ThreeD_Close.svg',
'assets/htmlimages/ThreeD_HotspotDefaultGlow.png',
'assets/htmlimages/ThreeD_HotspotGlow.png',
'assets/htmlimages/assessmenthotspotvisited.svg',
'assets/htmlimages/expand_icon.png',
'assets/htmlimages/img_trans.gif',
'assets/htmlimages/placeholder.png'
];
cp.model.data.images=[{
ip:'dr/01162.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01209.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01256.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01303.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01350.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01397.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01460.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01544.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01628.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01712.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01796.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01880.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01940.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/01962.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02099.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02164.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02691.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02815.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/02931.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03080.jpeg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03083.jpeg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03086.jpeg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03089.jpeg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/03192.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0553.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
];
cp.model.videos=[
];
cp.model.slideVideos=[
];
cp.model.tocVideos=[
];
cp.model.audios=[
];

cp.initVariables = function(){
cp.cv('CaptivateVersion','12.2.0',1,1000,0);
cp.cv('Date.DateDDMMYY','dd/mm/yyyy',1,15,0);
cp.cv('Date.DateMMDDYY','mm/dd/yyyy',1,15,0);
cp.cv('Date.Day',1,1,15,0);
cp.cv('Date.Hours','hh',1,15,0);
cp.cv('Date.LocaleString','',1,15,0);
cp.cv('Date.Minutes','mm',1,15,0);
cp.cv('Date.Month','mm',1,15,0);
cp.cv('Date.Time','hh:mm:ss',1,15,0);
cp.cv('Date.Today','dd',1,15,0);
cp.cv('Date.Year','yyyy',1,15,0);
cp.cv('Project.AudioLevel',100,1,15,0);
cp.cv('Project.ClosedCaptions',1,1,15,0);
cp.cv('Project.CurrentSlideName','slide',1,15,0);
cp.cv('Project.CurrentSlideNumber',1,1,15,0);
cp.cv('Project.LockTOC',0,1,15,0);
cp.cv('Project.MuteAudio',0,1,15,0);
cp.cv('Project.ShowPlaybar',1,1,15,0);
cp.cv('Project.ShowTOC',0,1,15,0);
cp.cv('Project.SlideCount',1,1,15,0);
cp.cv('Question.AnswerChoice','',1,15,0);
cp.cv('Question.MaxAttempts',0,1,15,0);
cp.cv('Question.NegativePoints',0,1,15,0);
cp.cv('Question.PointsAssigned',0,1,15,0);
cp.cv('Question.PreviousQuestionScore',0,1,15,0);
cp.cv('Quiz.AttemptCount',0,1,15,0);
cp.cv('Quiz.CorrectAnswerCount',0,1,15,0);
cp.cv('Quiz.InReview',0,1,15,0);
cp.cv('Quiz.InScope',0,1,15,0);
cp.cv('Quiz.MaxScore',0,1,1000,0);
cp.cv('Quiz.Pass',0,1,15,0);
cp.cv('Quiz.PassPercentage',80,1,1000,0);
cp.cv('Quiz.PassPoints',0,1,1000,0);
cp.cv('Quiz.PercentageScore',0,1,15,0);
cp.cv('Quiz.QuestionCount',0,1,1000,0);
cp.cv('Quiz.Score',0,1,15,0);
cp.cv('Quiz.UnansweredQuestionCount',0,1,1000,0);
cp.cv('cpInfoHasPlaybar',1,1,1000,0);
cp.cv('cpInfoSlidesInProject',3,1,1000,0);
cp.cv('cpLockTOC',0,1,1000,0);
cp.cv('cpQuizInfoPreTestTotalQuestions',0,1,1000,0);
cp.cv('cpQuizInfoTotalQuizPoints',0,1,1000,0);
cp.cv('cpInfoPrevFrame',0,1,15,0);
cp.cv('LMS.CourseName','',0,15,0);
cp.cv('LMS.LearnerID','',0,15,0);
cp.cv('LMS.LearnerName','',0,15,0);
};cp.ReportingVariables="LMS.CourseName,LMS.LearnerID,LMS.LearnerName,";
};cp.sbw=0;cp.useg=0;cp.geo=0;cp.pg=0;cp.win8=0;cp.autoGrow=1;cp.fluidFont=1;
